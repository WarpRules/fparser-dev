//===========================================
// Function parser v3.1 optimizer by Bisqwit
//===========================================

/* NOTE:
   This is a concatenation of all the header and source files of the
   original optimizer source code. All the code has been concatenated
   into this single file for convenience of usage (in other words, to
   simply use the optimizer, it's enough to add this file to the project
   rather than a multitude of files which the original optimizer source
   code is composed of).

   Thus this file exists for the usage of the Function parser library
   only, and is not suitable for developing it further. If you want to
   develop the library further, you should download the development
   version of the library, which has all the original source files.
 */

#include "fpconfig.hh"
#ifdef FP_SUPPORT_OPTIMIZER

#include <stdint.h>
#include <vector>

#include "fpconfig.hh"
#include "fparser.hh"

namespace FPoptimizer_CodeTree
{
    class CodeTreeParserData;
    class CodeTree;

    class CodeTreeP
    {
    public:
        CodeTreeP()                   : p(0)   { }
        CodeTreeP(CodeTree*        b) : p(b)   { Birth(); }
        CodeTreeP(const CodeTreeP& b) : p(&*b) { Birth(); }

        inline CodeTree& operator* () const { return *p; }
        inline CodeTree* operator->() const { return p; }

        CodeTreeP& operator= (CodeTree*        b) { Set(b); return *this; }
        CodeTreeP& operator= (const CodeTreeP& b) { Set(&*b); return *this; }

        ~CodeTreeP() { Forget(); }

    private:
        inline static void Have(CodeTree* p2);
        inline void Forget();
        inline void Birth();
        inline void Set(CodeTree* p2);
    private:
        CodeTree* p;
    };

    class CodeTree
    {
        friend class CodeTreeParserData;
        friend class CodeTreeP;

        int RefCount;

    public:
        /* Describing the codetree node */
        unsigned Opcode;
        union
        {
            double   Value;   // In case of cImmed: value of the immed
            unsigned Var;     // In case of cVar:   variable number
            unsigned Funcno;  // In case of cFCall or cPCall
        };
        struct Param
        {
            CodeTreeP param; // param node
            bool      sign;  // true = negated or inverted

            Param()                           : param(),  sign()  {}
            Param(CodeTree*        p, bool s) : param(p), sign(s) {}
            Param(const CodeTreeP& p, bool s) : param(p), sign(s) {}
        };
        // Parameters for the function
        //  These use the sign:
        //   For cAdd: operands to add together (0 to n)
        //             sign indicates that the value is negated before adding (0-x)
        //   For cMul: operands to multiply together (0 to n)
        //             sign indicates that the value is inverted before multiplying (1/x)
        //   For cAnd: operands to bitwise-and together (0 to n)
        //             sign indicates that the value is inverted before anding (!x)
        //   For cOr:  operands to bitwise-or together (0 to n)
        //             sign indicates that the value is inverted before orring (!x)
        //  These don't use the sign (sign is always false):
        //   For cMin: operands to select the minimum of
        //   For cMax: operands to select the maximum of
        //   For cImmed, not used
        //   For cVar,   not used
        //   For cIf:  operand 1 = condition, operand 2 = yes-branch, operand 3 = no-branch
        //   For anything else: the parameters required by the operation/function
        std::vector<Param> Params;

        /* Internal operation */
        uint_fast64_t Hash;
        size_t        Depth;
        CodeTree*     Parent;
    public:
        CodeTree();
        ~CodeTree();

        /* Generates a CodeTree from the given bytecode */
        static CodeTreeP GenerateFrom(
            const std::vector<unsigned>& byteCode,
            const std::vector<double>& immed,
            const FunctionParser::Data& data);

        class ByteCodeSynth;
        void SynthesizeByteCode(
            std::vector<unsigned>& byteCode,
            std::vector<double>&   immed,
            size_t& stacktop_max);
        void SynthesizeByteCode(ByteCodeSynth& synth);

        /* Regenerates the hash.
         * child_triggered=false: Recurse to children
         * child_triggered=true:  Recurse to parents
         */
        void Rehash(bool child_triggered);
        void Recalculate_Hash_NoRecursion();

        void Sort();
        void Sort_Recursive();

        void SetParams(const std::vector<Param>& RefParams);
        void AddParam(const Param& param);
        void DelParam(size_t index);

        /* Clones the tree. (For parameter duplication) */
        CodeTree* Clone();

        bool    IsImmed() const;
        double GetImmed() const { return Value; }
        bool    IsLongIntegerImmed() const { return IsImmed() && GetImmed() == (double)GetLongIntegerImmed(); }
        double GetLongIntegerImmed() const { return (long)GetImmed(); }
        bool      IsVar() const;
        unsigned GetVar() const { return Var; }

        void NegateImmed() { if(IsImmed()) Value = -Value;       }
        void InvertImmed() { if(IsImmed()) Value = 1.0 / Value;  }
        void NotTheImmed() { if(IsImmed()) Value = Value == 0.0; }

    private:
        void ConstantFolding();

    private:
        CodeTree(const CodeTree&);
        CodeTree& operator=(const CodeTree&);
    };

    inline void CodeTreeP::Forget()
    {
        if(!p) return;
        p->RefCount -= 1;
        if(!p->RefCount) delete p;
        //assert(p->RefCount >= 0);
    }
    inline void CodeTreeP::Have(CodeTree* p2)
    {
        if(p2) ++(p2->RefCount);
    }
    inline void CodeTreeP::Birth()
    {
        Have(p);
    }
    inline void CodeTreeP::Set(CodeTree* p2)
    {
        Have(p2);
        Forget();
        p = p2;
    }
}
#include <set>
#include <stdint.h> /* for uint_fast64_t */

namespace FPoptimizer_CodeTree
{
    class CodeTree;
}

namespace FPoptimizer_Grammar
{
    typedef unsigned OpcodeType;

    enum TransformationType
    {
        None,    // default
        Negate,  // 0-x
        Invert   // 1/x
    };

    enum SpecialOpcode
    {
        NumConstant = 0xFFFB, // Holds a particular value (syntax-time constant)
        ImmedHolder,          // Holds a particular immed
        NamedHolder,          // Holds a particular named param (of any kind)
        SubFunction,          // Holds an opcode and the params
        RestHolder            // Holds anything else
      //GroupFunction         // For parse-time functions
    };

    enum ParamMatchingType
    {
        PositionalParams, // this set of params in this order
        SelectedParams,   // this set of params in any order
        AnyParams         // these params are included
    };

    enum RuleType
    {
        ProduceNewTree, // replace self with the first (and only) from replaced_param
        ReplaceParams   // replace indicate params with replaced_params
    };

    /***/

    struct MatchedParams
    {
        ParamMatchingType type : 8;
        // count,index to plist[]
        unsigned         count : 8;
        unsigned         index : 16;

        struct CodeTreeMatch;

        bool Match(FPoptimizer_CodeTree::CodeTree& tree,
                   CodeTreeMatch& match,
                   bool recursion = true) const;

        void ReplaceParams(FPoptimizer_CodeTree::CodeTree& tree,
                           const MatchedParams& matcher, CodeTreeMatch& match) const;

        void ReplaceTree(FPoptimizer_CodeTree::CodeTree& tree,
                         const MatchedParams& matcher, CodeTreeMatch& match) const;

        void SynthesizeTree(
            FPoptimizer_CodeTree::CodeTree& tree,
            const MatchedParams& matcher,
            MatchedParams::CodeTreeMatch& match) const;
    };

    struct ParamSpec
    {
        OpcodeType opcode : 16;
        bool     sign     : 1;
        TransformationType
           transformation  : 3;
        unsigned minrepeat : 3;
        bool     anyrepeat : 1;

        // For NumConstant:   index to clist[]
        // For ImmedHolder:   index is the slot
        // For RestHolder:    index is the slot
        // For NamedHolder:   index is the slot
        // For SubFunction:   index to flist[]
        // For anything else
        //  =  GroupFunction: index,count to plist[]
        unsigned count : 8;
        unsigned index : 16;

        bool Match(
            FPoptimizer_CodeTree::CodeTree& tree,
            MatchedParams::CodeTreeMatch& match) const;

        bool GetConst(
            const MatchedParams::CodeTreeMatch& match,
            double& result) const;

        void SynthesizeTree(
            FPoptimizer_CodeTree::CodeTree& tree,
            const MatchedParams& matcher,
            MatchedParams::CodeTreeMatch& match) const;
    };
    struct Function
    {
        OpcodeType opcode : 16;
        // index to mlist[]
        unsigned   index  : 16;

        bool Match(FPoptimizer_CodeTree::CodeTree& tree,
                   MatchedParams::CodeTreeMatch& match) const;
    };
    struct Rule
    {
        unsigned  n_minimum_params : 8;
        RuleType  type             : 8;
        // index to mlist[]
        unsigned  repl_index       : 16;

        Function  func;

        bool ApplyTo(FPoptimizer_CodeTree::CodeTree& tree) const;
    };
    struct Grammar
    {
        // count,index to rlist[]
        unsigned index : 16;
        unsigned count : 16;

        bool ApplyTo(std::set<uint_fast64_t>& optimized_children,
                     FPoptimizer_CodeTree::CodeTree& tree,
                     bool recursion=false) const;
    };

    extern const struct GrammarPack
    {
        const double*         clist;
        const ParamSpec*      plist;
        const MatchedParams*  mlist;
        const Function*       flist;
        const Rule*           rlist;
        Grammar               glist[3];
    } pack;
}
#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif

#define CONSTANT_E     2.71828182845904509080  // exp(1)
#define CONSTANT_PI    M_PI                    // atan2(0,-1)
#define CONSTANT_L10   2.30258509299404590109  // log(10)
#define CONSTANT_L2    0.69314718055994530943  // log(2)
#define CONSTANT_L10I  0.43429448190325176116  // 1/log(10)
#define CONSTANT_L2I   1.4426950408889634074   // 1/log(2)
#define CONSTANT_L10E  CONSTANT_L10I           // log10(e)
#define CONSTANT_L10EI CONSTANT_L10            // 1/log10(e)
#define CONSTANT_L2E   CONSTANT_L2I            // log2(e)
#define CONSTANT_L2EI  CONSTANT_L2             // 1/log2(e)
#define CONSTANT_DR    (180.0 / M_PI)          // 180/pi
#define CONSTANT_RD    (M_PI / 180.0)          // pi/180


#include <string>

const std::string FP_GetOpcodeName(unsigned opcode, bool pad=false);
/* crc32 */
#include <stdint.h>
typedef uint_least32_t crc32_t;
namespace crc32
{
    enum { startvalue = 0xFFFFFFFFUL, poly = 0xEDB88320UL };

    /* This code constructs the CRC32 table at compile-time,
     * avoiding the need for a huge explicitly written table of magical numbers. */
    template<uint_fast32_t crc> // One byte of a CRC32 (eight bits):
    struct b8
    {
        enum { b1 = (crc & 1) ? (poly ^ (crc >> 1)) : (crc >> 1),
               b2 = (b1  & 1) ? (poly ^ (b1  >> 1)) : (b1  >> 1),
               b3 = (b2  & 1) ? (poly ^ (b2  >> 1)) : (b2  >> 1),
               b4 = (b3  & 1) ? (poly ^ (b3  >> 1)) : (b3  >> 1),
               b5 = (b4  & 1) ? (poly ^ (b4  >> 1)) : (b4  >> 1),
               b6 = (b5  & 1) ? (poly ^ (b5  >> 1)) : (b5  >> 1),
               b7 = (b6  & 1) ? (poly ^ (b6  >> 1)) : (b6  >> 1),
               res= (b7  & 1) ? (poly ^ (b7  >> 1)) : (b7  >> 1) };
    };
    inline uint_fast32_t update(uint_fast32_t crc, unsigned/* char */b) // __attribute__((pure))
    {
        // Four values of the table
        #define B4(n) b8<n>::res,b8<n+1>::res,b8<n+2>::res,b8<n+3>::res
        // Sixteen values of the table
        #define R(n) B4(n),B4(n+4),B4(n+8),B4(n+12)
        // The whole table, index by steps of 16
        static const uint_least32_t table[256] =
        { R(0x00),R(0x10),R(0x20),R(0x30), R(0x40),R(0x50),R(0x60),R(0x70),
          R(0x80),R(0x90),R(0xA0),R(0xB0), R(0xC0),R(0xD0),R(0xE0),R(0xF0) };
        #undef R
        #undef B4
        return ((crc >> 8) /* & 0x00FFFFFF*/) ^ table[/*(unsigned char)*/(crc^b)&0xFF];
    }
    inline crc32_t calc_upd(crc32_t c, const unsigned char* buf, size_t size)
    {
        uint_fast32_t value = c;
        for(size_t p=0; p<size; ++p) value = update(value, buf[p]);
        return value;
    }
    inline crc32_t calc(const unsigned char* buf, size_t size)
    {
        return calc_upd(startvalue, buf, size);
    }
}
#include <string>
#include <sstream>
#include <assert.h>

#include <iostream>

#include "fpconfig.hh"
#include "fptypes.hh"


using namespace FPoptimizer_Grammar;
using namespace FUNCTIONPARSERTYPES;

const std::string FP_GetOpcodeName(unsigned opcode, bool pad)
{
#if 1
    /* Symbolic meanings for the opcodes? */
    const char* p = 0;
    switch(OPCODE(opcode))
    {
        case cAbs: p = "cAbs"; break;
        case cAcos: p = "cAcos"; break;
#ifndef FP_NO_ASINH
        case cAcosh: p = "cAcosh"; break;
#endif
        case cAsin: p = "cAsin"; break;
#ifndef FP_NO_ASINH
        case cAsinh: p = "cAsinh"; break;
#endif
        case cAtan: p = "cAtan"; break;
        case cAtan2: p = "cAtan2"; break;
#ifndef FP_NO_ASINH
        case cAtanh: p = "cAtanh"; break;
#endif
        case cCeil: p = "cCeil"; break;
        case cCos: p = "cCos"; break;
        case cCosh: p = "cCosh"; break;
        case cCot: p = "cCot"; break;
        case cCsc: p = "cCsc"; break;
#ifndef FP_DISABLE_EVAL
        case cEval: p = "cEval"; break;
#endif
        case cExp: p = "cExp"; break;
        case cFloor: p = "cFloor"; break;
        case cIf: p = "cIf"; break;
        case cInt: p = "cInt"; break;
        case cLog: p = "cLog"; break;
        case cLog2: p = "cLog2"; break;
        case cLog10: p = "cLog10"; break;
        case cMax: p = "cMax"; break;
        case cMin: p = "cMin"; break;
        case cPow: p = "cPow"; break;
        case cSec: p = "cSec"; break;
        case cSin: p = "cSin"; break;
        case cSinh: p = "cSinh"; break;
        case cSqrt: p = "cSqrt"; break;
        case cTan: p = "cTan"; break;
        case cTanh: p = "cTanh"; break;
        case cImmed: p = "cImmed"; break;
        case cJump: p = "cJump"; break;
        case cNeg: p = "cNeg"; break;
        case cAdd: p = "cAdd"; break;
        case cSub: p = "cSub"; break;
        case cMul: p = "cMul"; break;
        case cDiv: p = "cDiv"; break;
        case cMod: p = "cMod"; break;
        case cEqual: p = "cEqual"; break;
        case cNEqual: p = "cNEqual"; break;
        case cLess: p = "cLess"; break;
        case cLessOrEq: p = "cLessOrEq"; break;
        case cGreater: p = "cGreater"; break;
        case cGreaterOrEq: p = "cGreaterOrEq"; break;
        case cNot: p = "cNot"; break;
        case cAnd: p = "cAnd"; break;
        case cOr: p = "cOr"; break;
        case cDeg: p = "cDeg"; break;
        case cRad: p = "cRad"; break;
        case cFCall: p = "cFCall"; break;
        case cPCall: p = "cPCall"; break;
#ifdef FP_SUPPORT_OPTIMIZER
        case cVar: p = "cVar"; break;
        case cDup: p = "cDup"; break;
        case cInv: p = "cInv"; break;
        case cFetch: p = "cFetch"; break;
        case cPopNMov: p = "cPopNMov"; break;
        case cSqr: p = "cSqr"; break;
        case cRDiv: p = "cRDiv"; break;
        case cRSub: p = "cRSub"; break;
        case cNotNot: p = "cNotNot"; break;
#endif
        case cNop: p = "cNop"; break;
        case VarBegin: p = "VarBegin"; break;
    }
    switch( SpecialOpcode(opcode) )
    {
        case NumConstant:   p = "NumConstant"; break;
        case ImmedHolder:   p = "ImmedHolder"; break;
        case NamedHolder:   p = "NamedHolder"; break;
        case RestHolder:    p = "RestHolder"; break;
        case SubFunction:   p = "SubFunction"; break;
      //case GroupFunction: p = "GroupFunction"; break;
    }
    std::stringstream tmp;
    //if(!p) std::cerr << "o=" << opcode << "\n";
    assert(p);
    tmp << p;
    if(pad) while(tmp.str().size() < 12) tmp << ' ';
    return tmp.str();
#else
    /* Just numeric meanings */
    std::stringstream tmp;
    tmp << opcode;
    if(pad) while(tmp.str().size() < 5) tmp << ' ';
    return tmp.str();
#endif
}
#include <cmath>
#include <list>
#include <algorithm>

#include "fptypes.hh"



using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;


namespace FPoptimizer_CodeTree
{
    CodeTree::CodeTree()
        : RefCount(0), Opcode(), Params(), Hash(), Depth(1), Parent()
    {
    }

    CodeTree::~CodeTree()
    {
    }

    void CodeTree::Rehash(
        bool child_triggered)
    {
        /* If we were triggered by a parent, recurse to children */
        if(!child_triggered)
        {
            for(size_t a=0; a<Params.size(); ++a)
                Params[a].param->Rehash(false);
        }

        Recalculate_Hash_NoRecursion();

        /* If we were triggered by a child, recurse to the parent */
        if(child_triggered && Parent)
        {
            //assert(Parent->RefCount > 0);
            Parent->Rehash(true);
        }
    }

    struct ParamComparer
    {
        bool operator() (const CodeTree::Param& a, const CodeTree::Param& b) const
        {
            if(a.param->Depth != b.param->Depth)
                return a.param->Depth > b.param->Depth;
            if(a.sign != b.sign) return a.sign < b.sign;
            return a.param->Hash < b.param->Hash;
        }
    };

    void CodeTree::Sort()
    {
        /* If the tree is commutative, order the parameters
         * in a set order in order to make equality tests
         * efficient in the optimizer
         */
        switch(Opcode)
        {
            case cAdd:
            case cMul:
            case cMin:
            case cMax:
            case cAnd:
            case cOr:
            case cEqual:
            case cNEqual:
                std::sort(Params.begin(), Params.end(), ParamComparer());
                break;
            case cLess:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cGreater; }
                break;
            case cLessOrEq:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cGreaterOrEq; }
                break;
            case cGreater:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cLess; }
                break;
            case cGreaterOrEq:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cLessOrEq; }
                break;
        }
    }

    void CodeTree::Sort_Recursive()
    {
        Sort();
        for(size_t a=0; a<Params.size(); ++a)
            Params[a].param->Sort_Recursive();
        Recalculate_Hash_NoRecursion();
    }

    void CodeTree::Recalculate_Hash_NoRecursion()
    {
        Hash = Opcode * 0x3A83A83A83A83A0ULL;
        Depth = 1;
        switch(Opcode)
        {
            case cImmed:
                // FIXME: not portable - we're casting double* into uint_least64_t*
                if(Value != 0.0)
                    Hash ^= *(uint_least64_t*)&Value;
                return; // no params
            case cVar:
                Hash ^= (Var<<24) | (Var>>24);
                return; // no params
            case cFCall: case cPCall:
                Hash ^= (Funcno<<24) | (Funcno>>24);
                break;
        }
        size_t MaxChildDepth = 0;
        for(size_t a=0; a<Params.size(); ++a)
        {
            if(Params[a].param->Depth > MaxChildDepth)
                MaxChildDepth = Params[a].param->Depth;

            Hash += (1+Params[a].sign)*0x2492492492492492ULL;
            Hash *= 1099511628211ULL;
            Hash += Params[a].param->Hash;
        }
        Depth += MaxChildDepth;
    }

    CodeTree* CodeTree::Clone()
    {
        CodeTree* result = new CodeTree;
        result->Opcode = Opcode;
        switch(Opcode)
        {
            case cImmed:
                result->Value  = Value;
                break;
            case cVar:
                result->Var = Var;
                break;
            case cFCall: case cPCall:
                result->Funcno = Funcno;
                break;
        }
        result->SetParams(Params);
        result->Hash   = Hash;
        result->Depth  = Depth;
        //assert(Parent->RefCount > 0);
        result->Parent = Parent;
        return result;
    }

    void CodeTree::AddParam(const Param& param)
    {
        Params.push_back(param);
        Params.back().param->Parent = this;
    }

    void CodeTree::SetParams(const std::vector<Param>& RefParams)
    {
        Params = RefParams;
        /**
        *** Note: The only reason we need to CLONE the children here
        ***       is because they must have the correct Parent field.
        ***       The Parent is required because of backward-recursive
        ***       hash regeneration. Is there any way around this?
        */

        for(size_t a=0; a<Params.size(); ++a)
        {
            Params[a].param = Params[a].param->Clone();
            Params[a].param->Parent = this;
        }
    }

    void CodeTree::DelParam(size_t index)
    {
        Params.erase(Params.begin() + index);
    }
}
/* This file is automatically generated. Do not edit... */
#include "fpconfig.hh"
#include "fptypes.hh"

using namespace FPoptimizer_Grammar;
using namespace FUNCTIONPARSERTYPES;

namespace
{
    const double clist[] =
    {
        3.141592653589793115997963468544185161590576171875, /* 0 */
        0.5, /* 1 */
        0, /* 2 */
        1, /* 3 */
        2.7182818284590450907955982984276488423347473144531, /* 4 */
        0.0 / 0.0, /* 5 */
        0.0 / 0.0, /* 6 */
        -1, /* 7 */
        0, /* 8 */
        0.5, /* 9 */
        1, /* 10 */
        2, /* 11 */
        3.141592653589793115997963468544185161590576171875, /* 12 */
        2.7182818284590450907955982984276488423347473144531, /* 13 */
        0.017453292519943295474371680597869271878153085708618, /* 14 */
        57.29577951308232286464772187173366546630859375, /* 15 */
        0.4342944819032517611567811854911269620060920715332, /* 16 */
        1.4426950408889633870046509400708600878715515136719, /* 17 */
        0.69314718055994528622676398299518041312694549560547, /* 18 */
        2.3025850929940459010936137929093092679977416992188, /* 19 */
    };

    const ParamSpec plist[] =
    {
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 0 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	0	}, /* 1    	*/
        {SubFunction , false, None  , 1, false, 0,	1	}, /* 2    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 3    	*/
        {cAcos       , false, None  , 1, false, 1,	3	}, /* 4    	*/
        {cAcosh      , false, None  , 1, false, 1,	3	}, /* 5    	*/
        {cAsin       , false, None  , 1, false, 1,	3	}, /* 6    	*/
        {cAsinh      , false, None  , 1, false, 1,	3	}, /* 7    	*/
        {cAtan       , false, None  , 1, false, 1,	3	}, /* 8    	*/
        {cAtanh      , false, None  , 1, false, 1,	3	}, /* 9    	*/
        {cCeil       , false, None  , 1, false, 1,	3	}, /* 10    	*/
        {cCos        , false, None  , 1, false, 1,	3	}, /* 11    	*/
        {SubFunction , false, None  , 1, false, 0,	2	}, /* 12    	*/
        {NumConstant , false, None  , 1, false, 0,	0	}, /* 13    	*/
        {NumConstant , false, None  , 1, false, 0,	1	}, /* 14    	*/
        {cMul        , false, None  , 1, false, 2,	13	}, /* 15    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 16 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	3	}, /* 17    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 18    	*/
        {cCosh       , false, None  , 1, false, 1,	3	}, /* 19    	*/
        {cFloor      , false, None  , 1, false, 1,	3	}, /* 20    	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 21    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 22 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 23 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 24    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 25 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 26 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 27 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 28 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 29 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 30 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 31    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 32    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 33 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 34 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 35    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 36 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 37    	*/
        {SubFunction , false, None  , 1, false, 0,	6	}, /* 38    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 39 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	7	}, /* 40    	*/
        {SubFunction , false, None  , 1, false, 0,	8	}, /* 41    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 42 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 43    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 44    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 45 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 46 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	9	}, /* 47    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 48 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 49    	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 50    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 51 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	11	}, /* 52    	*/
        {SubFunction , false, None  , 1, false, 0,	12	}, /* 53    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 54 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 55    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 56    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 57 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 58 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	13	}, /* 59    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 60 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 61    	*/
        {SubFunction , false, None  , 1, false, 0,	14	}, /* 62    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 63 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	15	}, /* 64    	*/
        {SubFunction , false, None  , 1, false, 0,	16	}, /* 65    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 66 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 67    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 68    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 69 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 70 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	17	}, /* 71    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 72 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 73    	*/
        {SubFunction , false, None  , 1, false, 0,	18	}, /* 74    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 75 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	19	}, /* 76    	*/
        {SubFunction , false, None  , 1, false, 0,	20	}, /* 77    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 78 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 79    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 80    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 81 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 82    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 83    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 84 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	21	}, /* 85    	*/
        {SubFunction , false, None  , 1, false, 0,	22	}, /* 86    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 87 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	6	}, /* 88    	*/
        {SubFunction , false, None  , 1, false, 0,	23	}, /* 89    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 90 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	24	}, /* 91    	*/
        {SubFunction , false, None  , 1, false, 0,	25	}, /* 92    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 93 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 94    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 95    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 96 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 97    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 98    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 99 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	26	}, /* 100    	*/
        {SubFunction , false, None  , 1, false, 0,	27	}, /* 101    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 102 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 103    	*/
        {SubFunction , false, None  , 1, false, 0,	28	}, /* 104    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 105 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	29	}, /* 106    	*/
        {SubFunction , false, None  , 1, false, 0,	30	}, /* 107    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 108 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 109    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 110    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 111 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 112    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 113    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 114 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	31	}, /* 115    	*/
        {SubFunction , false, None  , 1, false, 0,	32	}, /* 116    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 117 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	14	}, /* 118    	*/
        {SubFunction , false, None  , 1, false, 0,	33	}, /* 119    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 120 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	34	}, /* 121    	*/
        {SubFunction , false, None  , 1, false, 0,	35	}, /* 122    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 123 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 124    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 125    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 126 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 127    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 128    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 129 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	36	}, /* 130    	*/
        {SubFunction , false, None  , 1, false, 0,	37	}, /* 131    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 132 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	18	}, /* 133    	*/
        {SubFunction , false, None  , 1, false, 0,	38	}, /* 134    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 135 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	39	}, /* 136    	*/
        {SubFunction , false, None  , 1, false, 0,	40	}, /* 137    	*/
        {SubFunction , false, None  , 1, false, 0,	41	}, /* 138    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 139 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 140 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 141 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 142 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 143 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	42	}, /* 144    	*/
        {SubFunction , false, None  , 1, false, 0,	43	}, /* 145    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 146 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 147 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 148 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 149 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 150 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	44	}, /* 151    	*/
        {cLog        , false, None  , 1, false, 1,	3	}, /* 152    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 153 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 154 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	45	}, /* 155    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 156 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 157    	*/
        {SubFunction , false, None  , 1, false, 0,	47	}, /* 158    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 159    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 160 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	48	}, /* 161    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 162    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 163    	*/
        {SubFunction , false, None  , 1, false, 0,	49	}, /* 164    	*/
        {SubFunction , false, None  , 1, false, 0,	50	}, /* 165    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 166 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	51	}, /* 167    	*/
        {NumConstant , false, None  , 1, false, 0,	5	}, /* 168    	*/
        {SubFunction , false, None  , 1, false, 0,	52	}, /* 169    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 170    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 171    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 172    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 173    	*/
        {cMax        , false, None  , 1, false, 2,	172	}, /* 174    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 175 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 176 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	6	}, /* 177    	*/
        {SubFunction , false, None  , 1, false, 0,	53	}, /* 178    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 179    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 180    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 181    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 182    	*/
        {cMin        , false, None  , 1, false, 2,	181	}, /* 183    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 184 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 185 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 186    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 187    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 188    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 189    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 190    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 191    	*/
        {SubFunction , false, None  , 1, false, 0,	54	}, /* 192    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 193 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 194    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 195    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 196    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 197    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 198    	*/
        {cPow        , false, None  , 1, false, 2,	197	}, /* 199    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 200    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 201    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 202    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 203    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 204    	*/
        {SubFunction , false, None  , 1, false, 0,	55	}, /* 205    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 206 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 207    	*/
        {cLog        , true , None  , 1, false, 1,	3	}, /* 208    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 209    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 210    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 211    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 212    	*/
        {SubFunction , false, None  , 1, false, 0,	56	}, /* 213    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 214 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 215    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 216 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	7	}, /* 217    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 218 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	57	}, /* 219    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 220 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	8	}, /* 221    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 222 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 223    	*/
        {SubFunction , true , None  , 1, false, 0,	58	}, /* 224    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 225    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 226    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 227    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 228 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 229    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 230 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 231    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 232 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 233 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	60	}, /* 234    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 235 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 236 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 237 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 238 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	61	}, /* 239    	*/
        {cSin        , false, None  , 1, false, 1,	3	}, /* 240    	*/
        {SubFunction , false, None  , 1, false, 0,	62	}, /* 241    	*/
        {NumConstant , false, None  , 1, false, 0,	0	}, /* 242    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 243    	*/
        {cMul        , false, None  , 1, false, 2,	242	}, /* 244    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 245 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	63	}, /* 246    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 247    	*/
        {cSinh       , false, None  , 1, false, 1,	3	}, /* 248    	*/
        {cTan        , false, None  , 1, false, 1,	3	}, /* 249    	*/
        {SubFunction , false, None  , 1, false, 0,	65	}, /* 250    	*/
        {cTanh       , false, None  , 1, false, 1,	3	}, /* 251    	*/
        {SubFunction , false, None  , 1, false, 0,	66	}, /* 252    	*/
        {ImmedHolder , true , None  , 1, false, 0,	0	}, /* 253    	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 254    	*/
        {SubFunction , true , None  , 1, false, 0,	66	}, /* 255    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 256    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 257    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 258    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 259    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 260    	*/
        {SubFunction , true , None  , 1, false, 0,	67	}, /* 261    	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 262    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 263    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 264    	*/
        {SubFunction , false, None  , 1, false, 0,	68	}, /* 265    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 266    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 267    	*/
        {NumConstant , false, None  , 1, false, 0,	10	}, /* 268    	*/
        {SubFunction , true , None  , 1, false, 0,	69	}, /* 269    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 270    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 271    	*/
        {SubFunction , false, None  , 1, false, 0,	70	}, /* 272    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 273    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 274    	*/
        {NumConstant , false, None  , 1, false, 0,	10	}, /* 275    	*/
        {SubFunction , true , None  , 1, false, 0,	71	}, /* 276    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 277    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 278    	*/
        {SubFunction , false, None  , 1, false, 0,	72	}, /* 279    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 280    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 281    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 282    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 283    	*/
        {cAdd        , false, None  , 1, false, 2,	282	}, /* 284    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 285 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 286 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 287    	*/
        {SubFunction , false, None  , 1, false, 0,	73	}, /* 288    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 289 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 290 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	74	}, /* 291    	*/
        {SubFunction , false, None  , 1, false, 0,	75	}, /* 292    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 293    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 294    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 295    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 296    	*/
        {SubFunction , false, None  , 1, false, 0,	76	}, /* 297    	*/
        {SubFunction , false, None  , 1, false, 0,	77	}, /* 298    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 299 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 300    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 301    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 302 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 303    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 304    	*/
        {SubFunction , false, None  , 1, false, 0,	78	}, /* 305    	*/
        {SubFunction , false, None  , 1, false, 0,	79	}, /* 306    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 307    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 308    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 309    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 310    	*/
        {SubFunction , false, None  , 1, false, 0,	80	}, /* 311    	*/
        {SubFunction , false, None  , 1, false, 0,	81	}, /* 312    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 313 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	82	}, /* 314    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 315    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 316 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 317    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 318    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 319 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 320    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 321    	*/
        {SubFunction , false, None  , 1, false, 0,	84	}, /* 322    	*/
        {SubFunction , true , None  , 1, false, 0,	85	}, /* 323    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 324    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 325    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 326    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 327    	*/
        {SubFunction , false, None  , 1, false, 0,	86	}, /* 328    	*/
        {SubFunction , true , None  , 1, false, 0,	87	}, /* 329    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 330 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	88	}, /* 331    	*/
        {SubFunction , false, None  , 1, false, 0,	89	}, /* 332    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 333    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 334    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 335    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 336    	*/
        {SubFunction , false, None  , 1, false, 0,	91	}, /* 337    	*/
        {SubFunction , false, None  , 1, false, 0,	93	}, /* 338    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 339 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 340 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	94	}, /* 341    	*/
        {SubFunction , false, None  , 1, false, 0,	95	}, /* 342    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 343    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 344    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 345    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 346    	*/
        {SubFunction , false, None  , 1, false, 0,	96	}, /* 347    	*/
        {SubFunction , true , None  , 1, false, 0,	97	}, /* 348    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 349 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 350 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	98	}, /* 351    	*/
        {SubFunction , false, None  , 1, false, 0,	99	}, /* 352    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 353    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 354    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 355    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 356    	*/
        {SubFunction , false, None  , 1, false, 0,	100	}, /* 357    	*/
        {SubFunction , false, None  , 1, false, 0,	101	}, /* 358    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 359 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 360 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	102	}, /* 361    	*/
        {SubFunction , false, None  , 1, false, 0,	103	}, /* 362    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 363    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 364    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 365    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 366    	*/
        {SubFunction , false, None  , 1, false, 0,	104	}, /* 367    	*/
        {SubFunction , true , None  , 1, false, 0,	105	}, /* 368    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 369 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 370 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	106	}, /* 371    	*/
        {SubFunction , false, None  , 1, false, 0,	107	}, /* 372    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 373 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 374    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 375    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 376 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	108	}, /* 377    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 378 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 379    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 380 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	109	}, /* 381    	*/
        {SubFunction , false, None  , 1, false, 0,	110	}, /* 382    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 383 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 384    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 385    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 386 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	111	}, /* 387    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 388 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	10	}, /* 389    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 390 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	112	}, /* 391    	*/
        {SubFunction , false, None  , 1, false, 0,	113	}, /* 392    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 393 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 394    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 395    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 396 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 397    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 398    	*/
        {SubFunction , true , None  , 1, false, 0,	114	}, /* 399    	*/
        {SubFunction , true , None  , 1, false, 0,	115	}, /* 400    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 401    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 402    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 403    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 404    	*/
        {SubFunction , true , None  , 1, false, 0,	116	}, /* 405    	*/
        {SubFunction , true , None  , 1, false, 0,	117	}, /* 406    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 407 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	118	}, /* 408    	*/
        {SubFunction , false, None  , 1, false, 0,	119	}, /* 409    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 410    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 411    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 412    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 413    	*/
        {SubFunction , true , None  , 1, false, 0,	120	}, /* 414    	*/
        {SubFunction , false, None  , 1, false, 0,	121	}, /* 415    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 416 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 417 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	122	}, /* 418    	*/
        {SubFunction , true , None  , 1, false, 0,	123	}, /* 419    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 420    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 421    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 422    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 423    	*/
        {SubFunction , true , None  , 1, false, 0,	124	}, /* 424    	*/
        {SubFunction , true , None  , 1, false, 0,	125	}, /* 425    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 426 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 427 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	126	}, /* 428    	*/
        {SubFunction , true , None  , 1, false, 0,	127	}, /* 429    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 430    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 431    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 432    	*/
        {SubFunction , false, None  , 1, false, 0,	92	}, /* 433    	*/
        {SubFunction , true , None  , 1, false, 0,	128	}, /* 434    	*/
        {SubFunction , true , None  , 1, false, 0,	129	}, /* 435    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 436 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 437 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	130	}, /* 438    	*/
        {SubFunction , true , None  , 1, false, 0,	131	}, /* 439    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 440 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 441    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 442    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 443 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	132	}, /* 444    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 445 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 446    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 447 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	133	}, /* 448    	*/
        {SubFunction , false, None  , 1, false, 0,	134	}, /* 449    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 450 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 451    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 452    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 453 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	135	}, /* 454    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 455 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	10	}, /* 456    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 457 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	136	}, /* 458    	*/
        {SubFunction , false, None  , 1, false, 0,	137	}, /* 459    	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 460 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 461 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 462 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	138	}, /* 463    	*/
        {NamedHolder , true , None  , 2, true , 0,	0	}, /* 464 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 465 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 466 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	139	}, /* 467    	*/
        {NumConstant , false, None  , 1, false, 0,	12	}, /* 468    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 469    	*/
        {cMul        , false, None  , 1, false, 2,	468	}, /* 470    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 471 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	140	}, /* 472    	*/
        {SubFunction , true , None  , 1, false, 0,	141	}, /* 473    	*/
        {SubFunction , false, None  , 1, false, 0,	142	}, /* 474    	*/
        {SubFunction , false, None  , 1, false, 0,	143	}, /* 475    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 476 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 477    	*/
        {SubFunction , true , None  , 1, false, 0,	144	}, /* 478    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 479 "x"	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 480    	*/
        {SubFunction , false, None  , 1, false, 0,	145	}, /* 481    	*/
        {SubFunction , true , None  , 1, false, 0,	143	}, /* 482    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 483    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 484    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 485    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 486    	*/
        {cMul        , false, None  , 1, false, 2,	485	}, /* 487    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 488    	*/
        {ImmedHolder , true , None  , 1, false, 0,	1	}, /* 489    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 490    	*/
        {ImmedHolder , false, Invert, 1, false, 0,	1	}, /* 491    	*/
        {cMul        , false, None  , 1, false, 2,	490	}, /* 492    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 493 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 494 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 495    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 496 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	146	}, /* 497    	*/
        {SubFunction , false, None  , 1, false, 0,	147	}, /* 498    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 499    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 500    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 501 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	148	}, /* 502    	*/
        {SubFunction , false, None  , 1, false, 0,	149	}, /* 503    	*/
        {cLog        , true , None  , 1, false, 1,	3	}, /* 504    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 505 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 506 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	150	}, /* 507    	*/
        {SubFunction , false, None  , 1, false, 0,	151	}, /* 508    	*/
        {SubFunction , true , None  , 1, false, 0,	46	}, /* 509    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 510    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 511 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 512 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	152	}, /* 513    	*/
        {SubFunction , false, None  , 1, false, 0,	153	}, /* 514    	*/
        {SubFunction , false, None  , 1, false, 0,	154	}, /* 515    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 516    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 517    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 518    	*/
        {SubFunction , false, None  , 1, false, 0,	155	}, /* 519    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 520 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	156	}, /* 521    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 522    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 523 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 524 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	157	}, /* 525    	*/
        {SubFunction , false, None  , 1, false, 0,	158	}, /* 526    	*/
        {SubFunction , false, None  , 1, false, 0,	159	}, /* 527    	*/
        {cLog        , true , None  , 1, false, 1,	3	}, /* 528    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 529    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 530    	*/
        {SubFunction , false, None  , 1, false, 0,	160	}, /* 531    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 532 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	161	}, /* 533    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 534 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 535 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 536 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	162	}, /* 537    	*/
        {SubFunction , false, None  , 1, false, 0,	163	}, /* 538    	*/
        {SubFunction , false, None  , 1, false, 0,	164	}, /* 539    	*/
        {SubFunction , true , None  , 1, false, 0,	58	}, /* 540    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 541    	*/
        {SubFunction , true , None  , 1, false, 0,	58	}, /* 542    	*/
        {SubFunction , false, None  , 1, false, 0,	165	}, /* 543    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 544 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	166	}, /* 545    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 546 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 547 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 548 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 549 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	167	}, /* 550    	*/
        {SubFunction , false, None  , 1, false, 0,	168	}, /* 551    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 552 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 553 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 554 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	169	}, /* 555    	*/
        {SubFunction , false, None  , 1, false, 0,	170	}, /* 556    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 557 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 558 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 559 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 560 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	171	}, /* 561    	*/
        {SubFunction , true , None  , 1, false, 0,	172	}, /* 562    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 563 "y"	*/
        {NamedHolder , true , None  , 1, false, 0,	2	}, /* 564 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 565 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	173	}, /* 566    	*/
        {SubFunction , false, None  , 1, false, 0,	174	}, /* 567    	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 568    	*/
        {SubFunction , true , None  , 1, false, 0,	64	}, /* 569    	*/
        {SubFunction , false, None  , 1, false, 0,	175	}, /* 570    	*/
        {SubFunction , true , None  , 1, false, 0,	176	}, /* 571    	*/
        {SubFunction , false, None  , 1, false, 0,	177	}, /* 572    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 573 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 574    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 575 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	178	}, /* 576    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 577 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 578    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 579 "x"	*/
        {cAdd        , false, None  , 1, false, 2,	577	}, /* 580    	*/
        {SubFunction , false, None  , 1, false, 0,	179	}, /* 581    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 582 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 583    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 584 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	180	}, /* 585    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 586 "x"	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 587    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 588 "x"	*/
        {cAdd        , false, None  , 1, false, 2,	586	}, /* 589    	*/
        {SubFunction , false, None  , 1, false, 0,	181	}, /* 590    	*/
        {ImmedHolder , true , None  , 1, false, 0,	0	}, /* 591    	*/
        {ImmedHolder , true , None  , 1, false, 0,	1	}, /* 592    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 593    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 594    	*/
        {cMul        , true , None  , 1, false, 2,	593	}, /* 595    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 596    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 597 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	182	}, /* 598    	*/
        {SubFunction , true , None  , 1, false, 0,	183	}, /* 599    	*/
        {cLog        , false, None  , 1, false, 1,	3	}, /* 600    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 601 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 602 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	184	}, /* 603    	*/
        {SubFunction , true , None  , 1, false, 0,	185	}, /* 604    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 605    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 606 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 607 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 608 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 609 "z"	*/
        {SubFunction , true , None  , 1, false, 0,	186	}, /* 610    	*/
        {SubFunction , true , None  , 1, false, 0,	187	}, /* 611    	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 612 "y"	*/
        {NamedHolder , true , None  , 1, false, 0,	2	}, /* 613 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 614 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	188	}, /* 615    	*/
        {SubFunction , false, None  , 1, false, 0,	189	}, /* 616    	*/
        {SubFunction , true , None  , 1, false, 0,	4	}, /* 617    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 618    	*/
        {SubFunction , true , None  , 1, false, 0,	142	}, /* 619    	*/
        {SubFunction , true , None  , 1, false, 0,	175	}, /* 620    	*/
        {SubFunction , false, None  , 1, false, 0,	176	}, /* 621    	*/
        {SubFunction , true , None  , 1, false, 0,	177	}, /* 622    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 623 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 624    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 625 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	190	}, /* 626    	*/
        {NamedHolder , false, Negate, 1, true , 0,	0	}, /* 627 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 628    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 629 "x"	*/
        {cAdd        , false, None  , 1, false, 2,	627	}, /* 630    	*/
        {SubFunction , false, None  , 1, false, 0,	191	}, /* 631    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 632 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 633    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 634 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	192	}, /* 635    	*/
        {NamedHolder , false, Negate, 1, true , 0,	0	}, /* 636 "x"	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 637    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 638 "x"	*/
        {cAdd        , false, None  , 1, false, 2,	636	}, /* 639    	*/
        {SubFunction , false, None  , 1, false, 0,	193	}, /* 640    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 641 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 642 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	194	}, /* 643    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 644 "x"	*/
        {NamedHolder , false, Negate, 2, true , 0,	0	}, /* 645 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	195	}, /* 646    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 647    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 648    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 649    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 650    	*/
        {cMod        , false, None  , 1, false, 2,	649	}, /* 651    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 652 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 653 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 654 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 655 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 656 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 657 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 658 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 659 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 660 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 661 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 662 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 663 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 664 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 665 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	196	}, /* 666    	*/
        {SubFunction , false, None  , 1, false, 0,	197	}, /* 667    	*/
        {SubFunction , false, None  , 1, false, 0,	198	}, /* 668    	*/
        {SubFunction , false, None  , 1, false, 0,	199	}, /* 669    	*/
        {SubFunction , false, None  , 1, false, 0,	200	}, /* 670    	*/
        {SubFunction , false, None  , 1, false, 0,	201	}, /* 671    	*/
        {SubFunction , false, None  , 1, false, 0,	202	}, /* 672    	*/
        {SubFunction , true , None  , 1, false, 0,	196	}, /* 673    	*/
        {SubFunction , true , None  , 1, false, 0,	197	}, /* 674    	*/
        {SubFunction , true , None  , 1, false, 0,	198	}, /* 675    	*/
        {SubFunction , true , None  , 1, false, 0,	200	}, /* 676    	*/
        {SubFunction , true , None  , 1, false, 0,	201	}, /* 677    	*/
        {SubFunction , true , None  , 1, false, 0,	199	}, /* 678    	*/
        {SubFunction , true , None  , 1, false, 0,	0	}, /* 679    	*/
        {SubFunction , true , None  , 1, false, 0,	202	}, /* 680    	*/
        {SubFunction , true , None  , 1, false, 0,	1	}, /* 681    	*/
        {NamedHolder , true , None  , 1, false, 0,	3	}, /* 682 "a"	*/
        {NamedHolder , true , None  , 1, false, 0,	4	}, /* 683 "b"	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 684    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 685 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 686 "b"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 687    	*/
        {SubFunction , true , None  , 1, false, 0,	203	}, /* 688    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 689 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 690 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 691 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 692 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	204	}, /* 693    	*/
        {SubFunction , false, None  , 1, false, 0,	205	}, /* 694    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 695 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 696 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 697 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 698 "c"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 699 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 700 "c"	*/
        {SubFunction , false, None  , 1, false, 0,	204	}, /* 701    	*/
        {SubFunction , false, None  , 1, false, 0,	206	}, /* 702    	*/
        {SubFunction , false, None  , 1, false, 0,	207	}, /* 703    	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 704 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 705 "c"	*/
        {SubFunction , false, None  , 1, false, 0,	196	}, /* 706    	*/
        {SubFunction , false, None  , 1, false, 0,	208	}, /* 707    	*/
        {SubFunction , false, None  , 1, false, 0,	209	}, /* 708    	*/
        {SubFunction , true , None  , 1, false, 0,	209	}, /* 709    	*/
        {NamedHolder , true , None  , 1, false, 0,	3	}, /* 710 "a"	*/
        {NamedHolder , true , None  , 1, false, 0,	4	}, /* 711 "b"	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 712    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 713 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 714 "b"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 715    	*/
        {SubFunction , true , None  , 1, false, 0,	210	}, /* 716    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 717 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 718 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 719 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 720 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 721 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 722 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	211	}, /* 723    	*/
        {NumConstant , false, None  , 1, false, 0,	13	}, /* 724    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 725 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	212	}, /* 726    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 727 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 728    	*/
        {SubFunction , false, None  , 1, false, 0,	213	}, /* 729    	*/
        {NumConstant , false, None  , 1, false, 0,	14	}, /* 730    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 731    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 732    	*/
        {SubFunction , false, None  , 1, false, 0,	214	}, /* 733    	*/
        {NumConstant , false, None  , 1, false, 0,	15	}, /* 734    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 735    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 736    	*/
        {SubFunction , false, None  , 1, false, 0,	215	}, /* 737    	*/
        {NumConstant , true , None  , 1, false, 0,	14	}, /* 738    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 739    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 740    	*/
        {NumConstant , true , None  , 1, false, 0,	15	}, /* 741    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 742    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 743    	*/
        {SubFunction , false, None  , 1, false, 0,	216	}, /* 744    	*/
        {SubFunction , false, None  , 1, false, 0,	217	}, /* 745    	*/
        {SubFunction , false, None  , 1, false, 0,	218	}, /* 746    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 747    	*/
        {NumConstant , false, None  , 1, false, 0,	16	}, /* 748    	*/
        {SubFunction , false, None  , 1, false, 0,	219	}, /* 749    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 750    	*/
        {NumConstant , false, None  , 1, false, 0,	17	}, /* 751    	*/
        {SubFunction , false, None  , 1, false, 0,	220	}, /* 752    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 753    	*/
        {NumConstant , true , None  , 1, false, 0,	18	}, /* 754    	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 755    	*/
        {NumConstant , true , None  , 1, false, 0,	19	}, /* 756    	*/
        {SubFunction , true , None  , 1, false, 0,	46	}, /* 757    	*/
        {NumConstant , false, None  , 1, false, 0,	18	}, /* 758    	*/
        {SubFunction , true , None  , 1, false, 0,	220	}, /* 759    	*/
        {SubFunction , true , None  , 1, false, 0,	46	}, /* 760    	*/
        {NumConstant , false, None  , 1, false, 0,	19	}, /* 761    	*/
        {SubFunction , true , None  , 1, false, 0,	219	}, /* 762    	*/
        {SubFunction , true , None  , 1, false, 0,	46	}, /* 763    	*/
        {NumConstant , true , None  , 1, false, 0,	16	}, /* 764    	*/
        {SubFunction , true , None  , 1, false, 0,	46	}, /* 765    	*/
        {NumConstant , true , None  , 1, false, 0,	17	}, /* 766    	*/
        {SubFunction , false, None  , 1, false, 0,	221	}, /* 767    	*/
    };

    const MatchedParams mlist[] =
    {
        {PositionalParams, 1, 0 }, /* 0 */
        {PositionalParams, 1, 1 }, /* 1 */
        {PositionalParams, 1, 2 }, /* 2 */
        {PositionalParams, 1, 3 }, /* 3 */
        {PositionalParams, 1, 4 }, /* 4 */
        {PositionalParams, 1, 5 }, /* 5 */
        {PositionalParams, 1, 6 }, /* 6 */
        {PositionalParams, 1, 7 }, /* 7 */
        {PositionalParams, 1, 8 }, /* 8 */
        {PositionalParams, 1, 9 }, /* 9 */
        {PositionalParams, 1, 10 }, /* 10 */
        {PositionalParams, 1, 11 }, /* 11 */
        {PositionalParams, 1, 12 }, /* 12 */
        {AnyParams       , 2, 15 }, /* 13 */
        {PositionalParams, 1, 17 }, /* 14 */
        {PositionalParams, 1, 18 }, /* 15 */
        {PositionalParams, 1, 19 }, /* 16 */
        {PositionalParams, 1, 20 }, /* 17 */
        {PositionalParams, 3, 21 }, /* 18 */
        {PositionalParams, 1, 23 }, /* 19 */
        {PositionalParams, 3, 24 }, /* 20 */
        {PositionalParams, 3, 27 }, /* 21 */
        {AnyParams       , 3, 30 }, /* 22 */
        {PositionalParams, 3, 33 }, /* 23 */
        {PositionalParams, 2, 31 }, /* 24 */
        {PositionalParams, 3, 36 }, /* 25 */
        {PositionalParams, 2, 39 }, /* 26 */
        {PositionalParams, 1, 41 }, /* 27 */
        {AnyParams       , 3, 42 }, /* 28 */
        {PositionalParams, 3, 45 }, /* 29 */
        {PositionalParams, 3, 48 }, /* 30 */
        {PositionalParams, 2, 51 }, /* 31 */
        {PositionalParams, 1, 53 }, /* 32 */
        {AnyParams       , 3, 54 }, /* 33 */
        {PositionalParams, 3, 57 }, /* 34 */
        {PositionalParams, 3, 60 }, /* 35 */
        {PositionalParams, 2, 63 }, /* 36 */
        {PositionalParams, 1, 65 }, /* 37 */
        {AnyParams       , 3, 66 }, /* 38 */
        {PositionalParams, 3, 69 }, /* 39 */
        {PositionalParams, 3, 72 }, /* 40 */
        {PositionalParams, 2, 75 }, /* 41 */
        {PositionalParams, 1, 77 }, /* 42 */
        {AnyParams       , 3, 78 }, /* 43 */
        {AnyParams       , 3, 81 }, /* 44 */
        {PositionalParams, 3, 84 }, /* 45 */
        {PositionalParams, 2, 82 }, /* 46 */
        {PositionalParams, 3, 87 }, /* 47 */
        {PositionalParams, 2, 90 }, /* 48 */
        {PositionalParams, 1, 92 }, /* 49 */
        {AnyParams       , 3, 93 }, /* 50 */
        {AnyParams       , 3, 96 }, /* 51 */
        {PositionalParams, 3, 99 }, /* 52 */
        {PositionalParams, 3, 102 }, /* 53 */
        {PositionalParams, 2, 105 }, /* 54 */
        {PositionalParams, 1, 107 }, /* 55 */
        {AnyParams       , 3, 108 }, /* 56 */
        {AnyParams       , 3, 111 }, /* 57 */
        {PositionalParams, 3, 114 }, /* 58 */
        {PositionalParams, 3, 117 }, /* 59 */
        {PositionalParams, 2, 120 }, /* 60 */
        {PositionalParams, 1, 122 }, /* 61 */
        {AnyParams       , 3, 123 }, /* 62 */
        {AnyParams       , 3, 126 }, /* 63 */
        {PositionalParams, 3, 129 }, /* 64 */
        {PositionalParams, 3, 132 }, /* 65 */
        {PositionalParams, 2, 135 }, /* 66 */
        {PositionalParams, 1, 137 }, /* 67 */
        {AnyParams       , 1, 0 }, /* 68 */
        {PositionalParams, 3, 138 }, /* 69 */
        {PositionalParams, 3, 141 }, /* 70 */
        {PositionalParams, 1, 144 }, /* 71 */
        {PositionalParams, 3, 145 }, /* 72 */
        {PositionalParams, 3, 148 }, /* 73 */
        {PositionalParams, 1, 151 }, /* 74 */
        {PositionalParams, 1, 152 }, /* 75 */
        {PositionalParams, 2, 153 }, /* 76 */
        {PositionalParams, 1, 155 }, /* 77 */
        {PositionalParams, 2, 156 }, /* 78 */
        {PositionalParams, 1, 158 }, /* 79 */
        {PositionalParams, 2, 159 }, /* 80 */
        {AnyParams       , 3, 161 }, /* 81 */
        {PositionalParams, 1, 164 }, /* 82 */
        {PositionalParams, 1, 50 }, /* 83 */
        {PositionalParams, 2, 165 }, /* 84 */
        {PositionalParams, 1, 167 }, /* 85 */
        {PositionalParams, 0, 0 }, /* 86 */
        {PositionalParams, 1, 168 }, /* 87 */
        {AnyParams       , 1, 31 }, /* 88 */
        {AnyParams       , 1, 169 }, /* 89 */
        {PositionalParams, 1, 31 }, /* 90 */
        {AnyParams       , 2, 170 }, /* 91 */
        {PositionalParams, 1, 174 }, /* 92 */
        {AnyParams       , 2, 175 }, /* 93 */
        {PositionalParams, 1, 177 }, /* 94 */
        {AnyParams       , 1, 178 }, /* 95 */
        {AnyParams       , 2, 179 }, /* 96 */
        {PositionalParams, 1, 183 }, /* 97 */
        {AnyParams       , 2, 184 }, /* 98 */
        {PositionalParams, 2, 186 }, /* 99 */
        {AnyParams       , 3, 188 }, /* 100 */
        {PositionalParams, 2, 191 }, /* 101 */
        {PositionalParams, 2, 193 }, /* 102 */
        {PositionalParams, 2, 195 }, /* 103 */
        {PositionalParams, 1, 199 }, /* 104 */
        {AnyParams       , 4, 200 }, /* 105 */
        {PositionalParams, 2, 204 }, /* 106 */
        {PositionalParams, 2, 206 }, /* 107 */
        {AnyParams       , 4, 208 }, /* 108 */
        {PositionalParams, 2, 212 }, /* 109 */
        {PositionalParams, 2, 214 }, /* 110 */
        {PositionalParams, 2, 216 }, /* 111 */
        {PositionalParams, 1, 218 }, /* 112 */
        {PositionalParams, 1, 219 }, /* 113 */
        {PositionalParams, 2, 220 }, /* 114 */
        {PositionalParams, 1, 24 }, /* 115 */
        {PositionalParams, 2, 222 }, /* 116 */
        {PositionalParams, 1, 140 }, /* 117 */
        {AnyParams       , 4, 224 }, /* 118 */
        {PositionalParams, 2, 228 }, /* 119 */
        {PositionalParams, 2, 230 }, /* 120 */
        {PositionalParams, 2, 232 }, /* 121 */
        {PositionalParams, 2, 234 }, /* 122 */
        {PositionalParams, 2, 236 }, /* 123 */
        {PositionalParams, 2, 238 }, /* 124 */
        {PositionalParams, 1, 240 }, /* 125 */
        {PositionalParams, 1, 241 }, /* 126 */
        {AnyParams       , 2, 244 }, /* 127 */
        {PositionalParams, 1, 246 }, /* 128 */
        {PositionalParams, 1, 247 }, /* 129 */
        {PositionalParams, 1, 248 }, /* 130 */
        {PositionalParams, 1, 249 }, /* 131 */
        {PositionalParams, 1, 250 }, /* 132 */
        {PositionalParams, 1, 251 }, /* 133 */
        {PositionalParams, 1, 221 }, /* 134 */
        {AnyParams       , 1, 221 }, /* 135 */
        {AnyParams       , 2, 31 }, /* 136 */
        {AnyParams       , 1, 252 }, /* 137 */
        {AnyParams       , 1, 253 }, /* 138 */
        {PositionalParams, 1, 254 }, /* 139 */
        {AnyParams       , 1, 255 }, /* 140 */
        {PositionalParams, 2, 256 }, /* 141 */
        {AnyParams       , 3, 258 }, /* 142 */
        {AnyParams       , 1, 261 }, /* 143 */
        {PositionalParams, 3, 262 }, /* 144 */
        {PositionalParams, 1, 265 }, /* 145 */
        {PositionalParams, 2, 266 }, /* 146 */
        {AnyParams       , 2, 268 }, /* 147 */
        {PositionalParams, 2, 270 }, /* 148 */
        {PositionalParams, 1, 272 }, /* 149 */
        {PositionalParams, 2, 273 }, /* 150 */
        {AnyParams       , 2, 275 }, /* 151 */
        {PositionalParams, 2, 277 }, /* 152 */
        {PositionalParams, 1, 279 }, /* 153 */
        {AnyParams       , 2, 280 }, /* 154 */
        {PositionalParams, 1, 284 }, /* 155 */
        {AnyParams       , 2, 285 }, /* 156 */
        {AnyParams       , 2, 287 }, /* 157 */
        {PositionalParams, 2, 289 }, /* 158 */
        {PositionalParams, 1, 291 }, /* 159 */
        {PositionalParams, 1, 292 }, /* 160 */
        {PositionalParams, 2, 293 }, /* 161 */
        {PositionalParams, 2, 295 }, /* 162 */
        {AnyParams       , 2, 297 }, /* 163 */
        {PositionalParams, 1, 268 }, /* 164 */
        {AnyParams       , 3, 299 }, /* 165 */
        {AnyParams       , 3, 302 }, /* 166 */
        {AnyParams       , 2, 305 }, /* 167 */
        {PositionalParams, 2, 307 }, /* 168 */
        {PositionalParams, 2, 309 }, /* 169 */
        {PositionalParams, 2, 311 }, /* 170 */
        {PositionalParams, 2, 313 }, /* 171 */
        {PositionalParams, 1, 315 }, /* 172 */
        {AnyParams       , 3, 316 }, /* 173 */
        {AnyParams       , 3, 319 }, /* 174 */
        {AnyParams       , 2, 322 }, /* 175 */
        {PositionalParams, 2, 324 }, /* 176 */
        {PositionalParams, 2, 326 }, /* 177 */
        {PositionalParams, 2, 328 }, /* 178 */
        {PositionalParams, 2, 330 }, /* 179 */
        {PositionalParams, 1, 332 }, /* 180 */
        {SelectedParams  , 2, 333 }, /* 181 */
        {SelectedParams  , 2, 335 }, /* 182 */
        {AnyParams       , 2, 337 }, /* 183 */
        {PositionalParams, 2, 339 }, /* 184 */
        {PositionalParams, 1, 341 }, /* 185 */
        {PositionalParams, 1, 342 }, /* 186 */
        {SelectedParams  , 2, 343 }, /* 187 */
        {SelectedParams  , 2, 345 }, /* 188 */
        {AnyParams       , 2, 347 }, /* 189 */
        {PositionalParams, 2, 349 }, /* 190 */
        {PositionalParams, 1, 351 }, /* 191 */
        {PositionalParams, 1, 352 }, /* 192 */
        {SelectedParams  , 2, 353 }, /* 193 */
        {SelectedParams  , 2, 355 }, /* 194 */
        {AnyParams       , 2, 357 }, /* 195 */
        {PositionalParams, 2, 359 }, /* 196 */
        {PositionalParams, 1, 361 }, /* 197 */
        {PositionalParams, 1, 362 }, /* 198 */
        {SelectedParams  , 2, 363 }, /* 199 */
        {SelectedParams  , 2, 365 }, /* 200 */
        {AnyParams       , 2, 367 }, /* 201 */
        {PositionalParams, 2, 369 }, /* 202 */
        {PositionalParams, 1, 371 }, /* 203 */
        {PositionalParams, 1, 372 }, /* 204 */
        {AnyParams       , 3, 373 }, /* 205 */
        {AnyParams       , 2, 376 }, /* 206 */
        {PositionalParams, 2, 378 }, /* 207 */
        {PositionalParams, 2, 380 }, /* 208 */
        {PositionalParams, 1, 382 }, /* 209 */
        {AnyParams       , 3, 383 }, /* 210 */
        {AnyParams       , 2, 386 }, /* 211 */
        {PositionalParams, 2, 388 }, /* 212 */
        {PositionalParams, 2, 390 }, /* 213 */
        {PositionalParams, 1, 392 }, /* 214 */
        {AnyParams       , 3, 393 }, /* 215 */
        {AnyParams       , 3, 396 }, /* 216 */
        {AnyParams       , 2, 399 }, /* 217 */
        {PositionalParams, 2, 401 }, /* 218 */
        {PositionalParams, 2, 403 }, /* 219 */
        {PositionalParams, 2, 405 }, /* 220 */
        {PositionalParams, 2, 407 }, /* 221 */
        {PositionalParams, 1, 409 }, /* 222 */
        {SelectedParams  , 2, 410 }, /* 223 */
        {SelectedParams  , 2, 412 }, /* 224 */
        {AnyParams       , 2, 414 }, /* 225 */
        {PositionalParams, 2, 416 }, /* 226 */
        {PositionalParams, 1, 418 }, /* 227 */
        {PositionalParams, 1, 419 }, /* 228 */
        {SelectedParams  , 2, 420 }, /* 229 */
        {SelectedParams  , 2, 422 }, /* 230 */
        {AnyParams       , 2, 424 }, /* 231 */
        {PositionalParams, 2, 426 }, /* 232 */
        {PositionalParams, 1, 428 }, /* 233 */
        {PositionalParams, 1, 429 }, /* 234 */
        {SelectedParams  , 2, 430 }, /* 235 */
        {SelectedParams  , 2, 432 }, /* 236 */
        {AnyParams       , 2, 434 }, /* 237 */
        {PositionalParams, 2, 436 }, /* 238 */
        {PositionalParams, 1, 438 }, /* 239 */
        {PositionalParams, 1, 439 }, /* 240 */
        {AnyParams       , 3, 440 }, /* 241 */
        {AnyParams       , 2, 443 }, /* 242 */
        {PositionalParams, 2, 445 }, /* 243 */
        {PositionalParams, 2, 447 }, /* 244 */
        {PositionalParams, 1, 449 }, /* 245 */
        {AnyParams       , 3, 450 }, /* 246 */
        {AnyParams       , 2, 453 }, /* 247 */
        {PositionalParams, 2, 455 }, /* 248 */
        {PositionalParams, 2, 457 }, /* 249 */
        {PositionalParams, 1, 459 }, /* 250 */
        {AnyParams       , 1, 460 }, /* 251 */
        {PositionalParams, 2, 461 }, /* 252 */
        {PositionalParams, 1, 463 }, /* 253 */
        {AnyParams       , 1, 464 }, /* 254 */
        {PositionalParams, 2, 465 }, /* 255 */
        {PositionalParams, 1, 467 }, /* 256 */
        {AnyParams       , 2, 470 }, /* 257 */
        {PositionalParams, 1, 472 }, /* 258 */
        {PositionalParams, 1, 473 }, /* 259 */
        {PositionalParams, 1, 474 }, /* 260 */
        {AnyParams       , 1, 268 }, /* 261 */
        {AnyParams       , 1, 475 }, /* 262 */
        {PositionalParams, 2, 476 }, /* 263 */
        {AnyParams       , 1, 478 }, /* 264 */
        {PositionalParams, 2, 479 }, /* 265 */
        {PositionalParams, 1, 481 }, /* 266 */
        {AnyParams       , 1, 482 }, /* 267 */
        {AnyParams       , 2, 483 }, /* 268 */
        {PositionalParams, 1, 487 }, /* 269 */
        {AnyParams       , 2, 488 }, /* 270 */
        {PositionalParams, 1, 492 }, /* 271 */
        {AnyParams       , 2, 493 }, /* 272 */
        {PositionalParams, 2, 495 }, /* 273 */
        {PositionalParams, 1, 497 }, /* 274 */
        {AnyParams       , 2, 498 }, /* 275 */
        {PositionalParams, 2, 500 }, /* 276 */
        {PositionalParams, 1, 502 }, /* 277 */
        {AnyParams       , 2, 503 }, /* 278 */
        {PositionalParams, 2, 505 }, /* 279 */
        {PositionalParams, 1, 507 }, /* 280 */
        {AnyParams       , 2, 508 }, /* 281 */
        {PositionalParams, 2, 510 }, /* 282 */
        {AnyParams       , 2, 512 }, /* 283 */
        {PositionalParams, 1, 514 }, /* 284 */
        {AnyParams       , 2, 515 }, /* 285 */
        {PositionalParams, 2, 517 }, /* 286 */
        {PositionalParams, 2, 519 }, /* 287 */
        {PositionalParams, 1, 521 }, /* 288 */
        {PositionalParams, 2, 522 }, /* 289 */
        {AnyParams       , 2, 524 }, /* 290 */
        {PositionalParams, 1, 526 }, /* 291 */
        {AnyParams       , 2, 527 }, /* 292 */
        {PositionalParams, 2, 529 }, /* 293 */
        {PositionalParams, 2, 531 }, /* 294 */
        {PositionalParams, 1, 533 }, /* 295 */
        {PositionalParams, 2, 534 }, /* 296 */
        {AnyParams       , 2, 536 }, /* 297 */
        {PositionalParams, 1, 538 }, /* 298 */
        {AnyParams       , 2, 539 }, /* 299 */
        {PositionalParams, 2, 541 }, /* 300 */
        {PositionalParams, 2, 543 }, /* 301 */
        {PositionalParams, 1, 545 }, /* 302 */
        {PositionalParams, 2, 546 }, /* 303 */
        {PositionalParams, 2, 548 }, /* 304 */
        {AnyParams       , 2, 550 }, /* 305 */
        {PositionalParams, 2, 552 }, /* 306 */
        {PositionalParams, 2, 554 }, /* 307 */
        {PositionalParams, 1, 556 }, /* 308 */
        {PositionalParams, 2, 557 }, /* 309 */
        {PositionalParams, 2, 559 }, /* 310 */
        {AnyParams       , 2, 561 }, /* 311 */
        {PositionalParams, 2, 563 }, /* 312 */
        {PositionalParams, 2, 565 }, /* 313 */
        {PositionalParams, 1, 567 }, /* 314 */
        {AnyParams       , 2, 568 }, /* 315 */
        {AnyParams       , 2, 570 }, /* 316 */
        {PositionalParams, 1, 572 }, /* 317 */
        {PositionalParams, 2, 573 }, /* 318 */
        {AnyParams       , 2, 575 }, /* 319 */
        {PositionalParams, 2, 579 }, /* 320 */
        {PositionalParams, 1, 581 }, /* 321 */
        {PositionalParams, 2, 582 }, /* 322 */
        {AnyParams       , 2, 584 }, /* 323 */
        {PositionalParams, 2, 588 }, /* 324 */
        {PositionalParams, 1, 590 }, /* 325 */
        {AnyParams       , 2, 591 }, /* 326 */
        {PositionalParams, 1, 595 }, /* 327 */
        {PositionalParams, 2, 596 }, /* 328 */
        {PositionalParams, 1, 598 }, /* 329 */
        {AnyParams       , 2, 599 }, /* 330 */
        {PositionalParams, 1, 350 }, /* 331 */
        {PositionalParams, 2, 601 }, /* 332 */
        {PositionalParams, 1, 603 }, /* 333 */
        {AnyParams       , 2, 604 }, /* 334 */
        {PositionalParams, 2, 606 }, /* 335 */
        {PositionalParams, 2, 608 }, /* 336 */
        {AnyParams       , 2, 610 }, /* 337 */
        {PositionalParams, 2, 612 }, /* 338 */
        {PositionalParams, 2, 614 }, /* 339 */
        {PositionalParams, 1, 616 }, /* 340 */
        {AnyParams       , 2, 617 }, /* 341 */
        {PositionalParams, 1, 619 }, /* 342 */
        {AnyParams       , 2, 620 }, /* 343 */
        {PositionalParams, 1, 622 }, /* 344 */
        {PositionalParams, 2, 623 }, /* 345 */
        {AnyParams       , 2, 625 }, /* 346 */
        {PositionalParams, 2, 629 }, /* 347 */
        {PositionalParams, 1, 631 }, /* 348 */
        {PositionalParams, 2, 632 }, /* 349 */
        {AnyParams       , 2, 634 }, /* 350 */
        {PositionalParams, 2, 638 }, /* 351 */
        {PositionalParams, 1, 640 }, /* 352 */
        {PositionalParams, 2, 641 }, /* 353 */
        {PositionalParams, 1, 643 }, /* 354 */
        {PositionalParams, 2, 644 }, /* 355 */
        {PositionalParams, 1, 646 }, /* 356 */
        {PositionalParams, 2, 647 }, /* 357 */
        {PositionalParams, 1, 651 }, /* 358 */
        {PositionalParams, 2, 652 }, /* 359 */
        {PositionalParams, 2, 654 }, /* 360 */
        {PositionalParams, 2, 656 }, /* 361 */
        {PositionalParams, 2, 658 }, /* 362 */
        {PositionalParams, 2, 660 }, /* 363 */
        {PositionalParams, 2, 662 }, /* 364 */
        {PositionalParams, 2, 664 }, /* 365 */
        {PositionalParams, 1, 666 }, /* 366 */
        {PositionalParams, 1, 667 }, /* 367 */
        {PositionalParams, 1, 668 }, /* 368 */
        {PositionalParams, 1, 669 }, /* 369 */
        {PositionalParams, 1, 670 }, /* 370 */
        {PositionalParams, 1, 671 }, /* 371 */
        {AnyParams       , 1, 1 }, /* 372 */
        {AnyParams       , 1, 672 }, /* 373 */
        {AnyParams       , 1, 2 }, /* 374 */
        {AnyParams       , 1, 673 }, /* 375 */
        {AnyParams       , 1, 674 }, /* 376 */
        {AnyParams       , 1, 675 }, /* 377 */
        {AnyParams       , 1, 676 }, /* 378 */
        {AnyParams       , 1, 677 }, /* 379 */
        {AnyParams       , 1, 678 }, /* 380 */
        {AnyParams       , 1, 679 }, /* 381 */
        {AnyParams       , 1, 680 }, /* 382 */
        {AnyParams       , 1, 681 }, /* 383 */
        {AnyParams       , 3, 682 }, /* 384 */
        {PositionalParams, 3, 685 }, /* 385 */
        {PositionalParams, 1, 688 }, /* 386 */
        {AnyParams       , 2, 689 }, /* 387 */
        {AnyParams       , 2, 691 }, /* 388 */
        {AnyParams       , 2, 664 }, /* 389 */
        {AnyParams       , 2, 693 }, /* 390 */
        {AnyParams       , 2, 695 }, /* 391 */
        {AnyParams       , 2, 697 }, /* 392 */
        {AnyParams       , 2, 699 }, /* 393 */
        {AnyParams       , 3, 701 }, /* 394 */
        {PositionalParams, 2, 704 }, /* 395 */
        {PositionalParams, 2, 706 }, /* 396 */
        {AnyParams       , 1, 708 }, /* 397 */
        {AnyParams       , 1, 709 }, /* 398 */
        {AnyParams       , 3, 710 }, /* 399 */
        {PositionalParams, 3, 713 }, /* 400 */
        {PositionalParams, 1, 716 }, /* 401 */
        {AnyParams       , 2, 717 }, /* 402 */
        {AnyParams       , 2, 719 }, /* 403 */
        {AnyParams       , 2, 721 }, /* 404 */
        {PositionalParams, 1, 723 }, /* 405 */
        {PositionalParams, 1, 672 }, /* 406 */
        {PositionalParams, 1, 62 }, /* 407 */
        {PositionalParams, 1, 708 }, /* 408 */
        {PositionalParams, 1, 74 }, /* 409 */
        {PositionalParams, 2, 724 }, /* 410 */
        {PositionalParams, 1, 726 }, /* 411 */
        {PositionalParams, 2, 727 }, /* 412 */
        {PositionalParams, 1, 729 }, /* 413 */
        {AnyParams       , 3, 730 }, /* 414 */
        {PositionalParams, 1, 733 }, /* 415 */
        {AnyParams       , 3, 734 }, /* 416 */
        {PositionalParams, 1, 737 }, /* 417 */
        {AnyParams       , 3, 738 }, /* 418 */
        {AnyParams       , 3, 741 }, /* 419 */
        {AnyParams       , 1, 569 }, /* 420 */
        {PositionalParams, 1, 744 }, /* 421 */
        {AnyParams       , 1, 617 }, /* 422 */
        {PositionalParams, 1, 745 }, /* 423 */
        {AnyParams       , 1, 619 }, /* 424 */
        {PositionalParams, 1, 746 }, /* 425 */
        {AnyParams       , 2, 747 }, /* 426 */
        {PositionalParams, 1, 749 }, /* 427 */
        {AnyParams       , 2, 750 }, /* 428 */
        {PositionalParams, 1, 752 }, /* 429 */
        {AnyParams       , 2, 753 }, /* 430 */
        {AnyParams       , 2, 755 }, /* 431 */
        {AnyParams       , 2, 757 }, /* 432 */
        {PositionalParams, 1, 759 }, /* 433 */
        {AnyParams       , 2, 760 }, /* 434 */
        {PositionalParams, 1, 762 }, /* 435 */
        {AnyParams       , 2, 763 }, /* 436 */
        {AnyParams       , 2, 765 }, /* 437 */
        {PositionalParams, 1, 767 }, /* 438 */
    };

    const Function flist[] =
    {
        {cNot        , 0 }, /* 0 */
        {cNotNot     , 0 }, /* 1 */
        {cAcos       , 0 }, /* 2 */
        {cAdd        , 13 }, /* 3 */
        {cSin        , 0 }, /* 4 */
        {cAdd        , 22 }, /* 5 */
        {cAdd        , 24 }, /* 6 */
        {cIf         , 25 }, /* 7 */
        {cAdd        , 26 }, /* 8 */
        {cMul        , 28 }, /* 9 */
        {cMul        , 24 }, /* 10 */
        {cIf         , 30 }, /* 11 */
        {cMul        , 31 }, /* 12 */
        {cAnd        , 33 }, /* 13 */
        {cAnd        , 24 }, /* 14 */
        {cIf         , 35 }, /* 15 */
        {cAnd        , 36 }, /* 16 */
        {cOr         , 38 }, /* 17 */
        {cOr         , 24 }, /* 18 */
        {cIf         , 40 }, /* 19 */
        {cOr         , 41 }, /* 20 */
        {cAdd        , 43 }, /* 21 */
        {cAdd        , 44 }, /* 22 */
        {cAdd        , 46 }, /* 23 */
        {cIf         , 47 }, /* 24 */
        {cAdd        , 48 }, /* 25 */
        {cMul        , 50 }, /* 26 */
        {cMul        , 51 }, /* 27 */
        {cMul        , 46 }, /* 28 */
        {cIf         , 53 }, /* 29 */
        {cMul        , 54 }, /* 30 */
        {cAnd        , 56 }, /* 31 */
        {cAnd        , 57 }, /* 32 */
        {cAnd        , 46 }, /* 33 */
        {cIf         , 59 }, /* 34 */
        {cAnd        , 60 }, /* 35 */
        {cOr         , 62 }, /* 36 */
        {cOr         , 63 }, /* 37 */
        {cOr         , 46 }, /* 38 */
        {cIf         , 65 }, /* 39 */
        {cOr         , 66 }, /* 40 */
        {cNot        , 68 }, /* 41 */
        {cIf         , 70 }, /* 42 */
        {cNotNot     , 68 }, /* 43 */
        {cIf         , 73 }, /* 44 */
        {cPow        , 76 }, /* 45 */
        {cLog        , 0 }, /* 46 */
        {cMul        , 78 }, /* 47 */
        {cPow        , 80 }, /* 48 */
        {cMul        , 81 }, /* 49 */
        {cLog        , 83 }, /* 50 */
        {cAdd        , 84 }, /* 51 */
        {cMax        , 88 }, /* 52 */
        {cMin        , 88 }, /* 53 */
        {cMul        , 100 }, /* 54 */
        {cMul        , 105 }, /* 55 */
        {cMul        , 108 }, /* 56 */
        {cMul        , 112 }, /* 57 */
        {cLog        , 117 }, /* 58 */
        {cMul        , 118 }, /* 59 */
        {cPow        , 121 }, /* 60 */
        {cMul        , 123 }, /* 61 */
        {cAsin       , 0 }, /* 62 */
        {cAdd        , 127 }, /* 63 */
        {cCos        , 0 }, /* 64 */
        {cAtan       , 0 }, /* 65 */
        {cAdd        , 136 }, /* 66 */
        {cMul        , 142 }, /* 67 */
        {cMul        , 144 }, /* 68 */
        {cPow        , 146 }, /* 69 */
        {cPow        , 148 }, /* 70 */
        {cPow        , 150 }, /* 71 */
        {cPow        , 152 }, /* 72 */
        {cLog        , 19 }, /* 73 */
        {cMul        , 158 }, /* 74 */
        {cLog        , 159 }, /* 75 */
        {cPow        , 161 }, /* 76 */
        {cPow        , 162 }, /* 77 */
        {cMul        , 165 }, /* 78 */
        {cMul        , 166 }, /* 79 */
        {cMul        , 168 }, /* 80 */
        {cMul        , 169 }, /* 81 */
        {cAdd        , 170 }, /* 82 */
        {cMul        , 171 }, /* 83 */
        {cMul        , 173 }, /* 84 */
        {cMul        , 174 }, /* 85 */
        {cMul        , 176 }, /* 86 */
        {cMul        , 177 }, /* 87 */
        {cAdd        , 178 }, /* 88 */
        {cMul        , 179 }, /* 89 */
        {cCos        , 19 }, /* 90 */
        {cMul        , 181 }, /* 91 */
        {cSin        , 19 }, /* 92 */
        {cMul        , 182 }, /* 93 */
        {cAdd        , 184 }, /* 94 */
        {cCos        , 185 }, /* 95 */
        {cMul        , 187 }, /* 96 */
        {cMul        , 188 }, /* 97 */
        {cAdd        , 190 }, /* 98 */
        {cCos        , 191 }, /* 99 */
        {cMul        , 193 }, /* 100 */
        {cMul        , 194 }, /* 101 */
        {cAdd        , 196 }, /* 102 */
        {cSin        , 197 }, /* 103 */
        {cMul        , 199 }, /* 104 */
        {cMul        , 200 }, /* 105 */
        {cAdd        , 202 }, /* 106 */
        {cSin        , 203 }, /* 107 */
        {cMul        , 205 }, /* 108 */
        {cAdd        , 207 }, /* 109 */
        {cMul        , 208 }, /* 110 */
        {cMul        , 210 }, /* 111 */
        {cAdd        , 212 }, /* 112 */
        {cMul        , 213 }, /* 113 */
        {cMul        , 215 }, /* 114 */
        {cMul        , 216 }, /* 115 */
        {cMul        , 218 }, /* 116 */
        {cMul        , 219 }, /* 117 */
        {cAdd        , 220 }, /* 118 */
        {cMul        , 221 }, /* 119 */
        {cMul        , 223 }, /* 120 */
        {cMul        , 224 }, /* 121 */
        {cAdd        , 226 }, /* 122 */
        {cCos        , 227 }, /* 123 */
        {cMul        , 229 }, /* 124 */
        {cMul        , 230 }, /* 125 */
        {cAdd        , 232 }, /* 126 */
        {cCos        , 233 }, /* 127 */
        {cMul        , 235 }, /* 128 */
        {cMul        , 236 }, /* 129 */
        {cAdd        , 238 }, /* 130 */
        {cSin        , 239 }, /* 131 */
        {cMul        , 241 }, /* 132 */
        {cAdd        , 243 }, /* 133 */
        {cMul        , 244 }, /* 134 */
        {cMul        , 246 }, /* 135 */
        {cAdd        , 248 }, /* 136 */
        {cMul        , 249 }, /* 137 */
        {cMul        , 252 }, /* 138 */
        {cMul        , 255 }, /* 139 */
        {cAdd        , 257 }, /* 140 */
        {cTan        , 258 }, /* 141 */
        {cTan        , 0 }, /* 142 */
        {cMul        , 136 }, /* 143 */
        {cPow        , 263 }, /* 144 */
        {cPow        , 265 }, /* 145 */
        {cPow        , 273 }, /* 146 */
        {cLog        , 274 }, /* 147 */
        {cPow        , 276 }, /* 148 */
        {cLog        , 277 }, /* 149 */
        {cPow        , 279 }, /* 150 */
        {cLog        , 280 }, /* 151 */
        {cPow        , 282 }, /* 152 */
        {cMul        , 283 }, /* 153 */
        {cLog        , 284 }, /* 154 */
        {cMul        , 286 }, /* 155 */
        {cAdd        , 287 }, /* 156 */
        {cPow        , 289 }, /* 157 */
        {cMul        , 290 }, /* 158 */
        {cLog        , 291 }, /* 159 */
        {cMul        , 293 }, /* 160 */
        {cAdd        , 294 }, /* 161 */
        {cPow        , 296 }, /* 162 */
        {cMul        , 297 }, /* 163 */
        {cLog        , 298 }, /* 164 */
        {cMul        , 300 }, /* 165 */
        {cAdd        , 301 }, /* 166 */
        {cPow        , 303 }, /* 167 */
        {cPow        , 304 }, /* 168 */
        {cAdd        , 306 }, /* 169 */
        {cPow        , 307 }, /* 170 */
        {cPow        , 309 }, /* 171 */
        {cPow        , 310 }, /* 172 */
        {cAdd        , 312 }, /* 173 */
        {cPow        , 313 }, /* 174 */
        {cSinh       , 0 }, /* 175 */
        {cCosh       , 0 }, /* 176 */
        {cTanh       , 0 }, /* 177 */
        {cPow        , 318 }, /* 178 */
        {cPow        , 320 }, /* 179 */
        {cPow        , 322 }, /* 180 */
        {cPow        , 324 }, /* 181 */
        {cPow        , 328 }, /* 182 */
        {cLog        , 329 }, /* 183 */
        {cPow        , 332 }, /* 184 */
        {cLog        , 333 }, /* 185 */
        {cPow        , 335 }, /* 186 */
        {cPow        , 336 }, /* 187 */
        {cAdd        , 338 }, /* 188 */
        {cPow        , 339 }, /* 189 */
        {cPow        , 345 }, /* 190 */
        {cPow        , 347 }, /* 191 */
        {cPow        , 349 }, /* 192 */
        {cPow        , 351 }, /* 193 */
        {cPow        , 353 }, /* 194 */
        {cPow        , 355 }, /* 195 */
        {cEqual      , 365 }, /* 196 */
        {cNEqual     , 365 }, /* 197 */
        {cLess       , 365 }, /* 198 */
        {cGreaterOrEq, 365 }, /* 199 */
        {cLessOrEq   , 365 }, /* 200 */
        {cGreater    , 365 }, /* 201 */
        {cAnd        , 136 }, /* 202 */
        {cOr         , 385 }, /* 203 */
        {cEqual      , 389 }, /* 204 */
        {cNEqual     , 389 }, /* 205 */
        {cEqual      , 392 }, /* 206 */
        {cEqual      , 393 }, /* 207 */
        {cEqual      , 395 }, /* 208 */
        {cOr         , 136 }, /* 209 */
        {cAnd        , 400 }, /* 210 */
        {cNot        , 2 }, /* 211 */
        {cExp        , 0 }, /* 212 */
        {cSqrt       , 0 }, /* 213 */
        {cRad        , 83 }, /* 214 */
        {cDeg        , 83 }, /* 215 */
        {cSec        , 0 }, /* 216 */
        {cCsc        , 0 }, /* 217 */
        {cCot        , 0 }, /* 218 */
        {cLog10      , 0 }, /* 219 */
        {cLog2       , 0 }, /* 220 */
        {cNot        , 1 }, /* 221 */
    };

    const Rule rlist[] =
    {
        {1, ProduceNewTree,    2,	{ cNot        , 1 } }, /* 0 */
        {1, ProduceNewTree,    4,	{ cAcos       , 3 } }, /* 1 */
        {1, ProduceNewTree,    5,	{ cAcosh      , 3 } }, /* 2 */
        {1, ProduceNewTree,    6,	{ cAsin       , 3 } }, /* 3 */
        {1, ProduceNewTree,    7,	{ cAsinh      , 3 } }, /* 4 */
        {1, ProduceNewTree,    8,	{ cAtan       , 3 } }, /* 5 */
        {1, ProduceNewTree,    9,	{ cAtanh      , 3 } }, /* 6 */
        {1, ProduceNewTree,    10,	{ cCeil       , 3 } }, /* 7 */
        {1, ProduceNewTree,    11,	{ cCos        , 3 } }, /* 8 */
        {1, ProduceNewTree,    0,	{ cCos        , 12 } }, /* 9 */
        {1, ProduceNewTree,    15,	{ cCos        , 14 } }, /* 10 */
        {1, ProduceNewTree,    16,	{ cCosh       , 3 } }, /* 11 */
        {1, ProduceNewTree,    17,	{ cFloor      , 3 } }, /* 12 */
        {3, ProduceNewTree,    19,	{ cIf         , 18 } }, /* 13 */
        {3, ProduceNewTree,    0,	{ cIf         , 20 } }, /* 14 */
        {3, ProduceNewTree,    0,	{ cIf         , 21 } }, /* 15 */
        {3, ProduceNewTree,    27,	{ cIf         , 23 } }, /* 16 */
        {3, ProduceNewTree,    32,	{ cIf         , 29 } }, /* 17 */
        {3, ProduceNewTree,    37,	{ cIf         , 34 } }, /* 18 */
        {3, ProduceNewTree,    42,	{ cIf         , 39 } }, /* 19 */
        {3, ProduceNewTree,    49,	{ cIf         , 45 } }, /* 20 */
        {3, ProduceNewTree,    55,	{ cIf         , 52 } }, /* 21 */
        {3, ProduceNewTree,    61,	{ cIf         , 58 } }, /* 22 */
        {3, ProduceNewTree,    67,	{ cIf         , 64 } }, /* 23 */
        {3, ProduceNewTree,    71,	{ cIf         , 69 } }, /* 24 */
        {3, ProduceNewTree,    74,	{ cIf         , 72 } }, /* 25 */
        {1, ProduceNewTree,    75,	{ cLog        , 3 } }, /* 26 */
        {1, ProduceNewTree,    79,	{ cLog        , 77 } }, /* 27 */
        {1, ProduceNewTree,    85,	{ cLog        , 82 } }, /* 28 */
        {0, ProduceNewTree,    87,	{ cMax        , 86 } }, /* 29 */
        {1, ProduceNewTree,    0,	{ cMax        , 0 } }, /* 30 */
        {1, ReplaceParams ,    90,	{ cMax        , 89 } }, /* 31 */
        {2, ReplaceParams ,    92,	{ cMax        , 91 } }, /* 32 */
        {2, ReplaceParams ,    0,	{ cMax        , 93 } }, /* 33 */
        {0, ProduceNewTree,    94,	{ cMin        , 86 } }, /* 34 */
        {1, ProduceNewTree,    0,	{ cMin        , 0 } }, /* 35 */
        {1, ReplaceParams ,    90,	{ cMin        , 95 } }, /* 36 */
        {2, ReplaceParams ,    97,	{ cMin        , 96 } }, /* 37 */
        {2, ReplaceParams ,    0,	{ cMin        , 98 } }, /* 38 */
        {2, ProduceNewTree,    0,	{ cPow        , 99 } }, /* 39 */
        {2, ReplaceParams ,    102,	{ cPow        , 101 } }, /* 40 */
        {2, ProduceNewTree,    104,	{ cPow        , 103 } }, /* 41 */
        {2, ReplaceParams ,    107,	{ cPow        , 106 } }, /* 42 */
        {2, ReplaceParams ,    110,	{ cPow        , 109 } }, /* 43 */
        {2, ProduceNewTree,    113,	{ cPow        , 111 } }, /* 44 */
        {2, ProduceNewTree,    115,	{ cPow        , 114 } }, /* 45 */
        {2, ProduceNewTree,    0,	{ cPow        , 116 } }, /* 46 */
        {2, ReplaceParams ,    120,	{ cPow        , 119 } }, /* 47 */
        {2, ReplaceParams ,    124,	{ cPow        , 122 } }, /* 48 */
        {1, ProduceNewTree,    125,	{ cSin        , 3 } }, /* 49 */
        {1, ProduceNewTree,    0,	{ cSin        , 126 } }, /* 50 */
        {1, ProduceNewTree,    129,	{ cSin        , 128 } }, /* 51 */
        {1, ProduceNewTree,    130,	{ cSinh       , 3 } }, /* 52 */
        {1, ProduceNewTree,    131,	{ cTan        , 3 } }, /* 53 */
        {1, ProduceNewTree,    0,	{ cTan        , 132 } }, /* 54 */
        {1, ProduceNewTree,    133,	{ cTanh       , 3 } }, /* 55 */
        {0, ProduceNewTree,    134,	{ cAdd        , 86 } }, /* 56 */
        {1, ProduceNewTree,    0,	{ cAdd        , 0 } }, /* 57 */
        {1, ReplaceParams ,    86,	{ cAdd        , 135 } }, /* 58 */
        {1, ReplaceParams ,    24,	{ cAdd        , 137 } }, /* 59 */
        {1, ReplaceParams ,    139,	{ cAdd        , 138 } }, /* 60 */
        {1, ReplaceParams ,    141,	{ cAdd        , 140 } }, /* 61 */
        {1, ReplaceParams ,    145,	{ cAdd        , 143 } }, /* 62 */
        {2, ReplaceParams ,    149,	{ cAdd        , 147 } }, /* 63 */
        {2, ReplaceParams ,    153,	{ cAdd        , 151 } }, /* 64 */
        {2, ReplaceParams ,    155,	{ cAdd        , 154 } }, /* 65 */
        {2, ReplaceParams ,    86,	{ cAdd        , 156 } }, /* 66 */
        {2, ReplaceParams ,    160,	{ cAdd        , 157 } }, /* 67 */
        {2, ReplaceParams ,    164,	{ cAdd        , 163 } }, /* 68 */
        {2, ReplaceParams ,    172,	{ cAdd        , 167 } }, /* 69 */
        {2, ReplaceParams ,    180,	{ cAdd        , 175 } }, /* 70 */
        {2, ReplaceParams ,    186,	{ cAdd        , 183 } }, /* 71 */
        {2, ReplaceParams ,    192,	{ cAdd        , 189 } }, /* 72 */
        {2, ReplaceParams ,    198,	{ cAdd        , 195 } }, /* 73 */
        {2, ReplaceParams ,    204,	{ cAdd        , 201 } }, /* 74 */
        {2, ReplaceParams ,    209,	{ cAdd        , 206 } }, /* 75 */
        {2, ReplaceParams ,    214,	{ cAdd        , 211 } }, /* 76 */
        {2, ReplaceParams ,    222,	{ cAdd        , 217 } }, /* 77 */
        {2, ReplaceParams ,    228,	{ cAdd        , 225 } }, /* 78 */
        {2, ReplaceParams ,    234,	{ cAdd        , 231 } }, /* 79 */
        {2, ReplaceParams ,    240,	{ cAdd        , 237 } }, /* 80 */
        {2, ReplaceParams ,    245,	{ cAdd        , 242 } }, /* 81 */
        {2, ReplaceParams ,    250,	{ cAdd        , 247 } }, /* 82 */
        {2, ReplaceParams ,    253,	{ cAdd        , 251 } }, /* 83 */
        {2, ReplaceParams ,    256,	{ cAdd        , 254 } }, /* 84 */
        {0, ProduceNewTree,    164,	{ cMul        , 86 } }, /* 85 */
        {1, ProduceNewTree,    0,	{ cMul        , 0 } }, /* 86 */
        {1, ProduceNewTree,    260,	{ cMul        , 259 } }, /* 87 */
        {1, ProduceNewTree,    134,	{ cMul        , 135 } }, /* 88 */
        {1, ReplaceParams ,    86,	{ cMul        , 261 } }, /* 89 */
        {1, ReplaceParams ,    24,	{ cMul        , 262 } }, /* 90 */
        {1, ReplaceParams ,    266,	{ cMul        , 264 } }, /* 91 */
        {1, ReplaceParams ,    141,	{ cMul        , 267 } }, /* 92 */
        {2, ReplaceParams ,    269,	{ cMul        , 268 } }, /* 93 */
        {2, ReplaceParams ,    271,	{ cMul        , 270 } }, /* 94 */
        {2, ReplaceParams ,    86,	{ cMul        , 272 } }, /* 95 */
        {2, ReplaceParams ,    19,	{ cMul        , 275 } }, /* 96 */
        {2, ReplaceParams ,    19,	{ cMul        , 278 } }, /* 97 */
        {2, ReplaceParams ,    19,	{ cMul        , 281 } }, /* 98 */
        {2, ProduceNewTree,    288,	{ cMul        , 285 } }, /* 99 */
        {2, ProduceNewTree,    295,	{ cMul        , 292 } }, /* 100 */
        {2, ProduceNewTree,    302,	{ cMul        , 299 } }, /* 101 */
        {2, ReplaceParams ,    308,	{ cMul        , 305 } }, /* 102 */
        {2, ReplaceParams ,    314,	{ cMul        , 311 } }, /* 103 */
        {2, ReplaceParams ,    260,	{ cMul        , 315 } }, /* 104 */
        {2, ReplaceParams ,    317,	{ cMul        , 316 } }, /* 105 */
        {2, ReplaceParams ,    321,	{ cMul        , 319 } }, /* 106 */
        {2, ReplaceParams ,    325,	{ cMul        , 323 } }, /* 107 */
        {2, ReplaceParams ,    327,	{ cMul        , 326 } }, /* 108 */
        {2, ReplaceParams ,    331,	{ cMul        , 330 } }, /* 109 */
        {2, ReplaceParams ,    331,	{ cMul        , 334 } }, /* 110 */
        {2, ReplaceParams ,    340,	{ cMul        , 337 } }, /* 111 */
        {2, ReplaceParams ,    342,	{ cMul        , 341 } }, /* 112 */
        {2, ReplaceParams ,    344,	{ cMul        , 343 } }, /* 113 */
        {2, ReplaceParams ,    348,	{ cMul        , 346 } }, /* 114 */
        {2, ReplaceParams ,    352,	{ cMul        , 350 } }, /* 115 */
        {2, ReplaceParams ,    354,	{ cMul        , 251 } }, /* 116 */
        {2, ReplaceParams ,    356,	{ cMul        , 254 } }, /* 117 */
        {2, ProduceNewTree,    358,	{ cMod        , 357 } }, /* 118 */
        {2, ProduceNewTree,    164,	{ cEqual      , 359 } }, /* 119 */
        {2, ProduceNewTree,    164,	{ cNEqual     , 360 } }, /* 120 */
        {2, ProduceNewTree,    164,	{ cLess       , 361 } }, /* 121 */
        {2, ProduceNewTree,    164,	{ cLessOrEq   , 362 } }, /* 122 */
        {2, ProduceNewTree,    164,	{ cGreater    , 363 } }, /* 123 */
        {2, ProduceNewTree,    164,	{ cGreaterOrEq, 364 } }, /* 124 */
        {1, ProduceNewTree,    367,	{ cNot        , 366 } }, /* 125 */
        {1, ProduceNewTree,    366,	{ cNot        , 367 } }, /* 126 */
        {1, ProduceNewTree,    369,	{ cNot        , 368 } }, /* 127 */
        {1, ProduceNewTree,    371,	{ cNot        , 370 } }, /* 128 */
        {1, ProduceNewTree,    370,	{ cNot        , 371 } }, /* 129 */
        {1, ProduceNewTree,    368,	{ cNot        , 369 } }, /* 130 */
        {0, ProduceNewTree,    134,	{ cAnd        , 86 } }, /* 131 */
        {1, ProduceNewTree,    2,	{ cAnd        , 0 } }, /* 132 */
        {1, ProduceNewTree,    0,	{ cAnd        , 0 } }, /* 133 */
        {1, ProduceNewTree,    1,	{ cAnd        , 112 } }, /* 134 */
        {1, ReplaceParams ,    112,	{ cAnd        , 372 } }, /* 135 */
        {1, ReplaceParams ,    24,	{ cAnd        , 373 } }, /* 136 */
        {1, ReplaceParams ,    0,	{ cAnd        , 374 } }, /* 137 */
        {1, ReplaceParams ,    367,	{ cAnd        , 375 } }, /* 138 */
        {1, ReplaceParams ,    366,	{ cAnd        , 376 } }, /* 139 */
        {1, ReplaceParams ,    369,	{ cAnd        , 377 } }, /* 140 */
        {1, ReplaceParams ,    371,	{ cAnd        , 378 } }, /* 141 */
        {1, ReplaceParams ,    370,	{ cAnd        , 379 } }, /* 142 */
        {1, ReplaceParams ,    368,	{ cAnd        , 380 } }, /* 143 */
        {1, ReplaceParams ,    0,	{ cAnd        , 381 } }, /* 144 */
        {1, ReplaceParams ,    141,	{ cAnd        , 382 } }, /* 145 */
        {1, ReplaceParams ,    112,	{ cAnd        , 383 } }, /* 146 */
        {2, ReplaceParams ,    386,	{ cAnd        , 384 } }, /* 147 */
        {2, ReplaceParams ,    0,	{ cAnd        , 387 } }, /* 148 */
        {2, ProduceNewTree,    134,	{ cAnd        , 388 } }, /* 149 */
        {2, ProduceNewTree,    134,	{ cAnd        , 390 } }, /* 150 */
        {2, ReplaceParams ,    112,	{ cAnd        , 391 } }, /* 151 */
        {3, ReplaceParams ,    396,	{ cAnd        , 394 } }, /* 152 */
        {0, ProduceNewTree,    164,	{ cOr         , 86 } }, /* 153 */
        {1, ProduceNewTree,    2,	{ cOr         , 0 } }, /* 154 */
        {1, ProduceNewTree,    0,	{ cOr         , 0 } }, /* 155 */
        {1, ProduceNewTree,    1,	{ cOr         , 112 } }, /* 156 */
        {1, ReplaceParams ,    112,	{ cOr         , 372 } }, /* 157 */
        {1, ReplaceParams ,    24,	{ cOr         , 397 } }, /* 158 */
        {1, ReplaceParams ,    0,	{ cOr         , 374 } }, /* 159 */
        {1, ReplaceParams ,    367,	{ cOr         , 375 } }, /* 160 */
        {1, ReplaceParams ,    366,	{ cOr         , 376 } }, /* 161 */
        {1, ReplaceParams ,    369,	{ cOr         , 377 } }, /* 162 */
        {1, ReplaceParams ,    371,	{ cOr         , 378 } }, /* 163 */
        {1, ReplaceParams ,    370,	{ cOr         , 379 } }, /* 164 */
        {1, ReplaceParams ,    368,	{ cOr         , 380 } }, /* 165 */
        {1, ReplaceParams ,    0,	{ cOr         , 381 } }, /* 166 */
        {1, ReplaceParams ,    141,	{ cOr         , 398 } }, /* 167 */
        {1, ReplaceParams ,    112,	{ cOr         , 383 } }, /* 168 */
        {2, ReplaceParams ,    401,	{ cOr         , 399 } }, /* 169 */
        {2, ReplaceParams ,    0,	{ cOr         , 402 } }, /* 170 */
        {2, ProduceNewTree,    164,	{ cOr         , 403 } }, /* 171 */
        {2, ProduceNewTree,    164,	{ cOr         , 390 } }, /* 172 */
        {2, ReplaceParams ,    112,	{ cOr         , 404 } }, /* 173 */
        {1, ProduceNewTree,    366,	{ cNotNot     , 366 } }, /* 174 */
        {1, ProduceNewTree,    367,	{ cNotNot     , 367 } }, /* 175 */
        {1, ProduceNewTree,    368,	{ cNotNot     , 368 } }, /* 176 */
        {1, ProduceNewTree,    370,	{ cNotNot     , 370 } }, /* 177 */
        {1, ProduceNewTree,    371,	{ cNotNot     , 371 } }, /* 178 */
        {1, ProduceNewTree,    369,	{ cNotNot     , 369 } }, /* 179 */
        {1, ProduceNewTree,    405,	{ cNotNot     , 1 } }, /* 180 */
        {1, ProduceNewTree,    407,	{ cNotNot     , 406 } }, /* 181 */
        {1, ProduceNewTree,    409,	{ cNotNot     , 408 } }, /* 182 */
        {1, ReplaceParams ,    0,	{ cNotNot     , 2 } }, /* 183 */
        {2, ProduceNewTree,    411,	{ cPow        , 410 } }, /* 184 */
        {2, ProduceNewTree,    413,	{ cPow        , 412 } }, /* 185 */
        {1, ProduceNewTree,    415,	{ cMul        , 414 } }, /* 186 */
        {1, ProduceNewTree,    417,	{ cMul        , 416 } }, /* 187 */
        {1, ProduceNewTree,    417,	{ cMul        , 418 } }, /* 188 */
        {1, ProduceNewTree,    415,	{ cMul        , 419 } }, /* 189 */
        {1, ReplaceParams ,    421,	{ cMul        , 420 } }, /* 190 */
        {1, ReplaceParams ,    423,	{ cMul        , 422 } }, /* 191 */
        {1, ReplaceParams ,    425,	{ cMul        , 424 } }, /* 192 */
        {2, ReplaceParams ,    427,	{ cMul        , 426 } }, /* 193 */
        {2, ReplaceParams ,    429,	{ cMul        , 428 } }, /* 194 */
        {2, ReplaceParams ,    429,	{ cMul        , 430 } }, /* 195 */
        {2, ReplaceParams ,    427,	{ cMul        , 431 } }, /* 196 */
        {2, ReplaceParams ,    433,	{ cMul        , 432 } }, /* 197 */
        {2, ReplaceParams ,    435,	{ cMul        , 434 } }, /* 198 */
        {2, ReplaceParams ,    435,	{ cMul        , 436 } }, /* 199 */
        {2, ReplaceParams ,    433,	{ cMul        , 437 } }, /* 200 */
        {1, ProduceNewTree,    438,	{ cNotNot     , 0 } }, /* 201 */
    };
}

namespace FPoptimizer_Grammar
{
    const GrammarPack pack =
    {
        clist, plist, mlist, flist, rlist,
        {
            {0, 1 }, /* 0 */
            {1, 183 }, /* 1 */
            {184, 18 }, /* 2 */
        }
    };
}

#include <algorithm>
#include <cmath>
#include <map>
#include <assert.h>

#include "fpconfig.hh"
#include "fparser.hh"
#include "fptypes.hh"
using namespace FUNCTIONPARSERTYPES;

//#define DEBUG_SUBSTITUTIONS

namespace FPoptimizer_CodeTree
{
    void CodeTree::ConstantFolding()
    {
        // Insert here any hardcoded constant-folding optimizations
        // that you want to be done at bytecode->codetree conversion time.
    }
}

namespace FPoptimizer_Grammar
{
    /* A helper for std::equal_range */
    struct OpcodeRuleCompare
    {
        bool operator() (const FPoptimizer_CodeTree::CodeTree& tree, const Rule& rule) const
        {
            /* If this function returns true, len=half.
             */

            if(tree.Opcode != rule.func.opcode)
                return tree.Opcode < rule.func.opcode;

            if(tree.Params.size() < rule.n_minimum_params)
            {
                // Tree has fewer params than required?
                return true; // Failure
            }
            return false;
        }
        bool operator() (const Rule& rule, const FPoptimizer_CodeTree::CodeTree& tree) const
        {
            /* If this function returns true, rule will be excluded from the equal_range
             */

            if(rule.func.opcode != tree.Opcode)
                return rule.func.opcode < tree.Opcode;

            if(rule.n_minimum_params < tree.Params.size())
            {
                // Tree has more params than the pattern has?
                switch(pack.mlist[rule.func.index].type)
                {
                    case PositionalParams:
                    case SelectedParams:
                        return true; // Failure
                    case AnyParams:
                        return false; // Not a failure
                }
            }
            return false;
        }
    };

#ifdef DEBUG_SUBSTITUTIONS
    void DumpTree(const FPoptimizer_CodeTree::CodeTree& tree);
    static const char ImmedHolderNames[2][2] = {"%","&"};
    static const char NamedHolderNames[6][2] = {"x","y","z","a","b","c"};
#endif

    /* Apply the grammar to a given CodeTree */
    bool Grammar::ApplyTo(
        std::set<uint_fast64_t>& optimized_children,
        FPoptimizer_CodeTree::CodeTree& tree,
        bool recursion) const
    {
        bool changed = false;

#ifdef DEBUG_SUBSTITUTIONS
        if(!recursion)
        {
            std::cout << "Input:  ";
            DumpTree(tree);
            std::cout << "\n";
        }
#endif
        std::set<uint_fast64_t>::iterator
            i = optimized_children.lower_bound(tree.Hash);
        if(i == optimized_children.end() || *i != tree.Hash)
        {
            /* First optimize all children */
            for(size_t a=0; a<tree.Params.size(); ++a)
            {
                if( ApplyTo( optimized_children, *tree.Params[a].param, true ) )
                {
                    changed = true;
                }
            }

            /* Figure out which rules _may_ match this tree */
            typedef const Rule* ruleit;

            std::pair<ruleit, ruleit> range
                = std::equal_range(pack.rlist + index,
                                   pack.rlist + index + count,
                                   tree,
                                   OpcodeRuleCompare());

            while(range.first < range.second)
            {
                /* Check if this rule matches */
                if(range.first->ApplyTo(tree))
                {
                    changed = true;
                    break;
                }
                ++range.first;
            }

            if(!changed)
                optimized_children.insert(i, tree.Hash);
        }

#ifdef DEBUG_SUBSTITUTIONS
        if(!recursion)
        {
            std::cout << "Output: ";
            DumpTree(tree);
            std::cout << "\n";
        }
#endif
        return changed;
    }

    /* Store information about a potential match,
     * in order to iterate through candidates
     */
    struct MatchedParams::CodeTreeMatch
    {
        // Which parameters were matched -- these will be replaced if AnyParams are used
        std::vector<size_t> param_numbers;

        // Which values were saved for ImmedHolders?
        std::map<unsigned, double> ImmedMap;
        // Which codetrees were saved for each NameHolder? And how many?
        std::map<unsigned, std::pair<uint_fast64_t, size_t> > NamedMap;
        // Which codetrees were saved for each RestHolder?
        std::map<unsigned,
          std::vector<uint_fast64_t> > RestMap;

        // Examples of each codetree
        std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP> trees;

        CodeTreeMatch() : param_numbers(), ImmedMap(), NamedMap(), RestMap() { }
    };

#ifdef DEBUG_SUBSTITUTIONS
    void DumpMatch(const Function& input,
                   const FPoptimizer_CodeTree::CodeTree& tree,
                   const MatchedParams& replacement,
                   const MatchedParams::CodeTreeMatch& matchrec,
                   bool DidMatch=true);
    void DumpFunction(const Function& input);
    void DumpParam(const ParamSpec& p);
    void DumpParams(const MatchedParams& mitem);
#endif

    /* Apply the rule to a given CodeTree */
    bool Rule::ApplyTo(
        FPoptimizer_CodeTree::CodeTree& tree) const
    {
        const Function&      input  = func;
        const MatchedParams& repl   = pack.mlist[repl_index];

        MatchedParams::CodeTreeMatch matchrec;
        if(input.opcode == tree.Opcode
        && pack.mlist[input.index].Match(tree, matchrec, false))
        {
#ifdef DEBUG_SUBSTITUTIONS
            DumpMatch(input, tree, repl, matchrec);
#endif

            const MatchedParams& params = pack.mlist[input.index];
            switch(type)
            {
                case ReplaceParams:
                    repl.ReplaceParams(tree, params, matchrec);
#ifdef DEBUG_SUBSTITUTIONS
                    std::cout << "  ParmReplace: ";
                    DumpTree(tree);
                    std::cout << "\n";
#endif
                    return true;
                case ProduceNewTree:
                    repl.ReplaceTree(tree,   params, matchrec);
#ifdef DEBUG_SUBSTITUTIONS
                    std::cout << "  TreeReplace: ";
                    DumpTree(tree);
                    std::cout << "\n";
#endif
                    return true;
            }
        }
        else
        {
            //DumpMatch(input, tree, repl, matchrec, false);
        }
        return false;
    }


    /* Match the given function to the given CodeTree.
     */
    bool Function::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match) const
    {
        return opcode == tree.Opcode
            && pack.mlist[index].Match(tree, match);
    }


    /* This struct is used by MatchedParams::Match() for backtracking. */
    struct ParamMatchSnapshot
    {
        MatchedParams::CodeTreeMatch snapshot;
                                    // Snapshot of the state so far
        size_t            parampos; // Which position was last chosen?
        std::vector<bool> used;     // Which params were allocated?
    };

    /* Match the given list of ParamSpecs using the given ParamMatchingType
     * to the given CodeTree.
     * The CodeTree is already assumed to be a function type
     * -- i.e. it is assumed that the caller has tested the Opcode of the tree.
     */
    bool MatchedParams::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match,
        bool recursion) const
    {
        /* FIXME: This algorithm still does not cover the possibility
         *        that the ParamSpec needs backtracking.
         *
         *        For example,
         *          cMul (cAdd x) (cAdd x)
         *        Applied to:
         *          (a+b)*(c+b)
         *
         *        Match (cAdd x) to (a+b) may first capture "a" into "x",
         *        and then Match(cAdd x) for (c+b) will fail,
         *        because there's no "a" there.
         */


        /* First, check if the tree has any chances of matching... */
        /* Figure out what we need. */
        struct Needs
        {
            struct Needs_Pol
            {
                int Immeds;
                int SubTrees;
                int Others;
                unsigned SubTreesDetail[VarBegin];

                Needs_Pol(): Immeds(0), SubTrees(0), Others(0), SubTreesDetail()
                {
                }
            } polarity[2]; // 0=positive, 1=negative
        } NeedList;

        // Figure out what we need
        for(unsigned a=0; a<count; ++a)
        {
            const ParamSpec& param = pack.plist[index+a];
            Needs::Needs_Pol& needs = NeedList.polarity[param.sign];
            switch(param.opcode)
            {
                case SubFunction:
                    needs.SubTrees += 1;
                    assert( pack.flist[param.index].opcode < VarBegin );
                    needs.SubTreesDetail[ pack.flist[param.index].opcode ] += 1;
                    break;
                case NumConstant:
                case ImmedHolder:
                default:
                    needs.Immeds += 1;
                    break;
                case NamedHolder:
                    needs.Others += param.minrepeat;
                    break;
                case RestHolder:
                    break;
            }
        }

        // Figure out what we have (note: we already assume that the opcode of the tree matches!)
        for(size_t a=0; a<tree.Params.size(); ++a)
        {
            Needs::Needs_Pol& needs = NeedList.polarity[tree.Params[a].sign];
            unsigned opcode = tree.Params[a].param->Opcode;
            switch(opcode)
            {
                case cImmed:
                    if(needs.Immeds > 0) needs.Immeds -= 1;
                    else needs.Others -= 1;
                    break;
                case cVar:
                case cFCall:
                case cPCall:
                    needs.Others -= 1;
                    break;
                default:
                    assert( opcode < VarBegin );
                    if(needs.SubTrees > 0
                    && needs.SubTreesDetail[opcode] > 0)
                    {
                        needs.SubTrees -= 1;
                        needs.SubTreesDetail[opcode] -= 1;
                    }
                    else needs.Others -= 1;
            }
        }

        // Check whether all needs were satisfied
        if(NeedList.polarity[0].Immeds > 0
        || NeedList.polarity[0].SubTrees > 0
        || NeedList.polarity[0].Others > 0
        || NeedList.polarity[1].Immeds > 0
        || NeedList.polarity[1].SubTrees > 0
        || NeedList.polarity[1].Others > 0)
        {
            // Something came short.
            return false;
        }

        if(type != AnyParams)
        {
            if(NeedList.polarity[0].Immeds < 0
            || NeedList.polarity[0].SubTrees < 0
            || NeedList.polarity[0].Others < 0
            || NeedList.polarity[1].Immeds < 0
            || NeedList.polarity[1].SubTrees < 0
            || NeedList.polarity[1].Others < 0
            || count != tree.Params.size())
            {
                // Something was too much.
                return false;
            }

        }

        switch(type)
        {
            case PositionalParams:
            {
                /*DumpTree(tree);
                std::cout << "<->";
                DumpParams(*this);
                std::cout << " -- ";*/
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(param.sign != tree.Params[a].sign
                    || !param.Match(*tree.Params[a].param, match))
                    {
                        /*std::cout << " drats at " << a << "!\n";*/
                        return false;
                    }
                    if(!recursion)
                        match.param_numbers.push_back(a);
                }
                /*std::cout << " yay?\n";*/
                // Match = no mismatch.
                return true;
            }
            case AnyParams:
            case SelectedParams:
            {
                const size_t n_tree_params = tree.Params.size();

                bool HasRestHolders = false;
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(param.opcode == RestHolder) { HasRestHolders = true; break; }
                }

                #ifdef DEBUG_SUBSTITUTIONS
                if((type == AnyParams) && recursion && !HasRestHolders)
                {
                    std::cout << "Recursed AnyParams with no RestHolders?\n";
                    DumpParams(*this);
                }
                #endif

                if(!HasRestHolders && recursion && count != n_tree_params)
                {
                    /*DumpTree(tree);
                    std::cout << "<->";
                    DumpParams(*this);
                    std::cout << " -- fail due to recursion&&count!=n_tree_params";*/
                    return false;
                }

                std::vector<ParamMatchSnapshot> position(count);
                std::vector<bool>               used(count);

                for(unsigned a=0; a<count; ++a)
                {
                    position[a].snapshot  = match;
                    position[a].parampos  = 0;
                    position[a].used      = used;

                    size_t b = 0;
                backtrack:
                    const ParamSpec& param = pack.plist[index+a];

                    if(param.opcode == RestHolder)
                    {
                        // RestHolders always match. They're filled afterwards.
                        continue;
                    }

                    for(; b<n_tree_params; ++b)
                    {
                        if(!used[b])
                        {
                            /*std::cout << "Maybe [" << a << "]:";
                            DumpParam(param);
                            std::cout << " <-> ";
                            if(tree.Params[b].sign) std::cout << '~';
                            DumpTree(*tree.Params[b].param);
                            std::cout << "...?\n";*/

                            if(param.sign == tree.Params[b].sign
                            && param.Match(*tree.Params[b].param, match))
                            {
                                /*std::cout << "woo... " << a << ", " << b << "\n";*/
                                /* NamedHolders require a special treatment,
                                 * because a repetition count may be issued
                                 * for them.
                                 */
                                if(param.opcode == NamedHolder)
                                {
                                    // Verify the MinRepeat & AnyRepeat case
                                    unsigned MinRepeat = param.minrepeat;
                                    bool AnyRepeat     = param.anyrepeat;
                                    unsigned HadRepeat = 1;

                                    for(size_t c = b+1;
                                        c < n_tree_params && (HadRepeat < MinRepeat || AnyRepeat);
                                        ++c)
                                    {
                                        if(tree.Params[c].param->Hash == tree.Params[b].param->Hash
                                        && tree.Params[c].sign == param.sign)
                                        {
                                            ++HadRepeat;
                                        }
                                    }
                                    if(HadRepeat < MinRepeat)
                                        continue; // No sufficient repeat count here

                                    used[b] = true;
                                    if(!recursion) match.param_numbers.push_back(b);

                                    HadRepeat = 1;
                                    for(size_t c = b+1;
                                        c < n_tree_params && (HadRepeat < MinRepeat || AnyRepeat);
                                        ++c)
                                    {
                                        if(tree.Params[c].param->Hash == tree.Params[b].param->Hash
                                        && tree.Params[c].sign == param.sign)
                                        {
                                            ++HadRepeat;
                                            used[c] = true;
                                            if(!recursion) match.param_numbers.push_back(c);
                                        }
                                    }
                                    if(AnyRepeat)
                                        match.NamedMap[param.index].second = HadRepeat;
                                    position[a].parampos = b+1;
                                    goto ok;
                                }

                                used[b] = true;
                                if(!recursion) match.param_numbers.push_back(b);
                                position[a].parampos = b+1;
                                goto ok;
                            }
                        }
                    }

                    /*DumpParam(param);
                    std::cout << " didn't match anything in ";
                    DumpTree(tree);
                    std::cout << "\n";*/

                    // No match for this param, try backtracking.
                    while(a > 0)
                    {
                        --a;
                        ParamMatchSnapshot& prevpos = position[a];
                        if(prevpos.parampos < n_tree_params)
                        {
                            // Try another combination.
                            b     = prevpos.parampos;
                            match = prevpos.snapshot;
                            used  = prevpos.used;
                            goto backtrack;
                        }
                    }
                    // If we cannot backtrack, break. No possible match.
                    /*if(!recursion)
                        std::cout << "Drats!\n";*/
                    return false;
                ok:;
                    /*if(!recursion)
                        std::cout << "Match for param " << a << " at " << b << std::endl;*/
                }
                // Match = no mismatch.

                // Now feed any possible RestHolders the remaining parameters.
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(param.opcode == RestHolder)
                    {
                        std::vector<uint_fast64_t>& RestList
                            = match.RestMap[param.index]; // mark it up

                        for(size_t b=0; b<n_tree_params; ++b)
                            if(tree.Params[b].sign == param.sign && !used[b])
                            {
                                if(!recursion)
                                    match.param_numbers.push_back(b);
                                uint_fast64_t hash = tree.Params[b].param->Hash;
                                RestList.push_back(hash);
                                match.trees.insert(
                                    std::make_pair(hash, tree.Params[b].param) );
                            }
                    }
                }
                return true;
            }
        }
        return false;
    }

    bool ParamSpec::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match) const
    {
        assert(opcode != RestHolder); // RestHolders are supposed to be handler by the caller

        switch(OpcodeType(opcode))
        {
            case NumConstant:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();
                if(transformation == Negate) res = -res;
                if(transformation == Invert) res = 1/res;
                if(res != pack.clist[index]) return false;
                return true;
            }
            case ImmedHolder:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();
                if(transformation == Negate) res = -res;
                if(transformation == Invert) res = 1/res;
                std::map<unsigned, double>::iterator
                    i = match.ImmedMap.lower_bound(index);
                if(i != match.ImmedMap.end() && i->first == index)
                    return res == i->second;
                match.ImmedMap.insert(i, std::make_pair((unsigned)index, res));
                return true;
            }
            case NamedHolder:
            {
                std::map<unsigned, std::pair<uint_fast64_t, size_t> >::iterator
                    i = match.NamedMap.lower_bound(index);
                if(i != match.NamedMap.end() && i->first == index)
                {
                    return tree.Hash == i->second.first;
                }
                match.NamedMap.insert(i, std::make_pair(index, std::make_pair(tree.Hash, 1)));
                match.trees.insert(std::make_pair(tree.Hash, &tree));
                return true;
            }
            case RestHolder:
                break;
            case SubFunction:
            {
                return pack.flist[index].Match(tree, match);
            }
            default:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();

                double constval;
                return GetConst(match, constval) && res == constval;
            }
        }
        return false;
    }

    bool ParamSpec::GetConst(
        const MatchedParams::CodeTreeMatch& match,
        double& result) const
    {
        switch(OpcodeType(opcode))
        {
            case NumConstant:
                result = pack.clist[index];
                break;
            case ImmedHolder:
            {
                std::map<unsigned, double>::const_iterator
                    i = match.ImmedMap.find(index);
                if(i == match.ImmedMap.end()) return false; // impossible
                result = i->second;
                break;
            }
            case NamedHolder:
            {
                std::map<unsigned, std::pair<uint_fast64_t, size_t> >::const_iterator
                    i = match.NamedMap.find(index);
                if(i == match.NamedMap.end()) return false; // impossible
                result = i->second.second;
                break;
            }
            case RestHolder:
            {
                // Not enumerable
                return false;
            }
            case SubFunction:
            {
                // Not enumerable
                return false;
            }
            default:
            {
                switch(OPCODE(opcode))
                {
                    case cAdd:
                        result=0;
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            result += tmp;
                        }
                        break;
                    case cMul:
                        result=1;
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            result *= tmp;
                        }
                        break;
                    case cMin:
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            if(p == 0 || tmp < result) result = tmp;
                        }
                        break;
                    case cMax:
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            if(p == 0 || tmp > result) result = tmp;
                        }
                        break;
                    case cSin: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::sin(result); break;
                    case cCos: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::cos(result); break;
                    case cTan: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::tan(result); break;
                    case cAsin: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::asin(result); break;
                    case cAcos: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::acos(result); break;
                    case cAtan: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::atan(result); break;
                    case cSinh: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::sinh(result); break;
                    case cCosh: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::cosh(result); break;
                    case cTanh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::tanh(result); break;
#ifndef FP_NO_ASINH
                    case cAsinh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = asinh(result); break;
                    case cAcosh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = acosh(result); break;
                    case cAtanh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = atanh(result); break;
#endif
                    case cCeil: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::ceil(result); break;
                    case cFloor: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::floor(result); break;
                    case cLog: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::log(result); break;
                    case cLog2: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::log(result) * CONSTANT_L2I;
                                //result = std::log2(result);
                                break;
                    case cLog10: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::log10(result); break;
                    case cPow:
                    {
                        if(!pack.plist[index+0].GetConst(match, result))return false;
                        double tmp;
                        if(!pack.plist[index+1].GetConst(match, tmp))return false;
                        result = std::pow(result, tmp);
                        break;
                    }
                    case cMod:
                    {
                        if(!pack.plist[index+0].GetConst(match, result))return false;
                        double tmp;
                        if(!pack.plist[index+1].GetConst(match, tmp))return false;
                        result = std::fmod(result, tmp);
                        break;
                    }
                    default:
                        return false;
                }
            }
        }
        if(transformation == Negate) result = -result;
        if(transformation == Invert) result = 1.0 / result;
        return true;
    }

    void MatchedParams::SynthesizeTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        for(unsigned a=0; a<count; ++a)
        {
            const ParamSpec& param = pack.plist[index+a];
            if(param.opcode == RestHolder)
            {
                // Add children directly to this tree
                param.SynthesizeTree(tree, matcher, match);
            }
            else
            {
                FPoptimizer_CodeTree::CodeTree* subtree = new FPoptimizer_CodeTree::CodeTree;
                param.SynthesizeTree(*subtree, matcher, match);
                subtree->Sort();
                subtree->Recalculate_Hash_NoRecursion(); // rehash this, but not the children, nor the parent
                FPoptimizer_CodeTree::CodeTree::Param p(subtree, param.sign) ;
                tree.AddParam(p);
            }
        }
    }

    void MatchedParams::ReplaceParams(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        // Replace the 0-level params indicated in "match" with the ones we have

        // First, construct the tree recursively using the "match" info
        SynthesizeTree(tree, matcher, match);

        // Remove the indicated params
        std::sort(match.param_numbers.begin(), match.param_numbers.end());
        for(size_t a=match.param_numbers.size(); a-->0; )
        {
            size_t num = match.param_numbers[a];
            tree.DelParam(num);
        }
        tree.Sort();
        tree.Rehash(true); // rehash this and its parents, but not its children
    }

    void MatchedParams::ReplaceTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        CodeTreeMatch& match) const
    {
        // Replace the entire tree with one indicated by our Params[0]
        // Note: The tree is still constructed using the holders indicated in "match".
        std::vector<FPoptimizer_CodeTree::CodeTree::Param> OldParams = tree.Params;
        tree.Params.clear();
        pack.plist[index].SynthesizeTree(tree, matcher, match);

        tree.Sort();
        tree.Rehash(true);  // rehash this and its parents, but not its children
    }

    /* Synthesizes a new tree based on the given information
     * in ParamSpec. Assume the tree is empty, don't deallocate
     * anything. Don't touch Hash, Parent.
     */
    void ParamSpec::SynthesizeTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        switch(ParamMatchingType(opcode))
        {
            case RestHolder:
            {
                std::map<unsigned, std::vector<uint_fast64_t> >
                    ::const_iterator i = match.RestMap.find(index);

                assert(i != match.RestMap.end());

                /*std::cout << std::flush;
                fprintf(stderr, "Restmap %u, sign %d, size is %u -- params %u\n",
                    (unsigned) i->first, sign, (unsigned) i->second.size(),
                    (unsigned) tree.Params.size());*/

                for(size_t a=0; a<i->second.size(); ++a)
                {
                    uint_fast64_t hash = i->second[a];

                    std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP>
                        ::const_iterator j = match.trees.find(hash);

                    assert(j != match.trees.end());

                    FPoptimizer_CodeTree::CodeTree* subtree = j->second->Clone();
                    FPoptimizer_CodeTree::CodeTree::Param p(subtree, sign);
                    tree.AddParam(p);
                }
                /*fprintf(stderr, "- params size became %u\n", (unsigned)tree.Params.size());
                fflush(stderr);*/
                break;
            }
            case SubFunction:
            {
                const Function& fitem = pack.flist[index];
                tree.Opcode = fitem.opcode;
                const MatchedParams& mitem = pack.mlist[fitem.index];
                mitem.SynthesizeTree(tree, matcher, match);
                break;
            }
            case NamedHolder:
                if(!anyrepeat && minrepeat == 1)
                {
                    /* Literal parameter */
                    std::map<unsigned, std::pair<uint_fast64_t, size_t> >
                        ::const_iterator i = match.NamedMap.find(index);

                    assert(i != match.NamedMap.end());

                    uint_fast64_t hash = i->second.first;

                    std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP>
                        ::const_iterator j = match.trees.find(hash);

                    assert(j != match.trees.end());

                    tree.Opcode = j->second->Opcode;
                    switch(tree.Opcode)
                    {
                        case cImmed: tree.Value = j->second->Value; break;
                        case cVar:   tree.Var   = j->second->Var;  break;
                        case cFCall:
                        case cPCall: tree.Funcno = j->second->Funcno; break;
                    }

                    tree.SetParams(j->second->Params);
                    break;
                }
                // passthru; x+ is synthesized as the number, not as the tree
            case NumConstant:
            case ImmedHolder:
            default:
                tree.Opcode = cImmed;
                GetConst(match, tree.Value); // note: return value is ignored
                break;
        }
    }

#ifdef DEBUG_SUBSTITUTIONS
    void DumpParam(const ParamSpec& p)
    {
        //std::cout << "/*p" << (&p-pack.plist) << "*/";

        if(p.sign) std::cout << '~';
        if(p.transformation == Negate) std::cout << '-';
        if(p.transformation == Invert) std::cout << '/';

        switch(SpecialOpcode(p.opcode))
        {
            case NumConstant: std::cout << pack.clist[p.index]; break;
            case ImmedHolder: std::cout << ImmedHolderNames[p.index]; break;
            case NamedHolder: std::cout << NamedHolderNames[p.index]; break;
            case RestHolder: std::cout << '<' << p.index << '>'; break;
            case SubFunction: DumpFunction(pack.flist[p.index]); break;
            default:
            {
                std::string opcode = FP_GetOpcodeName(p.opcode).substr(1);
                for(size_t a=0; a<opcode.size(); ++a) opcode[a] = std::toupper(opcode[a]);
                std::cout << opcode << '(';
                for(unsigned a=0; a<p.count; ++a)
                {
                    if(a > 0) std::cout << ' ';
                    DumpParam(pack.plist[p.index+a]);
                }
                std::cout << " )";
            }
        }
        if(p.anyrepeat && p.minrepeat==1) std::cout << '*';
        if(p.anyrepeat && p.minrepeat==2) std::cout << '+';
    }

    void DumpParams(const MatchedParams& mitem)
    {
        //std::cout << "/*m" << (&mitem-pack.mlist) << "*/";

        if(mitem.type == PositionalParams) std::cout << '[';
        if(mitem.type == SelectedParams) std::cout << '{';

        for(unsigned a=0; a<mitem.count; ++a)
        {
            std::cout << ' ';
            DumpParam(pack.plist[mitem.index + a]);
        }

        if(mitem.type == PositionalParams) std::cout << " ]";
        if(mitem.type == SelectedParams) std::cout << " }";
    }

    void DumpFunction(const Function& fitem)
    {
        //std::cout << "/*f" << (&fitem-pack.flist) << "*/";

        std::cout << '(' << FP_GetOpcodeName(fitem.opcode);
        DumpParams(pack.mlist[fitem.index]);
        std::cout << ')';
    }
    void DumpTree(const FPoptimizer_CodeTree::CodeTree& tree)
    {
        //std::cout << "/*" << tree.Depth << "*/";
        const char* sep2 = "";
        switch(tree.Opcode)
        {
            case cImmed: std::cout << tree.Value; return;
            case cVar:   std::cout << "Var" << tree.Var; return;
            case cAdd: sep2 = " +"; break;
            case cMul: sep2 = " *"; break;
            case cAnd: sep2 = " &"; break;
            case cOr: sep2 = " |"; break;
            default:
                std::cout << FP_GetOpcodeName(tree.Opcode);
                if(tree.Opcode == cFCall || tree.Opcode == cPCall)
                    std::cout << ':' << tree.Funcno;
        }
        std::cout << '(';
        if(tree.Params.size() <= 1 && *sep2) std::cout << (sep2+1) << ' ';
        for(size_t a=0; a<tree.Params.size(); ++a)
        {
            if(a > 0) std::cout << ' ';
            if(tree.Params[a].sign) std::cout << '~';

            DumpTree(*tree.Params[a].param);

            if(tree.Params[a].param->Parent != &tree)
            {
                std::cout << "(?""?""?))";
            }

            if(a+1 < tree.Params.size()) std::cout << sep2;
        }
        std::cout << ')';
    }
    void DumpMatch(const Function& input,
                   const FPoptimizer_CodeTree::CodeTree& tree,
                   const MatchedParams& replacement,
                   const MatchedParams::CodeTreeMatch& matchrec,
                   bool DidMatch)
    {
        std::cout <<
            "Found " << (DidMatch ? "match" : "mismatch") << ":\n"
            "  Pattern    : ";
        DumpFunction(input);
        std::cout << "\n"
            "  Replacement: ";
        DumpParams(replacement);
        std::cout << "\n";

        std::cout <<
            "  Tree       : ";
        DumpTree(tree);
        std::cout << "\n";

        for(std::map<unsigned, std::pair<uint_fast64_t, size_t> >::const_iterator
            i = matchrec.NamedMap.begin(); i != matchrec.NamedMap.end(); ++i)
        {
            std::cout << "           " << NamedHolderNames[i->first] << " = ";
            DumpTree(*matchrec.trees.find(i->second.first)->second);
            std::cout << " (" << i->second.second << " matches)\n";
        }

        for(std::map<unsigned, double>::const_iterator
            i = matchrec.ImmedMap.begin(); i != matchrec.ImmedMap.end(); ++i)
        {
            std::cout << "           " << ImmedHolderNames[i->first] << " = ";
            std::cout << i->second << std::endl;
        }

        for(std::map<unsigned, std::vector<uint_fast64_t> >::const_iterator
            i = matchrec.RestMap.begin(); i != matchrec.RestMap.end(); ++i)
        {
            for(size_t a=0; a<i->second.size(); ++a)
            {
                uint_fast64_t hash = i->second[a];
                std::cout << "         <" << i->first << "> = ";
                DumpTree(*matchrec.trees.find(hash)->second);
                std::cout << std::endl;
            }
            if(i->second.empty())
                std::cout << "         <" << i->first << "> = <empty>\n";
        }
    }
#endif
}
#include "fpconfig.hh"
#include "fparser.hh"
#include "fptypes.hh"


using namespace FUNCTIONPARSERTYPES;

namespace FPoptimizer_CodeTree
{
    bool    CodeTree::IsImmed() const { return Opcode == cImmed; }
    bool    CodeTree::IsVar()   const { return Opcode == cVar; }
}

using namespace FPoptimizer_CodeTree;

void FunctionParser::Optimize()
{
    if(isOptimized) return;
    CopyOnWrite();

    //PrintByteCode(std::cout);

    FPoptimizer_CodeTree::CodeTreeP tree
        = CodeTree::GenerateFrom(data->ByteCode, data->Immed, *data);

    std::set<uint_fast64_t> optimized_children;
    while(FPoptimizer_Grammar::pack.glist[0].ApplyTo(optimized_children, *tree))
        {}

    optimized_children.clear();
    while(FPoptimizer_Grammar::pack.glist[1].ApplyTo(optimized_children, *tree))
        {}

    optimized_children.clear();
    while(FPoptimizer_Grammar::pack.glist[2].ApplyTo(optimized_children, *tree))
        {}

    tree->Sort_Recursive();

    std::vector<unsigned> byteCode;
    std::vector<double> immed;
    size_t stacktop_max = 0;
    tree->SynthesizeByteCode(byteCode, immed, stacktop_max);

    /*std::cout << std::flush;
    std::cerr << std::flush;
    fprintf(stderr, "Estimated stacktop %u\n", (unsigned)stacktop_max);
    fflush(stderr);*/

    if(data->StackSize != stacktop_max)
    {
        data->StackSize = stacktop_max;
        data->Stack.resize(stacktop_max);
    }

    data->ByteCode.swap(byteCode);
    data->Immed.swap(immed);

    //PrintByteCode(std::cout);

    isOptimized = true;
}
#include <cmath>
#include <list>
#include <cassert>

#include "fptypes.hh"


using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;

#ifndef FP_GENERATING_POWI_TABLE
static const unsigned MAX_POWI_BYTECODE_LENGTH = 15;
#else
static const unsigned MAX_POWI_BYTECODE_LENGTH = 999;
#endif
static const unsigned MAX_MULI_BYTECODE_LENGTH = 5;

#define POWI_TABLE_SIZE 256
#define POWI_WINDOW_SIZE 3
#ifndef FP_GENERATING_POWI_TABLE
static const
#endif
signed char powi_table[POWI_TABLE_SIZE] =
{
      0,   1,   1,   1,   2,   1,   3,   1, /*   0 -   7 */
      4,   1,   5,   1,   6,   1,  -2,   5, /*   8 -  15 */
      8,   1,   9,   1,  10,  -3,  11,   1, /*  16 -  23 */
     12,   5,  13,   9,  14,   1,  15,   1, /*  24 -  31 */
     16,   1,  17,  -5,  18,   1,  19,  13, /*  32 -  39 */
     20,   1,  21,   1,  22,   9,  -2,   1, /*  40 -  47 */
     24,   1,  25,  17,  26,   1,  27,  11, /*  48 -  55 */
     28,   1,  29,   8,  30,   1,  -2,   1, /*  56 -  63 */
     32,   1,  33,   1,  34,   1,  35,   1, /*  64 -  71 */
     36,   1,  37,  25,  38, -11,  39,   1, /*  72 -  79 */
     40,   9,  41,   1,  42,  17,   1,  29, /*  80 -  87 */
     44,   1,  45,   1,  46,  -3,  32,  19, /*  88 -  95 */
     48,   1,  49,  33,  50,   1,  51,   1, /*  96 - 103 */
     52,  35,  53,   8,  54,   1,  55,  37, /* 104 - 111 */
     56,   1,  57,  -5,  58,  13,  59, -17, /* 112 - 119 */
     60,   1,  61,  41,  62,  25,  -2,   1, /* 120 - 127 */
     64,   1,  65,   1,  66,   1,  67,  45, /* 128 - 135 */
     68,   1,  69,   1,  70,  48,  16,   8, /* 136 - 143 */
     72,   1,  73,  49,  74,   1,  75,   1, /* 144 - 151 */
     76,  17,   1,  -5,  78,   1,  32,  53, /* 152 - 159 */
     80,   1,  81,   1,  82,  33,   1,   2, /* 160 - 167 */
     84,   1,  85,  57,  86,   8,  87,  35, /* 168 - 175 */
     88,   1,  89,   1,  90,   1,  91,  61, /* 176 - 183 */
     92,  37,  93,  17,  94,  -3,  64,   2, /* 184 - 191 */
     96,   1,  97,  65,  98,   1,  99,   1, /* 192 - 199 */
    100,  67, 101,   8, 102,  41, 103,  69, /* 200 - 207 */
    104,   1, 105,  16, 106,  24, 107,   1, /* 208 - 215 */
    108,   1, 109,  73, 110,  17, 111,   1, /* 216 - 223 */
    112,  45, 113,  32, 114,   1, 115, -33, /* 224 - 231 */
    116,   1, 117,  -5, 118,  48, 119,   1, /* 232 - 239 */
    120,   1, 121,  81, 122,  49, 123,  13, /* 240 - 247 */
    124,   1, 125,   1, 126,   1,  -2,  85  /* 248 - 255 */
}; /* as in gcc, but custom-optimized for stack calculation */
static const int POWI_CACHE_SIZE = 256;

#define FPO(x) /**/
//#define FPO(x) x

static const struct SequenceOpCode
{
    double basevalue;
    unsigned op_flip;
    unsigned op_normal, op_normal_flip;
    unsigned op_inverse, op_inverse_flip;
} AddSequence = {0.0, cNeg, cAdd, cAdd, cSub, cRSub },
  MulSequence = {1.0, cInv, cMul, cMul, cDiv, cRDiv };

class FPoptimizer_CodeTree::CodeTree::ByteCodeSynth
{
public:
    ByteCodeSynth()
        : ByteCode(), Immed(), StackTop(0), StackMax(0)
    {
        /* estimate the initial requirements as such */
        ByteCode.reserve(64);
        Immed.reserve(8);
    }

    void Pull(std::vector<unsigned>& bc,
              std::vector<double>&   imm,
              size_t& StackTop_max)
    {
        ByteCode.swap(bc);
        Immed.swap(imm);
        StackTop_max = StackMax;
    }

    size_t GetByteCodeSize() const { return ByteCode.size(); }
    size_t GetStackTop()     const { return StackTop; }

    void PushVar(unsigned varno)
    {
        ByteCode.push_back(varno);
        SetStackTop(StackTop+1);
    }

    void PushImmed(double immed)
    {
        ByteCode.push_back(cImmed);
        Immed.push_back(immed);
        SetStackTop(StackTop+1);
    }

    void StackTopIs(uint_fast64_t hash)
    {
        if(StackTop > 0)
        {
            StackHash[StackTop-1].first = true;
            StackHash[StackTop-1].second = hash;
        }
    }

    void AddOperation(unsigned opcode, unsigned eat_count, unsigned produce_count = 1)
    {
        SetStackTop(StackTop - eat_count);

        if(opcode == cMul && ByteCode.back() == cDup)
            ByteCode.back() = cSqr;
        else
            ByteCode.push_back(opcode);
        SetStackTop(StackTop + produce_count);
    }

    void DoPopNMov(size_t targetpos, size_t srcpos)
    {
        ByteCode.push_back(cPopNMov);
        ByteCode.push_back(targetpos);
        ByteCode.push_back(srcpos);

        SetStackTop(srcpos+1);
        StackHash[targetpos] = StackHash[srcpos];
        SetStackTop(targetpos+1);
    }

    void DoDup(size_t src_pos)
    {
        if(src_pos == StackTop-1)
        {
            ByteCode.push_back(cDup);
        }
        else
        {
            ByteCode.push_back(cFetch);
            ByteCode.push_back(src_pos);
        }
        SetStackTop(StackTop + 1);
        StackHash[StackTop-1] = StackHash[src_pos];
    }

    bool FindAndDup(uint_fast64_t hash)
    {
        for(size_t a=StackHash.size(); a-->0; )
        {
            if(StackHash[a].first && StackHash[a].second == hash)
            {
                DoDup(a);
                return true;
            }
        }
        return false;
    }

    void SynthIfStep1(size_t& ofs)
    {
        SetStackTop(StackTop-1); // the If condition was popped.

        ofs = ByteCode.size();
        ByteCode.push_back(cIf);
        ByteCode.push_back(0); // code index
        ByteCode.push_back(0); // Immed index
    }
    void SynthIfStep2(size_t& ofs)
    {
        SetStackTop(StackTop-1); // ignore the pushed then-branch result.

        ByteCode[ofs+1] = ByteCode.size()+2;
        ByteCode[ofs+2] = Immed.size();

        ofs = ByteCode.size();
        ByteCode.push_back(cJump);
        ByteCode.push_back(0); // code index
        ByteCode.push_back(0); // Immed index
    }
    void SynthIfStep3(size_t& ofs)
    {
        SetStackTop(StackTop-1); // ignore the pushed else-branch result.

        ByteCode[ofs+1] = ByteCode.size()-1;
        ByteCode[ofs+2] = Immed.size();

        SetStackTop(StackTop+1); // one or the other was pushed.
    }

private:
    void SetStackTop(size_t value)
    {
        StackTop = value;
        if(StackTop > StackMax) StackMax = StackTop;
        StackHash.resize(value);
    }

private:
    std::vector<unsigned> ByteCode;
    std::vector<double>   Immed;

    std::vector<std::pair<bool/*known*/, uint_fast64_t/*hash*/> > StackHash;
    size_t StackTop;
    size_t StackMax;
};

namespace
{
    using namespace FPoptimizer_CodeTree;

    bool AssembleSequence(
                  CodeTree& tree, long count,
                  const SequenceOpCode& sequencing,
                  CodeTree::ByteCodeSynth& synth,
                  size_t max_bytecode_grow_length);

    class PowiCache
    {
    private:
        int cache[POWI_CACHE_SIZE];
        int cache_needed[POWI_CACHE_SIZE];

    public:
        PowiCache()
            : cache(), cache_needed() /* Assume we have no factors in the cache */
        {
            /* Decide which factors we would need multiple times.
             * Output:
             *   cache[]        = these factors were generated
             *   cache_needed[] = number of times these factors were desired
             */
            cache[1] = 1; // We have this value already.
        }

        bool Plan_Add(long value, int count)
        {
            if(value >= POWI_CACHE_SIZE) return false;
            //FPO(fprintf(stderr, "%ld will be needed %d times more\n", count, need_count));
            cache_needed[value] += count;
            return cache[value];
        }

        void Plan_Has(long value)
        {
            if(value < POWI_CACHE_SIZE)
                cache[value] = 1; // This value has been generated
        }

        void Start(size_t value1_pos)
        {
            for(int n=2; n<POWI_CACHE_SIZE; ++n)
                cache[n] = -1; /* Stack location for each component */

            Remember(1, value1_pos);

            DumpContents();
        }

        int Find(long value) const
        {
            if(value < POWI_CACHE_SIZE)
            {
                if(cache[value] >= 0)
                {
                    // found from the cache
                    FPO(fprintf(stderr, "* I found %ld from cache (%u,%d)\n",
                        value, (unsigned)cache[value], cache_needed[value]));
                    return cache[value];
                }
            }
            return -1;
        }

        void Remember(long value, size_t stackpos)
        {
            if(value >= POWI_CACHE_SIZE) return;

            FPO(fprintf(stderr, "* Remembering that %ld can be found at %u (%d uses remain)\n",
                value, (unsigned)stackpos, cache_needed[value]));
            cache[value] = stackpos;
        }

        void DumpContents() const
        {
            FPO(for(int a=1; a<POWI_CACHE_SIZE; ++a)
                if(cache[a] >= 0 || cache_needed[a] > 0)
                {
                    fprintf(stderr, "== cache: sp=%d, val=%d, needs=%d\n",
                        cache[a], a, cache_needed[a]);
                })
        }

        int UseGetNeeded(long value)
        {
            if(value >= 0 && value < POWI_CACHE_SIZE)
                return --cache_needed[value];
            return 0;
        }
    };

    size_t AssembleSequence_Subdivide(
        long count,
        PowiCache& cache,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth);

    void Subdivide_Combine(
        size_t apos, long aval,
        size_t bpos, long bval,
        PowiCache& cache,

        unsigned cumulation_opcode,
        unsigned cimulation_opcode_flip,

        CodeTree::ByteCodeSynth& synth);
}

namespace
{
    typedef
        std::map<uint_fast64_t,  std::pair<size_t, CodeTreeP> >
        TreeCountType;

    void FindTreeCounts(TreeCountType& TreeCounts, CodeTreeP tree)
    {
        TreeCountType::iterator i = TreeCounts.lower_bound(tree->Hash);
        if(i == TreeCounts.end() || i->first != tree->Hash)
            TreeCounts.insert(i, std::make_pair(tree->Hash, std::make_pair(size_t(1), tree)));
        else
            i->second.first += 1;

        for(size_t a=0; a<tree->Params.size(); ++a)
            FindTreeCounts(TreeCounts, tree->Params[a].param);
    }

    void RememberRecursivelyHashList(std::set<uint_fast64_t>& hashlist,
                                     CodeTreeP tree)
    {
        hashlist.insert(tree->Hash);
        for(size_t a=0; a<tree->Params.size(); ++a)
            RememberRecursivelyHashList(hashlist, tree->Params[a].param);
    }
}

namespace FPoptimizer_CodeTree
{
    void CodeTree::SynthesizeByteCode(
        std::vector<unsigned>& ByteCode,
        std::vector<double>&   Immed,
        size_t& stacktop_max)
    {
        ByteCodeSynth synth;

        /* Find common subtrees */
        TreeCountType TreeCounts;
        FindTreeCounts(TreeCounts, this);

        /* Synthesize some of the most common ones */
        std::set<uint_fast64_t> AlreadyDoneTrees;
    FindMore: ;
        size_t best_score = 0;
        TreeCountType::const_iterator synth_it;
        for(TreeCountType::const_iterator
            i = TreeCounts.begin();
            i != TreeCounts.end();
            ++i)
        {
            size_t score = i->second.first;
            if(score < 2) continue; // It must always occur at least twice
            if(i->second.second->Depth < 2) continue; // And it must not be a simple expression
            if(AlreadyDoneTrees.find(i->first)
            != AlreadyDoneTrees.end()) continue; // And it must not yet have been synthesized
            score *= i->second.second->Depth;
            if(score > best_score)
                { best_score = score; synth_it = i; }
        }
        if(best_score > 0)
        {
            /* Synthesize the selected tree */
            synth_it->second.second->SynthesizeByteCode(synth);
            /* Add the tree and all its children to the AlreadyDoneTrees list,
             * to prevent it from being re-synthesized
             */
            RememberRecursivelyHashList(AlreadyDoneTrees, synth_it->second.second);
            goto FindMore;
        }

        /* Then synthesize the actual expression */
        SynthesizeByteCode(synth);
      #ifndef FP_DISABLE_EVAL
        /* Ensure that the expression result is
         * the only thing that remains in the stack
         */
        /* Removed: Fparser does not seem to care! */
        /* But if cEval is supported, it still needs to be done. */
        if(synth.GetStackTop() > 1)
            synth.DoPopNMov(0, synth.GetStackTop()-1);
      #endif
        synth.Pull(ByteCode, Immed, stacktop_max);
    }

    void CodeTree::SynthesizeByteCode(ByteCodeSynth& synth)
    {
        // If the synth can already locate our operand in the stack,
        // never mind synthesizing it again, just dup it.
        if(synth.FindAndDup(Hash))
        {
            return;
        }

        switch(Opcode)
        {
            case cVar:
                synth.PushVar(GetVar());
                break;
            case cImmed:
                synth.PushImmed(GetImmed());
                break;
            case cAdd:
            case cMul:
            case cMin:
            case cMax:
            case cAnd:
            case cOr:
            {
                // Operand re-sorting:
                // If the first param has a sign, try to find a param
                // that does _not_ have a sign and put it first.
                // This can be done because params are commutative
                // when they are grouped with their signs.
                if(!Params.empty() && Params[0].sign)
                {
                    for(size_t a=1; a<Params.size(); ++a)
                        if(!Params[a].sign)
                        {
                            std::swap(Params[0], Params[a]);
                            break;
                        }
                }

                // Try to ensure that Immeds don't have a sign
                for(size_t a=0; a<Params.size(); ++a)
                {
                    CodeTreeP& param = Params[a].param;
                    if(Params[a].sign && param->IsImmed())
                        switch(Opcode)
                        {
                            case cAdd: param->NegateImmed(); Params[a].sign=false; break;
                            case cMul: if(param->GetImmed() == 0.0) break;
                                       param->InvertImmed(); Params[a].sign=false; break;
                            case cAnd:
                            case cOr:  param->NotTheImmed(); Params[a].sign=false; break;
                        }
                }

                if(Opcode == cMul) // Special treatment for cMul sequences
                {
                    // If the paramlist contains an Immed, and that Immed
                    // fits in a long-integer, try to synthesize it
                    // as add-sequences instead.
                    for(size_t a=0; a<Params.size(); ++a)
                    {
                        Param p = Params[a];
                        CodeTreeP& param = p.param;
                        if(!p.sign && param->IsLongIntegerImmed())
                        {
                            long value = param->GetLongIntegerImmed();
                            Params.erase(Params.begin()+a);

                            bool success = AssembleSequence(
                                *this, value, AddSequence,
                                synth,
                                MAX_MULI_BYTECODE_LENGTH);

                            // Readd the token so that we don't need
                            // to deal with allocationd/deallocation here.
                            Params.insert(Params.begin()+a, p);

                            if(success)
                            {
                                // this tree was treated just fine
                                synth.StackTopIs(Hash);
                                return;
                            }
                        }
                    }
                }

                int n_stacked = 0;
                for(size_t a=0; a<Params.size(); ++a)
                {
                    CodeTreeP const & param = Params[a].param;
                    bool               sign = Params[a].sign;

                    param->SynthesizeByteCode(synth);
                    ++n_stacked;

                    if(sign) // Is the operand negated/inverted?
                    {
                        if(n_stacked == 1)
                        {
                            // Needs unary negation/invertion. Decide how to accomplish it.
                            switch(Opcode)
                            {
                                case cAdd:
                                    synth.AddOperation(cNeg, 1); // stack state: -1+1 = +0
                                    break;
                                case cMul:
                                    synth.AddOperation(cInv, 1); // stack state: -1+1 = +0
                                    break;
                                case cAnd:
                                case cOr:
                                    synth.AddOperation(cNot, 1); // stack state: -1+1 = +0
                                    break;
                            }
                            // Note: We could use RDiv or RSub when the first
                            // token is negated/inverted and the second is not, to
                            // avoid cNeg/cInv/cNot, but thanks to the operand
                            // re-sorting in the beginning of this code, this
                            // situation never arises.
                            // cNeg/cInv/cNot is only synthesized when the group
                            // consists entirely of negated/inverted items.
                        }
                        else
                        {
                            // Needs binary negation/invertion. Decide how to accomplish it.
                            switch(Opcode)
                            {
                                case cAdd:
                                    synth.AddOperation(cSub, 2); // stack state: -2+1 = -1
                                    break;
                                case cMul:
                                    synth.AddOperation(cDiv, 2); // stack state: -2+1 = -1
                                    break;
                                case cAnd:
                                case cOr:
                                    synth.AddOperation(cNot,   1);   // stack state: -1+1 = +0
                                    synth.AddOperation(Opcode, 2); // stack state: -2+1 = -1
                                    break;
                            }
                            n_stacked = n_stacked - 2 + 1;
                        }
                    }
                    else if(n_stacked > 1)
                    {
                        // Cumulate at the earliest opportunity.
                        synth.AddOperation(Opcode, 2); // stack state: -2+1 = -1
                        n_stacked = n_stacked - 2 + 1;
                    }
                }
                if(n_stacked == 0)
                {
                    // Uh, we got an empty cAdd/cMul/whatever...
                    // Synthesize a default value.
                    // This should never happen.
                    switch(Opcode)
                    {
                        case cAdd:
                        case cOr:
                            synth.PushImmed(0);
                            break;
                        case cMul:
                        case cAnd:
                            synth.PushImmed(1);
                            break;
                        case cMin:
                        case cMax:
                            //synth.PushImmed(NaN);
                            synth.PushImmed(0);
                            break;
                    }
                    ++n_stacked;
                }
                assert(n_stacked == 1);
                break;
            }
            case cPow:
            {
                const Param& p0 = Params[0];
                const Param& p1 = Params[1];

                if(!p1.param->IsLongIntegerImmed()
                || !AssembleSequence( /* Optimize integer exponents */
                        *p0.param, p1.param->GetLongIntegerImmed(),
                        MulSequence,
                        synth,
                        MAX_POWI_BYTECODE_LENGTH)
                  )
                {
                    p0.param->SynthesizeByteCode(synth);
                    p1.param->SynthesizeByteCode(synth);
                    synth.AddOperation(Opcode, 2);
                }
                break;
            }
            case cIf:
            {
                size_t ofs;
                // If the parameter amount is != 3, we're screwed.
                Params[0].param->SynthesizeByteCode(synth); // expression
                synth.SynthIfStep1(ofs);
                Params[1].param->SynthesizeByteCode(synth); // true branch
                synth.SynthIfStep2(ofs);
                Params[2].param->SynthesizeByteCode(synth); // false branch
                synth.SynthIfStep3(ofs);
                break;
            }
            case cFCall:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                synth.AddOperation(Funcno, 0, 0);
                break;
            }
            case cPCall:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                synth.AddOperation(Funcno, 0, 0);
                break;
            }
            default:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                break;
            }
        }
        synth.StackTopIs(Hash);
    }
}

namespace
{
    void PlanNtimesCache
        (long value,
         PowiCache& cache,
         int need_count,
         int recursioncount=0)
    {
        if(value < 1) return;

    #ifdef FP_GENERATING_POWI_TABLE
        if(recursioncount > 32) throw false;
    #endif

        if(cache.Plan_Add(value, need_count)) return;

        long half = 1;
        if(value < POWI_TABLE_SIZE)
        {
            half = powi_table[value];
        }
        else if(value & 1)
        {
            half = value & ((1 << POWI_WINDOW_SIZE) - 1); // that is, value & 7
        }
        else
        {
            half = value / 2;
        }

        long otherhalf = value-half;
        if(half > otherhalf || half<0) std::swap(half,otherhalf);

        FPO(fprintf(stderr, "value=%ld, half=%ld, otherhalf=%ld\n", value,half,otherhalf));

        if(half == otherhalf)
        {
            PlanNtimesCache(half,      cache, 2, recursioncount+1);
        }
        else
        {
            PlanNtimesCache(half,      cache, 1, recursioncount+1);
            PlanNtimesCache(otherhalf>0?otherhalf:-otherhalf,
                                       cache, 1, recursioncount+1);
        }

        cache.Plan_Has(value);
    }

    bool AssembleSequence(
        CodeTree& tree, long count,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth,
        size_t max_bytecode_grow_length)
    {
        CodeTree::ByteCodeSynth backup = synth;
        const size_t bytecodesize_backup = synth.GetByteCodeSize();

        if(count == 0)
        {
            synth.PushImmed(sequencing.basevalue);
        }
        else
        {
            tree.SynthesizeByteCode(synth);

            if(count < 0)
            {
                synth.AddOperation(sequencing.op_flip, 1);
                count = -count;
            }

            if(count > 1)
            {
                /* To prevent calculating the same factors over and over again,
                 * we use a cache. */
                PowiCache cache;
                PlanNtimesCache(count, cache, 1);

                size_t stacktop_desired = synth.GetStackTop();

                cache.Start( synth.GetStackTop()-1 );

                FPO(fprintf(stderr, "Calculating result for %ld...\n", count));
                size_t res_stackpos = AssembleSequence_Subdivide(
                    count, cache, sequencing,
                    synth);

                size_t n_excess = synth.GetStackTop() - stacktop_desired;
                if(n_excess > 0 || res_stackpos != stacktop_desired-1)
                {
                    // Remove the cache values
                    synth.DoPopNMov(stacktop_desired-1, res_stackpos);
                }
            }
        }

        size_t bytecode_grow_amount = synth.GetByteCodeSize() - bytecodesize_backup;
        if(bytecode_grow_amount > max_bytecode_grow_length)
        {
            synth = backup;
            return false;
        }
        return true;
    }

    size_t AssembleSequence_Subdivide(
        long value,
        PowiCache& cache,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth)
    {
        int cachepos = cache.Find(value);
        if(cachepos >= 0)
        {
            // found from the cache
            return cachepos;
        }

        long half = 1;
        if(value < POWI_TABLE_SIZE)
        {
            half = powi_table[value];
        }
        else if(value & 1)
        {
            half = value & ((1 << POWI_WINDOW_SIZE) - 1); // that is, value & 7
        }
        else
        {
            half = value / 2;
        }
        long otherhalf = value-half;
        if(half > otherhalf || half<0) std::swap(half,otherhalf);

        FPO(fprintf(stderr, "* I want %ld, my plan is %ld + %ld\n", value, half, value-half));

        if(half == otherhalf)
        {
            size_t half_pos = AssembleSequence_Subdivide(half, cache, sequencing, synth);

            // self-cumulate the subdivide result
            Subdivide_Combine(half_pos,half, half_pos,half, cache,
                sequencing.op_normal, sequencing.op_normal_flip,
                synth);
        }
        else
        {
            long part1 = half;
            long part2 = otherhalf>0?otherhalf:-otherhalf;

            size_t part1_pos = AssembleSequence_Subdivide(part1, cache, sequencing, synth);
            size_t part2_pos = AssembleSequence_Subdivide(part2, cache, sequencing, synth);

            FPO(fprintf(stderr, "Subdivide(%ld: %ld, %ld)\n", value, half, otherhalf));

            Subdivide_Combine(part1_pos,part1, part2_pos,part2, cache,
                otherhalf>0 ? sequencing.op_normal      : sequencing.op_inverse,
                otherhalf>0 ? sequencing.op_normal_flip : sequencing.op_inverse_flip,
                synth);
        }
        size_t stackpos = synth.GetStackTop()-1;
        cache.Remember(value, stackpos);
        cache.DumpContents();
        return stackpos;
    }

    void Subdivide_Combine(
        size_t apos, long aval,
        size_t bpos, long bval,
        PowiCache& cache,
        unsigned cumulation_opcode,
        unsigned cumulation_opcode_flip,
        CodeTree::ByteCodeSynth& synth)
    {
        /*FPO(fprintf(stderr, "== making result for (sp=%u, val=%d, needs=%d) and (sp=%u, val=%d, needs=%d), stacktop=%u\n",
            (unsigned)apos, aval, aval>=0 ? cache_needed[aval] : -1,
            (unsigned)bpos, bval, bval>=0 ? cache_needed[bval] : -1,
            (unsigned)synth.GetStackTop()));*/

        // Figure out whether we can trample a and b
        int a_needed = cache.UseGetNeeded(aval);
        int b_needed = cache.UseGetNeeded(bval);

        bool flipped = false;

        #define DUP_BOTH() do { \
            if(apos < bpos) { size_t tmp=apos; apos=bpos; bpos=tmp; flipped=!flipped; } \
            FPO(fprintf(stderr, "-> dup(%u) dup(%u) op\n", (unsigned)apos, (unsigned)bpos)); \
            synth.DoDup(apos); \
            synth.DoDup(apos==bpos ? synth.GetStackTop()-1 : bpos); } while(0)
        #define DUP_ONE(p) do { \
            FPO(fprintf(stderr, "-> dup(%u) op\n", (unsigned)p)); \
            synth.DoDup(p); \
        } while(0)

        if(a_needed > 0)
        {
            if(b_needed > 0)
            {
                // If they must both be preserved, make duplicates
                // First push the one that is at the larger stack
                // address. This increases the odds of possibly using cDup.
                DUP_BOTH();

                //SCENARIO 1:
                // Input:  x B A x x
                // Temp:   x B A x x A B
                // Output: x B A x x R
                //SCENARIO 2:
                // Input:  x A B x x
                // Temp:   x A B x x B A
                // Output: x A B x x R
            }
            else
            {
                // A must be preserved, but B can be trampled over

                // SCENARIO 1:
                //  Input:  x B x x A
                //   Temp:  x B x x A A B   (dup both, later first)
                //  Output: x B x x A R
                // SCENARIO 2:
                //  Input:  x A x x B
                //   Temp:  x A x x B A
                //  Output: x A x x R       -- only commutative cases
                // SCENARIO 3:
                //  Input:  x x x B A
                //   Temp:  x x x B A A B   (dup both, later first)
                //  Output: x x x B A R
                // SCENARIO 4:
                //  Input:  x x x A B
                //   Temp:  x x x A B A     -- only commutative cases
                //  Output: x x x A R
                // SCENARIO 5:
                //  Input:  x A B x x
                //   Temp:  x A B x x A B   (dup both, later first)
                //  Output: x A B x x R

                // if B is not at the top, dup both.
                if(bpos != synth.GetStackTop()-1)
                    DUP_BOTH();    // dup both
                else
                {
                    DUP_ONE(apos); // just dup A
                    flipped=!flipped;
                }
            }
        }
        else if(b_needed > 0)
        {
            // B must be preserved, but A can be trampled over
            // This is a mirror image of the a_needed>0 case, so I'll cut the chase
            if(apos != synth.GetStackTop()-1)
                DUP_BOTH();
            else
                DUP_ONE(bpos);
        }
        else
        {
            // Both can be trampled over.
            // SCENARIO 1:
            //  Input:  x B x x A
            //   Temp:  x B x x A B
            //  Output: x B x x R
            // SCENARIO 2:
            //  Input:  x A x x B
            //   Temp:  x A x x B A
            //  Output: x A x x R       -- only commutative cases
            // SCENARIO 3:
            //  Input:  x x x B A
            //  Output: x x x R         -- only commutative cases
            // SCENARIO 4:
            //  Input:  x x x A B
            //  Output: x x x R
            // SCENARIO 5:
            //  Input:  x A B x x
            //   Temp:  x A B x x A B   (dup both, later first)
            //  Output: x A B x x R
            // SCENARIO 6:
            //  Input:  x x x C
            //   Temp:  x x x C C   (c is both A and B)
            //  Output: x x x R

            if(apos == bpos && apos == synth.GetStackTop()-1)
                DUP_ONE(apos); // scenario 6
            else if(apos == synth.GetStackTop()-1 && bpos == synth.GetStackTop()-2)
            {
                FPO(fprintf(stderr, "-> op\n")); // scenario 3
                flipped=!flipped;
            }
            else if(apos == synth.GetStackTop()-2 && bpos == synth.GetStackTop()-1)
                FPO(fprintf(stderr, "-> op\n")); // scenario 4
            else if(apos == synth.GetStackTop()-1)
                DUP_ONE(bpos); // scenario 1
            else if(bpos == synth.GetStackTop()-1)
            {
                DUP_ONE(apos); // scenario 2
                flipped=!flipped;
            }
            else
                DUP_BOTH(); // scenario 5
        }
        // Add them together.
        synth.AddOperation(flipped ? cumulation_opcode_flip : cumulation_opcode, 2);
    }
}
#include <cmath>
#include <cassert>

#include "fptypes.hh"

#include "fparser.hh"


using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;


namespace FPoptimizer_CodeTree
{
    class CodeTreeParserData
    {
    private:
        std::vector<CodeTreeP> stack;
    public:
        CodeTreeParserData() : stack() { }

        void Eat(unsigned nparams, OPCODE opcode)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = opcode;
            size_t stackhead = stack.size() - nparams;
            for(unsigned a=0; a<nparams; ++a)
            {
                CodeTree::Param param;
                param.param = stack[stackhead + a];
                param.sign  = false;
                newnode->AddParam(param);
            }
            stack.resize(stackhead);
            stack.push_back(newnode);
        }

        void EatFunc(unsigned params, OPCODE opcode, unsigned funcno)
        {
            Eat(params, opcode);
            stack.back()->Funcno = funcno;
        }

        void AddConst(double value)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = cImmed;
            newnode->Value  = value;
            stack.push_back(newnode);
        }

        void AddVar(unsigned varno)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = cVar;
            newnode->Var    = varno;
            stack.push_back(newnode);
        }

        void SetLastOpParamSign(unsigned paramno)
        {
            stack.back()->Params[paramno].sign = true;
        }

        void SwapLastTwoInStack()
        {
            std::swap(stack[stack.size()-1],
                      stack[stack.size()-2]);
        }

        void Dup()
        {
            stack.push_back(stack.back()->Clone());
        }

        CodeTreeP PullResult()
        {
            CodeTreeP result = stack.back();
            stack.resize(stack.size()-1);
            result->Rehash(false);
            result->Sort_Recursive();
            return result;
        }

        void CheckConst()
        {
            // Check if the last token on stack can be optimized with constant math
            CodeTreeP result = stack.back();
            result->ConstantFolding();
        }
    private:
        CodeTreeParserData(const CodeTreeParserData&);
        CodeTreeParserData& operator=(const CodeTreeParserData&);
    };

    CodeTreeP CodeTree::GenerateFrom(
        const std::vector<unsigned>& ByteCode,
        const std::vector<double>& Immed,
        const FunctionParser::Data& fpdata)
    {
        CodeTreeParserData data;
        std::vector<size_t> labels;

        for(size_t IP=0, DP=0; ; ++IP)
        {
            while(!labels.empty() && labels.back() == IP)
            {
                // The "else" of an "if" ends here
                data.Eat(3, cIf);
                labels.erase(labels.end()-1);
            }
            if(IP >= ByteCode.size()) break;

            unsigned opcode = ByteCode[IP];
            if(OPCODE(opcode) >= VarBegin)
            {
                data.AddVar(opcode);
            }
            else
            {
                switch(opcode)
                {
                    // Specials
                    case cIf:
                        IP += 2;
                        continue;
                    case cJump:
                        labels.push_back(ByteCode[IP+1]+1);
                        IP += 2;
                        continue;
                    case cImmed:
                        data.AddConst(Immed[DP++]);
                        break;
                    case cDup:
                        data.Dup();
                        break;
                    case cNop:
                        break;
                    case cFCall:
                    {
                        unsigned funcno = ByteCode[++IP];
                        unsigned params = fpdata.FuncPtrs[funcno].params;
                        data.EatFunc(params, OPCODE(opcode), funcno);
                        break;
                    }
                    case cPCall:
                    {
                        unsigned funcno = ByteCode[++IP];
                        unsigned params = fpdata.FuncParsers[funcno].params;
                        data.EatFunc(params, OPCODE(opcode), funcno);
                        break;
                    }
                    // Unary operators requiring special attention
                    case cInv:
                        data.Eat(1, cMul); // Unary division is inverse multiplying
                        data.SetLastOpParamSign(0);
                        break;
                    case cNeg:
                        data.Eat(1, cAdd); // Unary minus is negative adding.
                        data.SetLastOpParamSign(0);
                        break;
                    case cSqr:
                        data.Dup();
                        data.Eat(2, cMul);
                        break;
                    // Unary functions requiring special attention
                    case cDeg:
                        data.AddConst(CONSTANT_DR);
                        data.Eat(2, cMul);
                        break;
                    case cRad:
                        data.AddConst(CONSTANT_RD);
                        data.Eat(2, cMul);
                        break;
                    case cExp:
                        data.AddConst(CONSTANT_E);
                        data.SwapLastTwoInStack();
                        data.Eat(2, cPow);
                        break;
                    case cSqrt:
                        data.AddConst(0.5);
                        data.Eat(2, cPow);
                        break;
                    case cCot:
                        data.Eat(1, cTan);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cCsc:
                        data.Eat(1, cSin);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cSec:
                        data.Eat(1, cCos);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cLog10:
                        data.Eat(1, cLog);
                        data.AddConst(CONSTANT_L10I);
                        data.Eat(2, cMul);
                        break;
                    case cLog2:
                        data.Eat(1, cLog);
                        data.AddConst(CONSTANT_L2I);
                        data.Eat(2, cMul);
                        break;
                    // Binary operators requiring special attention
                    case cSub:
                        data.Eat(2, cAdd); // Minus is negative adding
                        data.SetLastOpParamSign(1);
                        break;
                    case cRSub:
                        data.Eat(2, cAdd);
                        data.SetLastOpParamSign(0); // negate param0 instead of param1
                        break;
                    case cDiv:
                        data.Eat(2, cMul); // Divide is inverse multiply
                        data.SetLastOpParamSign(1);
                        break;
                    case cRDiv:
                        data.Eat(2, cMul);
                        data.SetLastOpParamSign(0); // invert param0 instead of param1
                        break;
                    // Binary operators not requiring special attention
                    case cAdd: case cMul:
                    case cMod: case cPow:
                    case cEqual: case cLess: case cGreater:
                    case cNEqual: case cLessOrEq: case cGreaterOrEq:
                    case cAnd: case cOr:
                        data.Eat(2, OPCODE(opcode));
                        break;
                    // Unary operators not requiring special attention
                    case cNot:
                        data.Eat(1, OPCODE(opcode));
                        break;
                    // Other functions
#ifndef FP_DISABLE_EVAL
                    case cEval:
                    {
                        unsigned paramcount = fpdata.variableRefs.size();
                        data.Eat(paramcount, OPCODE(opcode));
                        break;
                    }
#endif
                    default:
                        unsigned funcno = opcode-cAbs;
                        assert(funcno < FUNC_AMOUNT);
                        const FuncDefinition& func = Functions[funcno];
                        data.Eat(func.params, OPCODE(opcode));
                        break;
                }
            }
            data.CheckConst();
        }
        return data.PullResult();
    }
}

#endif
