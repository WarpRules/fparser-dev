//===========================================
// Function parser v3.1 optimizer by Bisqwit
//===========================================

/* NOTE:
   This is a concatenation of all the header and source files of the
   original optimizer source code. All the code has been concatenated
   into this single file for convenience of usage (in other words, to
   simply use the optimizer, it's enough to add this file to the project
   rather than a multitude of files which the original optimizer source
   code is composed of).

   Thus this file exists for the usage of the Function parser library
   only, and is not suitable for developing it further. If you want to
   develop the library further, you should download the development
   version of the library, which has all the original source files.
 */

#include "fpconfig.hh"
#ifdef FP_SUPPORT_OPTIMIZER

#include <stdint.h>
#include <vector>

#include "fpconfig.hh"
#include "fparser.hh"

namespace FPoptimizer_Grammar
{
    class Grammar;
}

namespace FPoptimizer_CodeTree
{
    class CodeTreeParserData;
    class CodeTree;

    class CodeTreeP
    {
    public:
        CodeTreeP()                   : p(0)   { }
        CodeTreeP(CodeTree*        b) : p(b)   { Birth(); }
        CodeTreeP(const CodeTreeP& b) : p(&*b) { Birth(); }

        inline CodeTree& operator* () const { return *p; }
        inline CodeTree* operator->() const { return p; }

        CodeTreeP& operator= (CodeTree*        b) { Set(b); return *this; }
        CodeTreeP& operator= (const CodeTreeP& b) { Set(&*b); return *this; }

        ~CodeTreeP() { Forget(); }

    private:
        inline static void Have(CodeTree* p2);
        inline void Forget();
        inline void Birth();
        inline void Set(CodeTree* p2);
    private:
        CodeTree* p;
    };

    class CodeTree
    {
        friend class CodeTreeParserData;
        friend class CodeTreeP;

        int RefCount;

    public:
        /* Describing the codetree node */
        unsigned Opcode;
        union
        {
            double   Value;   // In case of cImmed: value of the immed
            unsigned Var;     // In case of cVar:   variable number
            unsigned Funcno;  // In case of cFCall or cPCall
        };
        struct Param
        {
            CodeTreeP param; // param node
            bool      sign;  // true = negated or inverted

            Param()                           : param(),  sign()  {}
            Param(CodeTree*        p, bool s) : param(p), sign(s) {}
            Param(const CodeTreeP& p, bool s) : param(p), sign(s) {}
        };

        // Parameters for the function
        //  These use the sign:
        //   For cAdd: operands to add together (0 to n)
        //             sign indicates that the value is negated before adding (0-x)
        //   For cMul: operands to multiply together (0 to n)
        //             sign indicates that the value is inverted before multiplying (1/x)
        //   For cAnd: operands to bitwise-and together (0 to n)
        //             sign indicates that the value is inverted before anding (!x)
        //   For cOr:  operands to bitwise-or together (0 to n)
        //             sign indicates that the value is inverted before orring (!x)
        //  These don't use the sign (sign is always false):
        //   For cMin: operands to select the minimum of
        //   For cMax: operands to select the maximum of
        //   For cImmed, not used
        //   For cVar,   not used
        //   For cIf:  operand 1 = condition, operand 2 = yes-branch, operand 3 = no-branch
        //   For anything else: the parameters required by the operation/function
        std::vector<Param> Params;

        /* Internal operation */
        uint_fast64_t Hash;
        size_t        Depth;
        CodeTree*     Parent;
        const FPoptimizer_Grammar::Grammar* OptimizedUsing;
    public:
        CodeTree();
        ~CodeTree();

        /* Generates a CodeTree from the given bytecode */
        static CodeTreeP GenerateFrom(
            const std::vector<unsigned>& byteCode,
            const std::vector<double>& immed,
            const FunctionParser::Data& data);

        class ByteCodeSynth;
        void SynthesizeByteCode(
            std::vector<unsigned>& byteCode,
            std::vector<double>&   immed,
            size_t& stacktop_max);
        void SynthesizeByteCode(ByteCodeSynth& synth);

        /* Regenerates the hash.
         * child_triggered=false: Recurse to children
         * child_triggered=true:  Recurse to parents
         */
        void Rehash(bool child_triggered);
        void Recalculate_Hash_NoRecursion();

        void Sort();
        void Sort_Recursive();

        void SetParams(const std::vector<Param>& RefParams);
        void AddParam(const Param& param);
        void DelParam(size_t index);

        /* Clones the tree. (For parameter duplication) */
        CodeTree* Clone();

        bool    IsImmed() const;
        double GetImmed() const { return Value; }
        bool    IsLongIntegerImmed() const { return IsImmed() && GetImmed() == (double)GetLongIntegerImmed(); }
        double GetLongIntegerImmed() const { return (long)GetImmed(); }
        bool      IsVar() const;
        unsigned GetVar() const { return Var; }

        void NegateImmed() { if(IsImmed()) Value = -Value;       }
        void InvertImmed() { if(IsImmed()) Value = 1.0 / Value;  }
        void NotTheImmed() { if(IsImmed()) Value = Value == 0.0; }

    private:
        void ConstantFolding();

    private:
        CodeTree(const CodeTree&);
        CodeTree& operator=(const CodeTree&);
    };

    inline void CodeTreeP::Forget()
    {
        if(!p) return;
        p->RefCount -= 1;
        if(!p->RefCount) delete p;
        //assert(p->RefCount >= 0);
    }
    inline void CodeTreeP::Have(CodeTree* p2)
    {
        if(p2) ++(p2->RefCount);
    }
    inline void CodeTreeP::Birth()
    {
        Have(p);
    }
    inline void CodeTreeP::Set(CodeTree* p2)
    {
        Have(p2);
        Forget();
        p = p2;
    }
}
#include <stdint.h> /* for uint_fast64_t */

namespace FPoptimizer_CodeTree
{
    class CodeTree;
}

namespace FPoptimizer_Grammar
{
    typedef unsigned OpcodeType;

    enum TransformationType
    {
        None,    // default
        Negate,  // 0-x
        Invert,  // 1/x
        NotThe   // !x
    };

    enum SpecialOpcode
    {
        NumConstant = 0xFFFB, // Holds a particular value (syntax-time constant)
        ImmedHolder,          // Holds a particular immed
        NamedHolder,          // Holds a particular named param (of any kind)
        SubFunction,          // Holds an opcode and the params
        RestHolder            // Holds anything else
      //GroupFunction         // For parse-time functions
    };

    enum ParamMatchingType
    {
        PositionalParams, // this set of params in this order
        SelectedParams,   // this set of params in any order
        AnyParams         // these params are included
    };

    enum RuleType
    {
        ProduceNewTree, // replace self with the first (and only) from replaced_param
        ReplaceParams   // replace indicate params with replaced_params
    };

    enum SignBalanceType
    {
        BalanceDontCare,
        BalanceMoreNeg,
        BalanceMorePos,
        BalanceEqual
    };

    /***/

    struct MatchedParams
    {
        ParamMatchingType type    : 6;
        SignBalanceType   balance : 2;
        // count,index to plist[]
        unsigned         count : 8;
        unsigned         index : 16;

        struct CodeTreeMatch;

        bool Match(FPoptimizer_CodeTree::CodeTree& tree,
                   CodeTreeMatch& match,
                   bool recursion = true) const;

        void ReplaceParams(FPoptimizer_CodeTree::CodeTree& tree,
                           const MatchedParams& matcher, CodeTreeMatch& match) const;

        void ReplaceTree(FPoptimizer_CodeTree::CodeTree& tree,
                         const MatchedParams& matcher, CodeTreeMatch& match) const;

        void SynthesizeTree(
            FPoptimizer_CodeTree::CodeTree& tree,
            const MatchedParams& matcher,
            MatchedParams::CodeTreeMatch& match) const;
    };

    struct ParamSpec
    {
        OpcodeType opcode : 16;
        bool     sign     : 1;
        TransformationType
           transformation  : 3;
        unsigned minrepeat : 3;
        bool     anyrepeat : 1;

        // For NumConstant:   index to clist[]
        // For ImmedHolder:   index is the slot
        // For RestHolder:    index is the slot
        // For NamedHolder:   index is the slot
        // For SubFunction:   index to flist[]
        // For anything else
        //  =  GroupFunction: index,count to plist[]
        unsigned count : 8;
        unsigned index : 16;

        bool Match(
            FPoptimizer_CodeTree::CodeTree& tree,
            MatchedParams::CodeTreeMatch& match,
            TransformationType transf) const;

        bool GetConst(
            const MatchedParams::CodeTreeMatch& match,
            double& result) const;

        void SynthesizeTree(
            FPoptimizer_CodeTree::CodeTree& tree,
            const MatchedParams& matcher,
            MatchedParams::CodeTreeMatch& match) const;
    };
    struct Function
    {
        OpcodeType opcode : 16;
        // index to mlist[]
        unsigned   index  : 16;

        bool Match(FPoptimizer_CodeTree::CodeTree& tree,
                   MatchedParams::CodeTreeMatch& match) const;
    };
    struct Rule
    {
        unsigned  n_minimum_params : 8;
        RuleType  type             : 8;
        // index to mlist[]
        unsigned  repl_index       : 16;

        Function  func;

        bool ApplyTo(FPoptimizer_CodeTree::CodeTree& tree) const;
    };
    struct Grammar
    {
        // count,index to rlist[]
        unsigned index : 16;
        unsigned count : 16;

        bool ApplyTo(FPoptimizer_CodeTree::CodeTree& tree,
                     bool recursion=false) const;
    };

    extern const struct GrammarPack
    {
        const double*         clist;
        const ParamSpec*      plist;
        const MatchedParams*  mlist;
        const Function*       flist;
        const Rule*           rlist;
        Grammar               glist[3];
    } pack;
}
#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif

#define CONSTANT_E     2.71828182845904509080  // exp(1)
#define CONSTANT_PI    M_PI                    // atan2(0,-1)
#define CONSTANT_L10   2.30258509299404590109  // log(10)
#define CONSTANT_L2    0.69314718055994530943  // log(2)
#define CONSTANT_L10I  0.43429448190325176116  // 1/log(10)
#define CONSTANT_L2I   1.4426950408889634074   // 1/log(2)
#define CONSTANT_L10E  CONSTANT_L10I           // log10(e)
#define CONSTANT_L10EI CONSTANT_L10            // 1/log10(e)
#define CONSTANT_L2E   CONSTANT_L2I            // log2(e)
#define CONSTANT_L2EI  CONSTANT_L2             // 1/log2(e)
#define CONSTANT_DR    (180.0 / M_PI)          // 180/pi
#define CONSTANT_RD    (M_PI / 180.0)          // pi/180


#include <string>

const std::string FP_GetOpcodeName(unsigned opcode, bool pad=false);
/* crc32 */
#include <stdint.h>
typedef uint_least32_t crc32_t;
namespace crc32
{
    enum { startvalue = 0xFFFFFFFFUL, poly = 0xEDB88320UL };

    /* This code constructs the CRC32 table at compile-time,
     * avoiding the need for a huge explicitly written table of magical numbers. */
    template<uint_fast32_t crc> // One byte of a CRC32 (eight bits):
    struct b8
    {
        enum { b1 = (crc & 1) ? (poly ^ (crc >> 1)) : (crc >> 1),
               b2 = (b1  & 1) ? (poly ^ (b1  >> 1)) : (b1  >> 1),
               b3 = (b2  & 1) ? (poly ^ (b2  >> 1)) : (b2  >> 1),
               b4 = (b3  & 1) ? (poly ^ (b3  >> 1)) : (b3  >> 1),
               b5 = (b4  & 1) ? (poly ^ (b4  >> 1)) : (b4  >> 1),
               b6 = (b5  & 1) ? (poly ^ (b5  >> 1)) : (b5  >> 1),
               b7 = (b6  & 1) ? (poly ^ (b6  >> 1)) : (b6  >> 1),
               res= (b7  & 1) ? (poly ^ (b7  >> 1)) : (b7  >> 1) };
    };
    inline uint_fast32_t update(uint_fast32_t crc, unsigned/* char */b) // __attribute__((pure))
    {
        // Four values of the table
        #define B4(n) b8<n>::res,b8<n+1>::res,b8<n+2>::res,b8<n+3>::res
        // Sixteen values of the table
        #define R(n) B4(n),B4(n+4),B4(n+8),B4(n+12)
        // The whole table, index by steps of 16
        static const uint_least32_t table[256] =
        { R(0x00),R(0x10),R(0x20),R(0x30), R(0x40),R(0x50),R(0x60),R(0x70),
          R(0x80),R(0x90),R(0xA0),R(0xB0), R(0xC0),R(0xD0),R(0xE0),R(0xF0) };
        #undef R
        #undef B4
        return ((crc >> 8) /* & 0x00FFFFFF*/) ^ table[/*(unsigned char)*/(crc^b)&0xFF];
    }
    inline crc32_t calc_upd(crc32_t c, const unsigned char* buf, size_t size)
    {
        uint_fast32_t value = c;
        for(size_t p=0; p<size; ++p) value = update(value, buf[p]);
        return value;
    }
    inline crc32_t calc(const unsigned char* buf, size_t size)
    {
        return calc_upd(startvalue, buf, size);
    }
}
#include <string>
#include <sstream>
#include <assert.h>

#include <iostream>

#include "fpconfig.hh"
#include "fptypes.hh"


using namespace FPoptimizer_Grammar;
using namespace FUNCTIONPARSERTYPES;

const std::string FP_GetOpcodeName(unsigned opcode, bool pad)
{
#if 1
    /* Symbolic meanings for the opcodes? */
    const char* p = 0;
    switch(OPCODE(opcode))
    {
        case cAbs: p = "cAbs"; break;
        case cAcos: p = "cAcos"; break;
#ifndef FP_NO_ASINH
        case cAcosh: p = "cAcosh"; break;
#endif
        case cAsin: p = "cAsin"; break;
#ifndef FP_NO_ASINH
        case cAsinh: p = "cAsinh"; break;
#endif
        case cAtan: p = "cAtan"; break;
        case cAtan2: p = "cAtan2"; break;
#ifndef FP_NO_ASINH
        case cAtanh: p = "cAtanh"; break;
#endif
        case cCeil: p = "cCeil"; break;
        case cCos: p = "cCos"; break;
        case cCosh: p = "cCosh"; break;
        case cCot: p = "cCot"; break;
        case cCsc: p = "cCsc"; break;
#ifndef FP_DISABLE_EVAL
        case cEval: p = "cEval"; break;
#endif
        case cExp: p = "cExp"; break;
        case cFloor: p = "cFloor"; break;
        case cIf: p = "cIf"; break;
        case cInt: p = "cInt"; break;
        case cLog: p = "cLog"; break;
        case cLog2: p = "cLog2"; break;
        case cLog10: p = "cLog10"; break;
        case cMax: p = "cMax"; break;
        case cMin: p = "cMin"; break;
        case cPow: p = "cPow"; break;
        case cSec: p = "cSec"; break;
        case cSin: p = "cSin"; break;
        case cSinh: p = "cSinh"; break;
        case cSqrt: p = "cSqrt"; break;
        case cTan: p = "cTan"; break;
        case cTanh: p = "cTanh"; break;
        case cImmed: p = "cImmed"; break;
        case cJump: p = "cJump"; break;
        case cNeg: p = "cNeg"; break;
        case cAdd: p = "cAdd"; break;
        case cSub: p = "cSub"; break;
        case cMul: p = "cMul"; break;
        case cDiv: p = "cDiv"; break;
        case cMod: p = "cMod"; break;
        case cEqual: p = "cEqual"; break;
        case cNEqual: p = "cNEqual"; break;
        case cLess: p = "cLess"; break;
        case cLessOrEq: p = "cLessOrEq"; break;
        case cGreater: p = "cGreater"; break;
        case cGreaterOrEq: p = "cGreaterOrEq"; break;
        case cNot: p = "cNot"; break;
        case cAnd: p = "cAnd"; break;
        case cOr: p = "cOr"; break;
        case cDeg: p = "cDeg"; break;
        case cRad: p = "cRad"; break;
        case cFCall: p = "cFCall"; break;
        case cPCall: p = "cPCall"; break;
//#ifdef FP_SUPPORT_OPTIMIZER
        case cVar: p = "cVar"; break;
        case cDup: p = "cDup"; break;
        case cInv: p = "cInv"; break;
        case cFetch: p = "cFetch"; break;
        case cPopNMov: p = "cPopNMov"; break;
        case cSqr: p = "cSqr"; break;
        case cRDiv: p = "cRDiv"; break;
        case cRSub: p = "cRSub"; break;
        case cNotNot: p = "cNotNot"; break;
//#endif
        case cNop: p = "cNop"; break;
        case VarBegin: p = "VarBegin"; break;
    }
    switch( SpecialOpcode(opcode) )
    {
        case NumConstant:   p = "NumConstant"; break;
        case ImmedHolder:   p = "ImmedHolder"; break;
        case NamedHolder:   p = "NamedHolder"; break;
        case RestHolder:    p = "RestHolder"; break;
        case SubFunction:   p = "SubFunction"; break;
      //case GroupFunction: p = "GroupFunction"; break;
    }
    std::stringstream tmp;
    //if(!p) std::cerr << "o=" << opcode << "\n";
    assert(p);
    tmp << p;
    if(pad) while(tmp.str().size() < 12) tmp << ' ';
    return tmp.str();
#else
    /* Just numeric meanings */
    std::stringstream tmp;
    tmp << opcode;
    if(pad) while(tmp.str().size() < 5) tmp << ' ';
    return tmp.str();
#endif
}
#include <cmath>
#include <list>
#include <algorithm>

#include "fptypes.hh"



using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;


namespace FPoptimizer_CodeTree
{
    CodeTree::CodeTree()
        : RefCount(0), Opcode(), Params(), Hash(), Depth(1), Parent(), OptimizedUsing(0)
    {
    }

    CodeTree::~CodeTree()
    {
    }

    void CodeTree::Rehash(
        bool child_triggered)
    {
        /* If we were triggered by a parent, recurse to children */
        if(!child_triggered)
        {
            for(size_t a=0; a<Params.size(); ++a)
                Params[a].param->Rehash(false);
        }

        Recalculate_Hash_NoRecursion();

        /* If we were triggered by a child, recurse to the parent */
        if(child_triggered && Parent)
        {
            //assert(Parent->RefCount > 0);
            Parent->Rehash(true);
        }
    }

    struct ParamComparer
    {
        bool operator() (const CodeTree::Param& a, const CodeTree::Param& b) const
        {
            if(a.param->Depth != b.param->Depth)
                return a.param->Depth > b.param->Depth;
            if(a.sign != b.sign) return a.sign < b.sign;
            return a.param->Hash < b.param->Hash;
        }
    };

    void CodeTree::Sort()
    {
        /* If the tree is commutative, order the parameters
         * in a set order in order to make equality tests
         * efficient in the optimizer
         */
        switch(Opcode)
        {
            case cAdd:
            case cMul:
            case cMin:
            case cMax:
            case cAnd:
            case cOr:
            case cEqual:
            case cNEqual:
                std::sort(Params.begin(), Params.end(), ParamComparer());
                break;
            case cLess:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cGreater; }
                break;
            case cLessOrEq:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cGreaterOrEq; }
                break;
            case cGreater:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cLess; }
                break;
            case cGreaterOrEq:
                if(ParamComparer() (Params[1], Params[0]))
                    { std::swap(Params[0], Params[1]); Opcode = cLessOrEq; }
                break;
        }
    }

    void CodeTree::Sort_Recursive()
    {
        Sort();
        for(size_t a=0; a<Params.size(); ++a)
            Params[a].param->Sort_Recursive();
        Recalculate_Hash_NoRecursion();
    }

    void CodeTree::Recalculate_Hash_NoRecursion()
    {
        uint_fast64_t NewHash = Opcode * 0x3A83A83A83A83A0ULL;
        Depth = 1;
        switch(Opcode)
        {
            case cImmed:
                // FIXME: not portable - we're casting double* into uint_least64_t*
                if(Value != 0.0)
                    NewHash ^= *(uint_least64_t*)&Value;
                break; // no params
            case cVar:
                NewHash ^= (Var<<24) | (Var>>24);
                break; // no params
            case cFCall: case cPCall:
                NewHash ^= (Funcno<<24) | (Funcno>>24);
                /* passthru */
            default:
            {
                size_t MaxChildDepth = 0;
                for(size_t a=0; a<Params.size(); ++a)
                {
                    if(Params[a].param->Depth > MaxChildDepth)
                        MaxChildDepth = Params[a].param->Depth;

                    NewHash += (1+Params[a].sign)*0x2492492492492492ULL;
                    NewHash *= 1099511628211ULL;
                    //assert(&*Params[a].param != this);
                    NewHash += Params[a].param->Hash;
                }
                Depth += MaxChildDepth;
            }
        }
        if(Hash != NewHash)
        {
            Hash = NewHash;
            OptimizedUsing = 0;
        }
    }

    CodeTree* CodeTree::Clone()
    {
        CodeTree* result = new CodeTree;
        result->Opcode = Opcode;
        switch(Opcode)
        {
            case cImmed:
                result->Value  = Value;
                break;
            case cVar:
                result->Var = Var;
                break;
            case cFCall: case cPCall:
                result->Funcno = Funcno;
                break;
        }
        result->SetParams(Params);
        result->Hash   = Hash;
        result->Depth  = Depth;
        //assert(Parent->RefCount > 0);
        result->Parent = Parent;
        return result;
    }

    void CodeTree::AddParam(const Param& param)
    {
        Params.push_back(param);
        Params.back().param->Parent = this;
    }

    void CodeTree::SetParams(const std::vector<Param>& RefParams)
    {
        Params = RefParams;
        /**
        *** Note: The only reason we need to CLONE the children here
        ***       is because they must have the correct Parent field.
        ***       The Parent is required because of backward-recursive
        ***       hash regeneration. Is there any way around this?
        */

        for(size_t a=0; a<Params.size(); ++a)
        {
            Params[a].param = Params[a].param->Clone();
            Params[a].param->Parent = this;
        }
    }

    void CodeTree::DelParam(size_t index)
    {
        Params.erase(Params.begin() + index);
    }
}
/* This file is automatically generated. Do not edit... */
#include "fpconfig.hh"
#include "fptypes.hh"

using namespace FPoptimizer_Grammar;
using namespace FUNCTIONPARSERTYPES;

namespace
{
    const double clist[] =
    {
        3.141592653589793115997963468544185161590576171875, /* 0 */
        0.5, /* 1 */
        0, /* 2 */
        1, /* 3 */
        2.7182818284590450907955982984276488423347473144531, /* 4 */
        0.0 / 0.0, /* 5 */
        0.0 / 0.0, /* 6 */
        -1, /* 7 */
        3.141592653589793115997963468544185161590576171875, /* 8 */
        2, /* 9 */
        -2, /* 10 */
        0.017453292519943295474371680597869271878153085708618, /* 11 */
        57.29577951308232286464772187173366546630859375, /* 12 */
        0.4342944819032517611567811854911269620060920715332, /* 13 */
        1.4426950408889633870046509400708600878715515136719, /* 14 */
        0.69314718055994528622676398299518041312694549560547, /* 15 */
        2.3025850929940459010936137929093092679977416992188, /* 16 */
    };

    const ParamSpec plist[] =
    {
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 0 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	0	}, /* 1    	*/
        {SubFunction , false, None  , 1, false, 0,	1	}, /* 2    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 3    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 4    	*/
        {cAcos       , false, None  , 1, false, 1,	4	}, /* 5    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 6    	*/
        {cAsin       , false, None  , 1, false, 1,	6	}, /* 7    	*/
        {cAtan       , false, None  , 1, false, 1,	6	}, /* 8    	*/
        {cCeil       , false, None  , 1, false, 1,	6	}, /* 9    	*/
        {cCos        , false, None  , 1, false, 1,	6	}, /* 10    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 11 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	2	}, /* 12    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 13 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	3	}, /* 14    	*/
        {NumConstant , false, None  , 1, false, 0,	0	}, /* 15    	*/
        {NumConstant , false, None  , 1, false, 0,	1	}, /* 16    	*/
        {cMul        , false, None  , 1, false, 2,	15	}, /* 17    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 18 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	4	}, /* 19    	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 20    	*/
        {cCosh       , false, None  , 1, false, 1,	6	}, /* 21    	*/
        {cFloor      , false, None  , 1, false, 1,	6	}, /* 22    	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 23    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 24 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 25 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 26 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 27    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 28 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 29 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 30 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 31 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 32 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 33 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 34    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 35    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 36 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 37 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	6	}, /* 38    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 39 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 40    	*/
        {SubFunction , false, None  , 1, false, 0,	7	}, /* 41    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 42 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	8	}, /* 43    	*/
        {SubFunction , false, None  , 1, false, 0,	9	}, /* 44    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 45 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 46    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 47    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 48 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 49 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	10	}, /* 50    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 51    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 52    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 53 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 54    	*/
        {SubFunction , false, None  , 1, false, 0,	11	}, /* 55    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 56 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	12	}, /* 57    	*/
        {SubFunction , false, None  , 1, false, 0,	13	}, /* 58    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 59 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 60    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 61    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 62 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 63 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	14	}, /* 64    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 65 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 66    	*/
        {SubFunction , false, None  , 1, false, 0,	15	}, /* 67    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 68 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	16	}, /* 69    	*/
        {SubFunction , false, None  , 1, false, 0,	17	}, /* 70    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 71 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 72    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 73    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 74 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 75 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	18	}, /* 76    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 77    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 78    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 79 "y"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 80    	*/
        {SubFunction , false, None  , 1, false, 0,	19	}, /* 81    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 82 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	20	}, /* 83    	*/
        {SubFunction , false, None  , 1, false, 0,	21	}, /* 84    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 85 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 86    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 87    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 88 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 89    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 90    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 91 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	22	}, /* 92    	*/
        {SubFunction , false, None  , 1, false, 0,	23	}, /* 93    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 94    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 95    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 96 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	24	}, /* 97    	*/
        {SubFunction , false, None  , 1, false, 0,	25	}, /* 98    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 99 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	26	}, /* 100    	*/
        {SubFunction , false, None  , 1, false, 0,	27	}, /* 101    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 102 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 103    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 104    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 105 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 106    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 107    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 108 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	28	}, /* 109    	*/
        {SubFunction , false, None  , 1, false, 0,	29	}, /* 110    	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 111    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 112    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 113 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	11	}, /* 114    	*/
        {SubFunction , false, None  , 1, false, 0,	30	}, /* 115    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 116 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	31	}, /* 117    	*/
        {SubFunction , false, None  , 1, false, 0,	32	}, /* 118    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 119 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 120    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 121    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 122 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 123    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 124    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 125 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	33	}, /* 126    	*/
        {SubFunction , false, None  , 1, false, 0,	34	}, /* 127    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 128    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 129    	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 130    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 131    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 132 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	35	}, /* 133    	*/
        {SubFunction , false, None  , 1, false, 0,	36	}, /* 134    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 135 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	37	}, /* 136    	*/
        {SubFunction , false, None  , 1, false, 0,	38	}, /* 137    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 138 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 139    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 140    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 141 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 142    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 143    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 144 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	39	}, /* 145    	*/
        {SubFunction , false, None  , 1, false, 0,	40	}, /* 146    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 147    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 148    	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 149    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 150    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 151 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	41	}, /* 152    	*/
        {SubFunction , false, None  , 1, false, 0,	42	}, /* 153    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 154 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	43	}, /* 155    	*/
        {SubFunction , false, None  , 1, false, 0,	44	}, /* 156    	*/
        {SubFunction , false, None  , 1, false, 0,	45	}, /* 157    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 158 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 159 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 160 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 161 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 162 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	46	}, /* 163    	*/
        {SubFunction , false, None  , 1, false, 0,	47	}, /* 164    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 165 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 166 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 167 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 168 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 169 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	48	}, /* 170    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 171    	*/
        {cLog        , false, None  , 1, false, 1,	6	}, /* 172    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 173 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 174 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	49	}, /* 175    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 176 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	50	}, /* 177    	*/
        {SubFunction , false, None  , 1, false, 0,	51	}, /* 178    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 179    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 180 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	52	}, /* 181    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 182    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 183    	*/
        {SubFunction , false, None  , 1, false, 0,	53	}, /* 184    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 185    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 186    	*/
        {SubFunction , false, None  , 1, false, 0,	54	}, /* 187    	*/
        {SubFunction , false, None  , 1, false, 0,	55	}, /* 188    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 189 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	56	}, /* 190    	*/
        {NumConstant , false, None  , 1, false, 0,	5	}, /* 191    	*/
        {SubFunction , false, None  , 1, false, 0,	57	}, /* 192    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 193    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 194    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 195    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 196    	*/
        {cMax        , false, None  , 1, false, 2,	195	}, /* 197    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 198 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 199 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	6	}, /* 200    	*/
        {SubFunction , false, None  , 1, false, 0,	58	}, /* 201    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 202    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 203    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 204    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 205    	*/
        {cMin        , false, None  , 1, false, 2,	204	}, /* 206    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 207 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 208 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 209    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 210 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 211    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 212 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 213    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 214    	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 215    	*/
        {SubFunction , false, None  , 1, false, 0,	60	}, /* 216    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 217    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 218    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 219    	*/
        {SubFunction , false, None  , 1, false, 0,	61	}, /* 220    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 221    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 222    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 223 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	62	}, /* 224    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 225    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 226    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 227    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 228    	*/
        {cPow        , false, None  , 1, false, 2,	227	}, /* 229    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 230    	*/
        {SubFunction , false, None  , 1, false, 0,	63	}, /* 231    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 232    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 233    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 234    	*/
        {SubFunction , false, None  , 1, false, 0,	64	}, /* 235    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 236    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 237    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 238 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	65	}, /* 239    	*/
        {cLog        , true , None  , 1, false, 1,	6	}, /* 240    	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 241    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 242    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 243    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 244    	*/
        {SubFunction , false, None  , 1, false, 0,	66	}, /* 245    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 246    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 247    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 248 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	67	}, /* 249    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 250 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	7	}, /* 251    	*/
        {SubFunction , false, None  , 1, false, 0,	68	}, /* 252    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 253 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	2	}, /* 254    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 255 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 256    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 257 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	69	}, /* 258    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 259    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 260    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 261 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	70	}, /* 262    	*/
        {SubFunction , true , None  , 1, false, 0,	71	}, /* 263    	*/
        {SubFunction , false, None  , 1, false, 0,	72	}, /* 264    	*/
        {SubFunction , true , None  , 1, false, 0,	73	}, /* 265    	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 266    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 267    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 268    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 269 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	74	}, /* 270    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 271    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 272    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 273 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	75	}, /* 274    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 275 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 276 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	76	}, /* 277    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 278 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 279 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 280 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 281 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	77	}, /* 282    	*/
        {cSin        , false, None  , 1, false, 1,	6	}, /* 283    	*/
        {SubFunction , false, None  , 1, false, 0,	78	}, /* 284    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 285 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	79	}, /* 286    	*/
        {SubFunction , true , None  , 1, false, 0,	80	}, /* 287    	*/
        {SubFunction , false, None  , 1, false, 0,	81	}, /* 288    	*/
        {NumConstant , false, None  , 1, false, 0,	8	}, /* 289    	*/
        {NumConstant , false, None  , 1, false, 0,	1	}, /* 290    	*/
        {cMul        , false, None  , 1, false, 2,	289	}, /* 291    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 292 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	82	}, /* 293    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 294    	*/
        {cSinh       , false, None  , 1, false, 1,	3	}, /* 295    	*/
        {cTan        , false, None  , 1, false, 1,	6	}, /* 296    	*/
        {SubFunction , false, None  , 1, false, 0,	84	}, /* 297    	*/
        {SubFunction , true , None  , 1, false, 0,	85	}, /* 298    	*/
        {SubFunction , false, None  , 1, false, 0,	86	}, /* 299    	*/
        {cTanh       , false, None  , 1, false, 1,	4	}, /* 300    	*/
        {SubFunction , false, None  , 1, false, 0,	87	}, /* 301    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 302    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 303    	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 304    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 305    	*/
        {SubFunction , false, None  , 1, false, 0,	88	}, /* 306    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 307    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 308    	*/
        {SubFunction , false, None  , 1, false, 0,	89	}, /* 309    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 310    	*/
        {RestHolder  , false, None  , 1, false, 0,	4	}, /* 311    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 312    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 313    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 314    	*/
        {SubFunction , true , None  , 1, false, 0,	91	}, /* 315    	*/
        {ImmedHolder , true , None  , 1, false, 0,	0	}, /* 316    	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 317    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 318    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 319    	*/
        {SubFunction , true , None  , 1, false, 0,	92	}, /* 320    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 321    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 322    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 323    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 324    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 325    	*/
        {SubFunction , true , None  , 1, false, 0,	93	}, /* 326    	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 327    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 328    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 329    	*/
        {SubFunction , false, None  , 1, false, 0,	94	}, /* 330    	*/
        {RestHolder  , false, None  , 1, false, 0,	3	}, /* 331    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 332    	*/
        {SubFunction , false, None  , 1, false, 0,	95	}, /* 333    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 334    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 335    	*/
        {SubFunction , true , None  , 1, false, 0,	96	}, /* 336    	*/
        {SubFunction , false, None  , 1, false, 0,	90	}, /* 337    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 338    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 339    	*/
        {SubFunction , false, None  , 1, false, 0,	97	}, /* 340    	*/
        {SubFunction , false, None  , 1, false, 0,	98	}, /* 341    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 342    	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 343    	*/
        {SubFunction , true , None  , 1, false, 0,	99	}, /* 344    	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 345    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 346    	*/
        {SubFunction , false, None  , 1, false, 0,	100	}, /* 347    	*/
        {SubFunction , false, None  , 1, false, 0,	101	}, /* 348    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 349    	*/
        {NumConstant , false, None  , 1, false, 0,	3	}, /* 350    	*/
        {SubFunction , true , None  , 1, false, 0,	102	}, /* 351    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 352    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 353    	*/
        {SubFunction , false, None  , 1, false, 0,	103	}, /* 354    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 355    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 356    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 357    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 358    	*/
        {cAdd        , false, None  , 1, false, 2,	357	}, /* 359    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 360 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 361 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 362    	*/
        {SubFunction , false, None  , 1, false, 0,	104	}, /* 363    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 364 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 365 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	105	}, /* 366    	*/
        {SubFunction , false, None  , 1, false, 0,	106	}, /* 367    	*/
        {SubFunction , false, None  , 1, false, 0,	101	}, /* 368    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 369    	*/
        {SubFunction , false, None  , 1, false, 0,	108	}, /* 370    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 371    	*/
        {SubFunction , false, None  , 1, false, 0,	107	}, /* 372    	*/
        {SubFunction , false, None  , 1, false, 0,	109	}, /* 373    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 374 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 375    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 376    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 377 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 378    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 379    	*/
        {SubFunction , false, None  , 1, false, 0,	110	}, /* 380    	*/
        {SubFunction , false, None  , 1, false, 0,	111	}, /* 381    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 382    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 383    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 384    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 385    	*/
        {SubFunction , false, None  , 1, false, 0,	112	}, /* 386    	*/
        {SubFunction , false, None  , 1, false, 0,	113	}, /* 387    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 388 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	114	}, /* 389    	*/
        {SubFunction , false, None  , 1, false, 0,	115	}, /* 390    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 391 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 392    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 393    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 394 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 395    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 396    	*/
        {SubFunction , false, None  , 1, false, 0,	116	}, /* 397    	*/
        {SubFunction , true , None  , 1, false, 0,	117	}, /* 398    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 399    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 400    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 401    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 402    	*/
        {SubFunction , false, None  , 1, false, 0,	118	}, /* 403    	*/
        {SubFunction , true , None  , 1, false, 0,	119	}, /* 404    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 405 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	120	}, /* 406    	*/
        {SubFunction , false, None  , 1, false, 0,	121	}, /* 407    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 408 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 409    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 410    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 411 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 412    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 413    	*/
        {SubFunction , false, None  , 1, false, 0,	122	}, /* 414    	*/
        {SubFunction , false, None  , 1, false, 0,	123	}, /* 415    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 416    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 417    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 418    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 419    	*/
        {SubFunction , false, None  , 1, false, 0,	124	}, /* 420    	*/
        {SubFunction , false, None  , 1, false, 0,	125	}, /* 421    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 422 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	126	}, /* 423    	*/
        {SubFunction , false, None  , 1, false, 0,	127	}, /* 424    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 425 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 426    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 427    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 428 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 429    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 430    	*/
        {SubFunction , false, None  , 1, false, 0,	128	}, /* 431    	*/
        {SubFunction , true , None  , 1, false, 0,	129	}, /* 432    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 433    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 434    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 435    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 436    	*/
        {SubFunction , false, None  , 1, false, 0,	130	}, /* 437    	*/
        {SubFunction , true , None  , 1, false, 0,	131	}, /* 438    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 439 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	132	}, /* 440    	*/
        {SubFunction , false, None  , 1, false, 0,	133	}, /* 441    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 442    	*/
        {SubFunction , false, None  , 1, false, 0,	134	}, /* 443    	*/
        {SubFunction , false, None  , 1, false, 0,	101	}, /* 444    	*/
        {SubFunction , false, None  , 1, false, 0,	136	}, /* 445    	*/
        {SubFunction , false, None  , 1, false, 0,	135	}, /* 446    	*/
        {SubFunction , false, None  , 1, false, 0,	137	}, /* 447    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 448 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 449 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	138	}, /* 450    	*/
        {SubFunction , false, None  , 1, false, 0,	139	}, /* 451    	*/
        {SubFunction , false, None  , 1, false, 0,	98	}, /* 452    	*/
        {SubFunction , false, None  , 1, false, 0,	140	}, /* 453    	*/
        {SubFunction , false, None  , 1, false, 0,	80	}, /* 454    	*/
        {SubFunction , false, None  , 1, false, 0,	142	}, /* 455    	*/
        {SubFunction , false, None  , 1, false, 0,	141	}, /* 456    	*/
        {SubFunction , true , None  , 1, false, 0,	143	}, /* 457    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 458 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 459 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	144	}, /* 460    	*/
        {SubFunction , false, None  , 1, false, 0,	145	}, /* 461    	*/
        {SubFunction , false, None  , 1, false, 0,	80	}, /* 462    	*/
        {SubFunction , false, None  , 1, false, 0,	146	}, /* 463    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 464    	*/
        {SubFunction , false, None  , 1, false, 0,	148	}, /* 465    	*/
        {SubFunction , false, None  , 1, false, 0,	147	}, /* 466    	*/
        {SubFunction , false, None  , 1, false, 0,	149	}, /* 467    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 468 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 469 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	150	}, /* 470    	*/
        {SubFunction , false, None  , 1, false, 0,	151	}, /* 471    	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 472    	*/
        {SubFunction , false, None  , 1, false, 0,	134	}, /* 473    	*/
        {SubFunction , false, None  , 1, false, 0,	98	}, /* 474    	*/
        {SubFunction , false, None  , 1, false, 0,	136	}, /* 475    	*/
        {SubFunction , false, None  , 1, false, 0,	152	}, /* 476    	*/
        {SubFunction , true , None  , 1, false, 0,	153	}, /* 477    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 478 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 479 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	154	}, /* 480    	*/
        {SubFunction , false, None  , 1, false, 0,	155	}, /* 481    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 482 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 483    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 484    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 485 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	156	}, /* 486    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 487    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 488    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 489 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	157	}, /* 490    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 491 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	158	}, /* 492    	*/
        {SubFunction , false, None  , 1, false, 0,	159	}, /* 493    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 494 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 495    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 496    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 497 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	160	}, /* 498    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 499    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 500    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 501 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	161	}, /* 502    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 503 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	162	}, /* 504    	*/
        {SubFunction , false, None  , 1, false, 0,	163	}, /* 505    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 506 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 507    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 508    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 509 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 510    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 511    	*/
        {SubFunction , true , None  , 1, false, 0,	164	}, /* 512    	*/
        {SubFunction , true , None  , 1, false, 0,	165	}, /* 513    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 514    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 515    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 516    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 517    	*/
        {SubFunction , true , None  , 1, false, 0,	166	}, /* 518    	*/
        {SubFunction , true , None  , 1, false, 0,	167	}, /* 519    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 520 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	168	}, /* 521    	*/
        {SubFunction , false, None  , 1, false, 0,	169	}, /* 522    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 523 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 524    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 525    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 526 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 527    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 528    	*/
        {SubFunction , true , None  , 1, false, 0,	170	}, /* 529    	*/
        {SubFunction , true , None  , 1, false, 0,	171	}, /* 530    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 531    	*/
        {RestHolder  , true , None  , 1, false, 0,	3	}, /* 532    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 533    	*/
        {RestHolder  , true , None  , 1, false, 0,	4	}, /* 534    	*/
        {SubFunction , true , None  , 1, false, 0,	172	}, /* 535    	*/
        {SubFunction , true , None  , 1, false, 0,	173	}, /* 536    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 537 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	174	}, /* 538    	*/
        {SubFunction , false, None  , 1, false, 0,	175	}, /* 539    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 540    	*/
        {SubFunction , false, None  , 1, false, 0,	134	}, /* 541    	*/
        {SubFunction , true , None  , 1, false, 0,	176	}, /* 542    	*/
        {SubFunction , false, None  , 1, false, 0,	143	}, /* 543    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 544 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 545 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	177	}, /* 546    	*/
        {SubFunction , true , None  , 1, false, 0,	178	}, /* 547    	*/
        {SubFunction , false, None  , 1, false, 0,	80	}, /* 548    	*/
        {SubFunction , false, None  , 1, false, 0,	142	}, /* 549    	*/
        {SubFunction , true , None  , 1, false, 0,	135	}, /* 550    	*/
        {SubFunction , true , None  , 1, false, 0,	179	}, /* 551    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 552 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 553 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	180	}, /* 554    	*/
        {SubFunction , true , None  , 1, false, 0,	181	}, /* 555    	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 556    	*/
        {SubFunction , false, None  , 1, false, 0,	134	}, /* 557    	*/
        {SubFunction , false, None  , 1, false, 0,	98	}, /* 558    	*/
        {SubFunction , false, None  , 1, false, 0,	136	}, /* 559    	*/
        {SubFunction , true , None  , 1, false, 0,	182	}, /* 560    	*/
        {SubFunction , true , None  , 1, false, 0,	183	}, /* 561    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 562 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 563 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	184	}, /* 564    	*/
        {SubFunction , true , None  , 1, false, 0,	185	}, /* 565    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 566 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 567    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 568    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 569 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	186	}, /* 570    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 571    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 572    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 573 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	187	}, /* 574    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 575 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	188	}, /* 576    	*/
        {SubFunction , false, None  , 1, false, 0,	189	}, /* 577    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 578 "x"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 579    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 580    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 581 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	190	}, /* 582    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 583    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 584    	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 585 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	191	}, /* 586    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 587 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	192	}, /* 588    	*/
        {SubFunction , false, None  , 1, false, 0,	193	}, /* 589    	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 590 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 591 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 592 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	194	}, /* 593    	*/
        {NamedHolder , true , None  , 2, true , 0,	0	}, /* 594 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 595 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 596 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	195	}, /* 597    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 598 "a"	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 599    	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 600 "b"	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 601    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 602 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 603 "b"	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 604    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 605    	*/
        {SubFunction , false, None  , 1, false, 0,	196	}, /* 606    	*/
        {SubFunction , false, None  , 1, false, 0,	197	}, /* 607    	*/
        {SubFunction , false, None  , 1, false, 0,	198	}, /* 608    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 609 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 610 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	199	}, /* 611    	*/
        {NumConstant , false, None  , 1, false, 0,	9	}, /* 612    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 613    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 614    	*/
        {SubFunction , false, None  , 1, false, 0,	201	}, /* 615    	*/
        {NumConstant , false, None  , 1, false, 0,	10	}, /* 616    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 617 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 618 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	202	}, /* 619    	*/
        {SubFunction , false, None  , 1, false, 0,	200	}, /* 620    	*/
        {SubFunction , false, None  , 1, false, 0,	203	}, /* 621    	*/
        {cMul        , false, None  , 1, false, 2,	289	}, /* 622    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 623 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	204	}, /* 624    	*/
        {SubFunction , true , None  , 1, false, 0,	205	}, /* 625    	*/
        {SubFunction , false, None  , 1, false, 0,	85	}, /* 626    	*/
        {NumConstant , false, None  , 1, false, 0,	7	}, /* 627    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 628    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 629    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 630    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 631    	*/
        {SubFunction , true , None  , 1, false, 0,	206	}, /* 632    	*/
        {SubFunction , false, None  , 1, false, 0,	207	}, /* 633    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 634    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 635    	*/
        {SubFunction , false, None  , 1, false, 0,	208	}, /* 636    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 637    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 638    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 639 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 640    	*/
        {SubFunction , true , None  , 1, false, 0,	209	}, /* 641    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 642 "x"	*/
        {ImmedHolder , false, Negate, 1, false, 0,	0	}, /* 643    	*/
        {SubFunction , false, None  , 1, false, 0,	210	}, /* 644    	*/
        {SubFunction , true , None  , 1, false, 0,	211	}, /* 645    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 646    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 647    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 648    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 649    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 650    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 651    	*/
        {cMul        , false, None  , 1, false, 2,	650	}, /* 652    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 653    	*/
        {ImmedHolder , true , None  , 1, false, 0,	1	}, /* 654    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 655    	*/
        {ImmedHolder , false, Invert, 1, false, 0,	1	}, /* 656    	*/
        {cMul        , false, None  , 1, false, 2,	655	}, /* 657    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 658 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 659 "x"	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 660    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 661 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	212	}, /* 662    	*/
        {SubFunction , false, None  , 1, false, 0,	213	}, /* 663    	*/
        {cLog        , false, Invert, 1, false, 1,	6	}, /* 664    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 665    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 666 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	214	}, /* 667    	*/
        {SubFunction , false, None  , 1, false, 0,	215	}, /* 668    	*/
        {cLog        , true , None  , 1, false, 1,	4	}, /* 669    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 670 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 671 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	216	}, /* 672    	*/
        {SubFunction , false, None  , 1, false, 0,	217	}, /* 673    	*/
        {SubFunction , true , None  , 1, false, 0,	63	}, /* 674    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 675    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 676 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 677 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	218	}, /* 678    	*/
        {SubFunction , false, None  , 1, false, 0,	219	}, /* 679    	*/
        {SubFunction , false, None  , 1, false, 0,	220	}, /* 680    	*/
        {cLog        , false, Invert, 1, false, 1,	3	}, /* 681    	*/
        {SubFunction , false, None  , 1, false, 0,	59	}, /* 682    	*/
        {cLog        , false, Invert, 1, false, 1,	6	}, /* 683    	*/
        {SubFunction , false, None  , 1, false, 0,	221	}, /* 684    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 685 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	222	}, /* 686    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 687    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 688 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 689 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	223	}, /* 690    	*/
        {SubFunction , false, None  , 1, false, 0,	224	}, /* 691    	*/
        {SubFunction , false, None  , 1, false, 0,	225	}, /* 692    	*/
        {cLog        , true , None  , 1, false, 1,	6	}, /* 693    	*/
        {SubFunction , false, None  , 1, false, 0,	60	}, /* 694    	*/
        {cLog        , false, Invert, 1, false, 1,	4	}, /* 695    	*/
        {SubFunction , false, None  , 1, false, 0,	226	}, /* 696    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 697 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	227	}, /* 698    	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 699 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 700 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 701 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	228	}, /* 702    	*/
        {SubFunction , false, None  , 1, false, 0,	229	}, /* 703    	*/
        {SubFunction , false, None  , 1, false, 0,	230	}, /* 704    	*/
        {SubFunction , true , None  , 1, false, 0,	73	}, /* 705    	*/
        {SubFunction , false, None  , 1, false, 0,	60	}, /* 706    	*/
        {SubFunction , true , None  , 1, false, 0,	231	}, /* 707    	*/
        {SubFunction , false, None  , 1, false, 0,	232	}, /* 708    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 709 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	233	}, /* 710    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 711 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 712 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 713 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 714 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	234	}, /* 715    	*/
        {SubFunction , false, None  , 1, false, 0,	235	}, /* 716    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 717 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 718 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 719 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	236	}, /* 720    	*/
        {SubFunction , false, None  , 1, false, 0,	237	}, /* 721    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 722 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 723 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 724 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 725 "z"	*/
        {SubFunction , false, None  , 1, false, 0,	238	}, /* 726    	*/
        {SubFunction , true , None  , 1, false, 0,	239	}, /* 727    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 728 "y"	*/
        {NamedHolder , true , None  , 1, false, 0,	2	}, /* 729 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 730 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	240	}, /* 731    	*/
        {SubFunction , false, None  , 1, false, 0,	241	}, /* 732    	*/
        {SubFunction , false, None  , 1, false, 0,	5	}, /* 733    	*/
        {SubFunction , true , None  , 1, false, 0,	83	}, /* 734    	*/
        {SubFunction , false, None  , 1, false, 0,	242	}, /* 735    	*/
        {SubFunction , false, None  , 1, false, 0,	243	}, /* 736    	*/
        {SubFunction , true , None  , 1, false, 0,	244	}, /* 737    	*/
        {SubFunction , false, None  , 1, false, 0,	245	}, /* 738    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 739 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 740 "y"	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 741 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	246	}, /* 742    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 743 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 744 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 745 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	247	}, /* 746    	*/
        {SubFunction , false, None  , 1, false, 0,	248	}, /* 747    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 748 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 749 "y"	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 750 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	249	}, /* 751    	*/
        {NamedHolder , false, None  , 1, true , 0,	0	}, /* 752 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 753 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 754 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	250	}, /* 755    	*/
        {SubFunction , false, None  , 1, false, 0,	251	}, /* 756    	*/
        {ImmedHolder , true , None  , 1, false, 0,	0	}, /* 757    	*/
        {ImmedHolder , true , None  , 1, false, 0,	1	}, /* 758    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 759    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 760    	*/
        {cMul        , true , None  , 1, false, 2,	759	}, /* 761    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 762    	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 763 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	252	}, /* 764    	*/
        {SubFunction , true , None  , 1, false, 0,	253	}, /* 765    	*/
        {cLog        , false, None  , 1, false, 1,	6	}, /* 766    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 767 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 768 "y"	*/
        {SubFunction , false, None  , 1, false, 0,	254	}, /* 769    	*/
        {SubFunction , true , None  , 1, false, 0,	255	}, /* 770    	*/
        {SubFunction , false, None  , 1, false, 0,	60	}, /* 771    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 772 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 773 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 774 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	2	}, /* 775 "z"	*/
        {SubFunction , true , None  , 1, false, 0,	256	}, /* 776    	*/
        {SubFunction , true , None  , 1, false, 0,	257	}, /* 777    	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 778 "y"	*/
        {NamedHolder , true , None  , 1, false, 0,	2	}, /* 779 "z"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 780 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	258	}, /* 781    	*/
        {SubFunction , false, None  , 1, false, 0,	259	}, /* 782    	*/
        {SubFunction , true , None  , 1, false, 0,	5	}, /* 783    	*/
        {SubFunction , false, None  , 1, false, 0,	83	}, /* 784    	*/
        {SubFunction , true , None  , 1, false, 0,	260	}, /* 785    	*/
        {SubFunction , true , None  , 1, false, 0,	261	}, /* 786    	*/
        {SubFunction , false, None  , 1, false, 0,	262	}, /* 787    	*/
        {SubFunction , true , None  , 1, false, 0,	263	}, /* 788    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 789 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 790 "y"	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 791 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	264	}, /* 792    	*/
        {NamedHolder , false, Negate, 1, true , 0,	0	}, /* 793 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 794 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 795 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	265	}, /* 796    	*/
        {SubFunction , false, None  , 1, false, 0,	266	}, /* 797    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 798 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	1	}, /* 799 "y"	*/
        {NamedHolder , true , None  , 1, true , 0,	0	}, /* 800 "x"	*/
        {SubFunction , true , None  , 1, false, 0,	267	}, /* 801    	*/
        {NamedHolder , false, Negate, 1, true , 0,	0	}, /* 802 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	1	}, /* 803 "y"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 804 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	268	}, /* 805    	*/
        {SubFunction , false, None  , 1, false, 0,	269	}, /* 806    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 807 "x"	*/
        {NamedHolder , false, None  , 2, true , 0,	0	}, /* 808 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	270	}, /* 809    	*/
        {NamedHolder , true , None  , 2, true , 0,	0	}, /* 810 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 811 "x"	*/
        {NamedHolder , false, Negate, 2, true , 0,	0	}, /* 812 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	271	}, /* 813    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 814    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 815    	*/
        {ImmedHolder , false, None  , 1, false, 0,	0	}, /* 816    	*/
        {ImmedHolder , false, None  , 1, false, 0,	1	}, /* 817    	*/
        {cMod        , false, None  , 1, false, 2,	816	}, /* 818    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 819 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 820 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 821 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 822 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 823 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 824 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 825 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 826 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 827 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 828 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 829 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 830 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 831 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 832 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	272	}, /* 833    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 834 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 835 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	273	}, /* 836    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 837 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 838 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	274	}, /* 839    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 840 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 841 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	275	}, /* 842    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 843 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 844 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	276	}, /* 845    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 846 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 847 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	277	}, /* 848    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 849 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 850 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	278	}, /* 851    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 852 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 853 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	279	}, /* 854    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 855 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 856 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	280	}, /* 857    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 858 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 859 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	281	}, /* 860    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 861 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 862 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	282	}, /* 863    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 864 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 865 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	283	}, /* 866    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 867    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 868    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 869    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 870    	*/
        {SubFunction , true , None  , 1, false, 0,	284	}, /* 871    	*/
        {SubFunction , false, None  , 1, false, 0,	285	}, /* 872    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 873    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 874    	*/
        {SubFunction , false, None  , 1, false, 0,	286	}, /* 875    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 876 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 877 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	287	}, /* 878    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 879 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 880 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	288	}, /* 881    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 882 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 883 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	289	}, /* 884    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 885 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 886 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	290	}, /* 887    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 888 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 889 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	291	}, /* 890    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 891 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 892 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	292	}, /* 893    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 894 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 895 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	293	}, /* 896    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 897 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 898 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	294	}, /* 899    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 900 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 901 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	295	}, /* 902    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 903 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 904 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	296	}, /* 905    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 906 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 907 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	297	}, /* 908    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 909 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 910 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	298	}, /* 911    	*/
        {SubFunction , true , None  , 1, false, 0,	0	}, /* 912    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 913    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 914    	*/
        {SubFunction , true , None  , 1, false, 0,	299	}, /* 915    	*/
        {SubFunction , true , None  , 1, false, 0,	300	}, /* 916    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 917 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 918 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 919 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 920 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 921 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 922 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	301	}, /* 923    	*/
        {SubFunction , false, None  , 1, false, 0,	302	}, /* 924    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 925 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 926 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 927 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 928 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 929 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 930 "c"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 931 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 932 "c"	*/
        {SubFunction , false, None  , 1, false, 0,	303	}, /* 933    	*/
        {SubFunction , false, None  , 1, false, 0,	304	}, /* 934    	*/
        {SubFunction , false, None  , 1, false, 0,	305	}, /* 935    	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 936 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	5	}, /* 937 "c"	*/
        {SubFunction , false, None  , 1, false, 0,	306	}, /* 938    	*/
        {SubFunction , false, None  , 1, false, 0,	307	}, /* 939    	*/
        {RestHolder  , false, None  , 1, false, 0,	2	}, /* 940    	*/
        {RestHolder  , true , None  , 1, false, 0,	1	}, /* 941    	*/
        {SubFunction , true , None  , 1, false, 0,	308	}, /* 942    	*/
        {SubFunction , false, None  , 1, false, 0,	309	}, /* 943    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 944    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 945    	*/
        {SubFunction , false, None  , 1, false, 0,	310	}, /* 946    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 947 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 948 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	311	}, /* 949    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 950 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 951 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	312	}, /* 952    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 953 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 954 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	313	}, /* 955    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 956 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 957 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	314	}, /* 958    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 959 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 960 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	315	}, /* 961    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 962 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 963 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	316	}, /* 964    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 965 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 966 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	317	}, /* 967    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 968 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 969 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	318	}, /* 970    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 971 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 972 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	319	}, /* 973    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 974 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 975 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	320	}, /* 976    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 977 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 978 "b"	*/
        {SubFunction , true , None  , 1, false, 0,	321	}, /* 979    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 980 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 981 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	322	}, /* 982    	*/
        {SubFunction , true , None  , 1, false, 0,	309	}, /* 983    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 984    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 985    	*/
        {SubFunction , true , None  , 1, false, 0,	323	}, /* 986    	*/
        {SubFunction , true , None  , 1, false, 0,	1	}, /* 987    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 988 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 989 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 990 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 991 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 992 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 993 "b"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 994 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 995 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	324	}, /* 996    	*/
        {SubFunction , false, None  , 1, false, 0,	325	}, /* 997    	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 998 "x"	*/
        {NamedHolder , true , None  , 1, false, 0,	0	}, /* 999 "x"	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1000 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1001 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	326	}, /* 1002    	*/
        {SubFunction , false, None  , 1, false, 0,	306	}, /* 1003    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1004 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1005 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	327	}, /* 1006    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1007 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1008 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	328	}, /* 1009    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1010 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1011 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	329	}, /* 1012    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1013 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1014 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	330	}, /* 1015    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1016 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1017 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	331	}, /* 1018    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1019 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1020 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	332	}, /* 1021    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1022 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1023 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	333	}, /* 1024    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1025 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1026 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	334	}, /* 1027    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1028 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1029 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	335	}, /* 1030    	*/
        {NamedHolder , false, None  , 1, false, 0,	3	}, /* 1031 "a"	*/
        {NamedHolder , false, None  , 1, false, 0,	4	}, /* 1032 "b"	*/
        {SubFunction , false, None  , 1, false, 0,	336	}, /* 1033    	*/
        {SubFunction , false, None  , 1, false, 0,	337	}, /* 1034    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1035    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1036    	*/
        {SubFunction , false, None  , 1, false, 0,	338	}, /* 1037    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1038    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1039    	*/
        {SubFunction , false, None  , 1, false, 0,	339	}, /* 1040    	*/
        {SubFunction , false, None  , 1, false, 0,	340	}, /* 1041    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1042    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1043    	*/
        {SubFunction , false, None  , 1, false, 0,	341	}, /* 1044    	*/
        {NumConstant , false, None  , 1, false, 0,	4	}, /* 1045    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 1046 "x"	*/
        {SubFunction , false, None  , 1, false, 0,	342	}, /* 1047    	*/
        {NamedHolder , false, None  , 1, false, 0,	0	}, /* 1048 "x"	*/
        {NumConstant , false, None  , 1, false, 0,	1	}, /* 1049    	*/
        {SubFunction , false, None  , 1, false, 0,	343	}, /* 1050    	*/
        {NumConstant , false, None  , 1, false, 0,	11	}, /* 1051    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1052    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1053    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1054    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1055    	*/
        {SubFunction , false, None  , 1, false, 0,	344	}, /* 1056    	*/
        {SubFunction , false, None  , 1, false, 0,	345	}, /* 1057    	*/
        {NumConstant , false, None  , 1, false, 0,	12	}, /* 1058    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1059    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1060    	*/
        {RestHolder  , false, None  , 1, false, 0,	1	}, /* 1061    	*/
        {RestHolder  , true , None  , 1, false, 0,	2	}, /* 1062    	*/
        {SubFunction , false, None  , 1, false, 0,	346	}, /* 1063    	*/
        {SubFunction , false, None  , 1, false, 0,	347	}, /* 1064    	*/
        {SubFunction , true , None  , 1, false, 0,	98	}, /* 1065    	*/
        {SubFunction , false, None  , 1, false, 0,	348	}, /* 1066    	*/
        {SubFunction , false, None  , 1, false, 0,	349	}, /* 1067    	*/
        {SubFunction , true , None  , 1, false, 0,	242	}, /* 1068    	*/
        {SubFunction , false, None  , 1, false, 0,	350	}, /* 1069    	*/
        {SubFunction , false, None  , 1, false, 0,	63	}, /* 1070    	*/
        {NumConstant , false, None  , 1, false, 0,	13	}, /* 1071    	*/
        {SubFunction , false, None  , 1, false, 0,	351	}, /* 1072    	*/
        {SubFunction , false, None  , 1, false, 0,	63	}, /* 1073    	*/
        {NumConstant , false, None  , 1, false, 0,	14	}, /* 1074    	*/
        {SubFunction , false, None  , 1, false, 0,	352	}, /* 1075    	*/
        {SubFunction , true , None  , 1, false, 0,	63	}, /* 1076    	*/
        {NumConstant , false, None  , 1, false, 0,	15	}, /* 1077    	*/
        {SubFunction , true , None  , 1, false, 0,	352	}, /* 1078    	*/
        {SubFunction , true , None  , 1, false, 0,	63	}, /* 1079    	*/
        {NumConstant , false, None  , 1, false, 0,	16	}, /* 1080    	*/
        {SubFunction , true , None  , 1, false, 0,	351	}, /* 1081    	*/
        {SubFunction , false, None  , 1, false, 0,	353	}, /* 1082    	*/
    };

    const MatchedParams mlist[] =
    {
        {PositionalParams, BalanceDontCare, 1, 0 }, /* 0 */
        {PositionalParams, BalanceDontCare, 1, 1 }, /* 1 */
        {PositionalParams, BalanceDontCare, 1, 2 }, /* 2 */
        {PositionalParams, BalanceDontCare, 1, 3 }, /* 3 */
        {PositionalParams, BalanceDontCare, 1, 5 }, /* 4 */
        {PositionalParams, BalanceDontCare, 1, 6 }, /* 5 */
        {PositionalParams, BalanceDontCare, 1, 7 }, /* 6 */
        {PositionalParams, BalanceDontCare, 1, 8 }, /* 7 */
        {PositionalParams, BalanceDontCare, 1, 9 }, /* 8 */
        {PositionalParams, BalanceDontCare, 1, 10 }, /* 9 */
        {PositionalParams, BalanceDontCare, 1, 11 }, /* 10 */
        {PositionalParams, BalanceDontCare, 1, 12 }, /* 11 */
        {PositionalParams, BalanceDontCare, 1, 13 }, /* 12 */
        {PositionalParams, BalanceDontCare, 1, 14 }, /* 13 */
        {AnyParams       , BalanceDontCare, 2, 17 }, /* 14 */
        {PositionalParams, BalanceDontCare, 1, 19 }, /* 15 */
        {PositionalParams, BalanceDontCare, 1, 20 }, /* 16 */
        {PositionalParams, BalanceDontCare, 1, 21 }, /* 17 */
        {PositionalParams, BalanceDontCare, 1, 22 }, /* 18 */
        {PositionalParams, BalanceDontCare, 3, 23 }, /* 19 */
        {PositionalParams, BalanceDontCare, 1, 26 }, /* 20 */
        {PositionalParams, BalanceDontCare, 3, 27 }, /* 21 */
        {PositionalParams, BalanceDontCare, 3, 30 }, /* 22 */
        {AnyParams       , BalanceDontCare, 3, 33 }, /* 23 */
        {PositionalParams, BalanceDontCare, 3, 36 }, /* 24 */
        {PositionalParams, BalanceDontCare, 2, 34 }, /* 25 */
        {PositionalParams, BalanceDontCare, 3, 39 }, /* 26 */
        {PositionalParams, BalanceDontCare, 2, 42 }, /* 27 */
        {PositionalParams, BalanceDontCare, 1, 44 }, /* 28 */
        {AnyParams       , BalanceDontCare, 3, 45 }, /* 29 */
        {PositionalParams, BalanceDontCare, 3, 48 }, /* 30 */
        {PositionalParams, BalanceDontCare, 2, 51 }, /* 31 */
        {PositionalParams, BalanceDontCare, 3, 53 }, /* 32 */
        {PositionalParams, BalanceDontCare, 2, 56 }, /* 33 */
        {PositionalParams, BalanceDontCare, 1, 58 }, /* 34 */
        {AnyParams       , BalanceDontCare, 3, 59 }, /* 35 */
        {PositionalParams, BalanceDontCare, 3, 62 }, /* 36 */
        {PositionalParams, BalanceDontCare, 3, 65 }, /* 37 */
        {PositionalParams, BalanceDontCare, 2, 68 }, /* 38 */
        {PositionalParams, BalanceDontCare, 1, 70 }, /* 39 */
        {AnyParams       , BalanceDontCare, 3, 71 }, /* 40 */
        {PositionalParams, BalanceDontCare, 3, 74 }, /* 41 */
        {PositionalParams, BalanceDontCare, 2, 77 }, /* 42 */
        {PositionalParams, BalanceDontCare, 3, 79 }, /* 43 */
        {PositionalParams, BalanceDontCare, 2, 82 }, /* 44 */
        {PositionalParams, BalanceDontCare, 1, 84 }, /* 45 */
        {AnyParams       , BalanceDontCare, 3, 85 }, /* 46 */
        {AnyParams       , BalanceDontCare, 3, 88 }, /* 47 */
        {PositionalParams, BalanceDontCare, 3, 91 }, /* 48 */
        {PositionalParams, BalanceDontCare, 2, 94 }, /* 49 */
        {PositionalParams, BalanceDontCare, 2, 89 }, /* 50 */
        {PositionalParams, BalanceDontCare, 3, 96 }, /* 51 */
        {PositionalParams, BalanceDontCare, 2, 99 }, /* 52 */
        {PositionalParams, BalanceDontCare, 1, 101 }, /* 53 */
        {AnyParams       , BalanceDontCare, 3, 102 }, /* 54 */
        {AnyParams       , BalanceDontCare, 3, 105 }, /* 55 */
        {PositionalParams, BalanceDontCare, 3, 108 }, /* 56 */
        {PositionalParams, BalanceDontCare, 2, 111 }, /* 57 */
        {PositionalParams, BalanceDontCare, 3, 113 }, /* 58 */
        {PositionalParams, BalanceDontCare, 2, 116 }, /* 59 */
        {PositionalParams, BalanceDontCare, 1, 118 }, /* 60 */
        {AnyParams       , BalanceDontCare, 3, 119 }, /* 61 */
        {AnyParams       , BalanceDontCare, 3, 122 }, /* 62 */
        {PositionalParams, BalanceDontCare, 3, 125 }, /* 63 */
        {PositionalParams, BalanceDontCare, 2, 128 }, /* 64 */
        {PositionalParams, BalanceDontCare, 2, 130 }, /* 65 */
        {PositionalParams, BalanceDontCare, 3, 132 }, /* 66 */
        {PositionalParams, BalanceDontCare, 2, 135 }, /* 67 */
        {PositionalParams, BalanceDontCare, 1, 137 }, /* 68 */
        {AnyParams       , BalanceDontCare, 3, 138 }, /* 69 */
        {AnyParams       , BalanceDontCare, 3, 141 }, /* 70 */
        {PositionalParams, BalanceDontCare, 3, 144 }, /* 71 */
        {PositionalParams, BalanceDontCare, 2, 147 }, /* 72 */
        {PositionalParams, BalanceDontCare, 2, 149 }, /* 73 */
        {PositionalParams, BalanceDontCare, 3, 151 }, /* 74 */
        {PositionalParams, BalanceDontCare, 2, 154 }, /* 75 */
        {PositionalParams, BalanceDontCare, 1, 156 }, /* 76 */
        {AnyParams       , BalanceDontCare, 1, 0 }, /* 77 */
        {PositionalParams, BalanceDontCare, 3, 157 }, /* 78 */
        {PositionalParams, BalanceDontCare, 3, 160 }, /* 79 */
        {PositionalParams, BalanceDontCare, 1, 163 }, /* 80 */
        {AnyParams       , BalanceDontCare, 1, 18 }, /* 81 */
        {PositionalParams, BalanceDontCare, 3, 164 }, /* 82 */
        {PositionalParams, BalanceDontCare, 3, 167 }, /* 83 */
        {PositionalParams, BalanceDontCare, 1, 170 }, /* 84 */
        {PositionalParams, BalanceDontCare, 1, 171 }, /* 85 */
        {PositionalParams, BalanceDontCare, 1, 172 }, /* 86 */
        {PositionalParams, BalanceDontCare, 2, 173 }, /* 87 */
        {PositionalParams, BalanceDontCare, 1, 175 }, /* 88 */
        {PositionalParams, BalanceDontCare, 1, 18 }, /* 89 */
        {PositionalParams, BalanceDontCare, 2, 176 }, /* 90 */
        {PositionalParams, BalanceDontCare, 1, 178 }, /* 91 */
        {PositionalParams, BalanceDontCare, 2, 179 }, /* 92 */
        {AnyParams       , BalanceDontCare, 3, 181 }, /* 93 */
        {PositionalParams, BalanceDontCare, 1, 184 }, /* 94 */
        {PositionalParams, BalanceDontCare, 2, 185 }, /* 95 */
        {PositionalParams, BalanceDontCare, 1, 187 }, /* 96 */
        {PositionalParams, BalanceDontCare, 2, 188 }, /* 97 */
        {PositionalParams, BalanceDontCare, 1, 190 }, /* 98 */
        {PositionalParams, BalanceDontCare, 0, 0 }, /* 99 */
        {PositionalParams, BalanceDontCare, 1, 191 }, /* 100 */
        {AnyParams       , BalanceDontCare, 1, 72 }, /* 101 */
        {AnyParams       , BalanceDontCare, 1, 192 }, /* 102 */
        {PositionalParams, BalanceDontCare, 1, 185 }, /* 103 */
        {AnyParams       , BalanceDontCare, 2, 193 }, /* 104 */
        {PositionalParams, BalanceDontCare, 1, 197 }, /* 105 */
        {AnyParams       , BalanceDontCare, 2, 198 }, /* 106 */
        {PositionalParams, BalanceDontCare, 1, 200 }, /* 107 */
        {AnyParams       , BalanceDontCare, 1, 34 }, /* 108 */
        {AnyParams       , BalanceDontCare, 1, 201 }, /* 109 */
        {PositionalParams, BalanceDontCare, 1, 51 }, /* 110 */
        {AnyParams       , BalanceDontCare, 2, 202 }, /* 111 */
        {PositionalParams, BalanceDontCare, 1, 206 }, /* 112 */
        {AnyParams       , BalanceDontCare, 2, 207 }, /* 113 */
        {PositionalParams, BalanceDontCare, 2, 209 }, /* 114 */
        {PositionalParams, BalanceDontCare, 1, 66 }, /* 115 */
        {PositionalParams, BalanceDontCare, 2, 211 }, /* 116 */
        {PositionalParams, BalanceDontCare, 1, 213 }, /* 117 */
        {PositionalParams, BalanceDontCare, 2, 214 }, /* 118 */
        {PositionalParams, BalanceDontCare, 1, 75 }, /* 119 */
        {AnyParams       , BalanceDontCare, 3, 216 }, /* 120 */
        {PositionalParams, BalanceDontCare, 2, 219 }, /* 121 */
        {PositionalParams, BalanceDontCare, 2, 221 }, /* 122 */
        {PositionalParams, BalanceDontCare, 2, 223 }, /* 123 */
        {PositionalParams, BalanceDontCare, 2, 225 }, /* 124 */
        {PositionalParams, BalanceDontCare, 1, 229 }, /* 125 */
        {AnyParams       , BalanceDontCare, 4, 230 }, /* 126 */
        {PositionalParams, BalanceDontCare, 2, 234 }, /* 127 */
        {PositionalParams, BalanceDontCare, 2, 236 }, /* 128 */
        {PositionalParams, BalanceDontCare, 2, 238 }, /* 129 */
        {AnyParams       , BalanceDontCare, 4, 240 }, /* 130 */
        {PositionalParams, BalanceDontCare, 2, 244 }, /* 131 */
        {PositionalParams, BalanceDontCare, 2, 246 }, /* 132 */
        {PositionalParams, BalanceDontCare, 2, 248 }, /* 133 */
        {PositionalParams, BalanceDontCare, 2, 250 }, /* 134 */
        {PositionalParams, BalanceDontCare, 1, 252 }, /* 135 */
        {PositionalParams, BalanceDontCare, 2, 253 }, /* 136 */
        {PositionalParams, BalanceDontCare, 1, 27 }, /* 137 */
        {PositionalParams, BalanceDontCare, 2, 255 }, /* 138 */
        {AnyParams       , BalanceMoreNeg , 2, 34 }, /* 139 */
        {PositionalParams, BalanceDontCare, 2, 257 }, /* 140 */
        {PositionalParams, BalanceDontCare, 2, 259 }, /* 141 */
        {PositionalParams, BalanceDontCare, 2, 261 }, /* 142 */
        {PositionalParams, BalanceDontCare, 1, 263 }, /* 143 */
        {PositionalParams, BalanceDontCare, 1, 264 }, /* 144 */
        {PositionalParams, BalanceDontCare, 1, 159 }, /* 145 */
        {AnyParams       , BalanceDontCare, 4, 265 }, /* 146 */
        {PositionalParams, BalanceDontCare, 2, 269 }, /* 147 */
        {PositionalParams, BalanceDontCare, 2, 271 }, /* 148 */
        {PositionalParams, BalanceDontCare, 2, 273 }, /* 149 */
        {PositionalParams, BalanceDontCare, 2, 275 }, /* 150 */
        {PositionalParams, BalanceDontCare, 2, 277 }, /* 151 */
        {PositionalParams, BalanceDontCare, 2, 279 }, /* 152 */
        {PositionalParams, BalanceDontCare, 2, 281 }, /* 153 */
        {PositionalParams, BalanceDontCare, 1, 283 }, /* 154 */
        {PositionalParams, BalanceDontCare, 1, 284 }, /* 155 */
        {PositionalParams, BalanceDontCare, 1, 285 }, /* 156 */
        {PositionalParams, BalanceDontCare, 1, 286 }, /* 157 */
        {PositionalParams, BalanceDontCare, 1, 287 }, /* 158 */
        {PositionalParams, BalanceDontCare, 1, 288 }, /* 159 */
        {AnyParams       , BalanceDontCare, 2, 291 }, /* 160 */
        {PositionalParams, BalanceDontCare, 1, 293 }, /* 161 */
        {PositionalParams, BalanceDontCare, 1, 294 }, /* 162 */
        {PositionalParams, BalanceDontCare, 1, 295 }, /* 163 */
        {PositionalParams, BalanceDontCare, 1, 296 }, /* 164 */
        {PositionalParams, BalanceDontCare, 1, 297 }, /* 165 */
        {PositionalParams, BalanceDontCare, 1, 298 }, /* 166 */
        {PositionalParams, BalanceDontCare, 1, 299 }, /* 167 */
        {PositionalParams, BalanceDontCare, 1, 4 }, /* 168 */
        {PositionalParams, BalanceDontCare, 1, 300 }, /* 169 */
        {AnyParams       , BalanceDontCare, 1, 66 }, /* 170 */
        {AnyParams       , BalanceDontCare, 2, 34 }, /* 171 */
        {AnyParams       , BalanceDontCare, 1, 301 }, /* 172 */
        {PositionalParams, BalanceDontCare, 2, 302 }, /* 173 */
        {AnyParams       , BalanceMoreNeg , 2, 304 }, /* 174 */
        {AnyParams       , BalanceDontCare, 3, 306 }, /* 175 */
        {AnyParams       , BalanceDontCare, 1, 309 }, /* 176 */
        {PositionalParams, BalanceDontCare, 2, 310 }, /* 177 */
        {PositionalParams, BalanceDontCare, 3, 312 }, /* 178 */
        {PositionalParams, BalanceDontCare, 1, 315 }, /* 179 */
        {AnyParams       , BalanceDontCare, 1, 316 }, /* 180 */
        {PositionalParams, BalanceDontCare, 1, 317 }, /* 181 */
        {AnyParams       , BalanceDontCare, 2, 318 }, /* 182 */
        {AnyParams       , BalanceDontCare, 1, 320 }, /* 183 */
        {PositionalParams, BalanceDontCare, 2, 321 }, /* 184 */
        {AnyParams       , BalanceDontCare, 3, 323 }, /* 185 */
        {AnyParams       , BalanceDontCare, 1, 326 }, /* 186 */
        {PositionalParams, BalanceDontCare, 3, 327 }, /* 187 */
        {PositionalParams, BalanceDontCare, 1, 330 }, /* 188 */
        {AnyParams       , BalanceMoreNeg , 2, 331 }, /* 189 */
        {AnyParams       , BalanceDontCare, 3, 333 }, /* 190 */
        {AnyParams       , BalanceDontCare, 1, 336 }, /* 191 */
        {PositionalParams, BalanceDontCare, 3, 337 }, /* 192 */
        {PositionalParams, BalanceDontCare, 1, 340 }, /* 193 */
        {PositionalParams, BalanceDontCare, 2, 341 }, /* 194 */
        {AnyParams       , BalanceDontCare, 2, 343 }, /* 195 */
        {PositionalParams, BalanceDontCare, 2, 345 }, /* 196 */
        {PositionalParams, BalanceDontCare, 1, 347 }, /* 197 */
        {PositionalParams, BalanceDontCare, 2, 348 }, /* 198 */
        {AnyParams       , BalanceDontCare, 2, 350 }, /* 199 */
        {PositionalParams, BalanceDontCare, 2, 352 }, /* 200 */
        {PositionalParams, BalanceDontCare, 1, 354 }, /* 201 */
        {AnyParams       , BalanceDontCare, 2, 355 }, /* 202 */
        {PositionalParams, BalanceDontCare, 1, 359 }, /* 203 */
        {AnyParams       , BalanceDontCare, 2, 360 }, /* 204 */
        {AnyParams       , BalanceDontCare, 2, 362 }, /* 205 */
        {PositionalParams, BalanceDontCare, 2, 364 }, /* 206 */
        {PositionalParams, BalanceDontCare, 1, 366 }, /* 207 */
        {PositionalParams, BalanceDontCare, 1, 367 }, /* 208 */
        {PositionalParams, BalanceDontCare, 2, 368 }, /* 209 */
        {PositionalParams, BalanceDontCare, 2, 370 }, /* 210 */
        {AnyParams       , BalanceDontCare, 2, 372 }, /* 211 */
        {AnyParams       , BalanceDontCare, 3, 374 }, /* 212 */
        {AnyParams       , BalanceDontCare, 3, 377 }, /* 213 */
        {AnyParams       , BalanceDontCare, 2, 380 }, /* 214 */
        {PositionalParams, BalanceDontCare, 2, 382 }, /* 215 */
        {PositionalParams, BalanceDontCare, 2, 384 }, /* 216 */
        {PositionalParams, BalanceDontCare, 2, 386 }, /* 217 */
        {PositionalParams, BalanceDontCare, 2, 388 }, /* 218 */
        {PositionalParams, BalanceDontCare, 1, 390 }, /* 219 */
        {AnyParams       , BalanceDontCare, 3, 391 }, /* 220 */
        {AnyParams       , BalanceDontCare, 3, 394 }, /* 221 */
        {AnyParams       , BalanceDontCare, 2, 397 }, /* 222 */
        {PositionalParams, BalanceDontCare, 2, 399 }, /* 223 */
        {PositionalParams, BalanceDontCare, 2, 401 }, /* 224 */
        {PositionalParams, BalanceDontCare, 2, 403 }, /* 225 */
        {PositionalParams, BalanceDontCare, 2, 405 }, /* 226 */
        {PositionalParams, BalanceDontCare, 1, 407 }, /* 227 */
        {AnyParams       , BalanceDontCare, 3, 408 }, /* 228 */
        {AnyParams       , BalanceDontCare, 3, 411 }, /* 229 */
        {AnyParams       , BalanceDontCare, 2, 414 }, /* 230 */
        {PositionalParams, BalanceDontCare, 2, 416 }, /* 231 */
        {PositionalParams, BalanceDontCare, 2, 418 }, /* 232 */
        {PositionalParams, BalanceDontCare, 2, 420 }, /* 233 */
        {PositionalParams, BalanceDontCare, 2, 422 }, /* 234 */
        {PositionalParams, BalanceDontCare, 1, 424 }, /* 235 */
        {AnyParams       , BalanceDontCare, 3, 425 }, /* 236 */
        {AnyParams       , BalanceDontCare, 3, 428 }, /* 237 */
        {AnyParams       , BalanceDontCare, 2, 431 }, /* 238 */
        {PositionalParams, BalanceDontCare, 2, 433 }, /* 239 */
        {PositionalParams, BalanceDontCare, 2, 435 }, /* 240 */
        {PositionalParams, BalanceDontCare, 2, 437 }, /* 241 */
        {PositionalParams, BalanceDontCare, 2, 439 }, /* 242 */
        {PositionalParams, BalanceDontCare, 1, 441 }, /* 243 */
        {SelectedParams  , BalanceDontCare, 2, 442 }, /* 244 */
        {PositionalParams, BalanceDontCare, 1, 25 }, /* 245 */
        {SelectedParams  , BalanceDontCare, 2, 444 }, /* 246 */
        {AnyParams       , BalanceDontCare, 2, 446 }, /* 247 */
        {PositionalParams, BalanceDontCare, 2, 448 }, /* 248 */
        {PositionalParams, BalanceDontCare, 1, 450 }, /* 249 */
        {PositionalParams, BalanceDontCare, 1, 451 }, /* 250 */
        {SelectedParams  , BalanceDontCare, 2, 452 }, /* 251 */
        {PositionalParams, BalanceDontCare, 1, 29 }, /* 252 */
        {SelectedParams  , BalanceDontCare, 2, 454 }, /* 253 */
        {AnyParams       , BalanceDontCare, 2, 456 }, /* 254 */
        {PositionalParams, BalanceDontCare, 2, 458 }, /* 255 */
        {PositionalParams, BalanceDontCare, 1, 460 }, /* 256 */
        {PositionalParams, BalanceDontCare, 1, 461 }, /* 257 */
        {SelectedParams  , BalanceDontCare, 2, 462 }, /* 258 */
        {SelectedParams  , BalanceDontCare, 2, 464 }, /* 259 */
        {AnyParams       , BalanceDontCare, 2, 466 }, /* 260 */
        {PositionalParams, BalanceDontCare, 2, 468 }, /* 261 */
        {PositionalParams, BalanceDontCare, 1, 470 }, /* 262 */
        {PositionalParams, BalanceDontCare, 1, 471 }, /* 263 */
        {SelectedParams  , BalanceDontCare, 2, 472 }, /* 264 */
        {SelectedParams  , BalanceDontCare, 2, 474 }, /* 265 */
        {AnyParams       , BalanceDontCare, 2, 476 }, /* 266 */
        {PositionalParams, BalanceDontCare, 2, 478 }, /* 267 */
        {PositionalParams, BalanceDontCare, 1, 480 }, /* 268 */
        {PositionalParams, BalanceDontCare, 1, 481 }, /* 269 */
        {AnyParams       , BalanceDontCare, 3, 482 }, /* 270 */
        {AnyParams       , BalanceDontCare, 2, 485 }, /* 271 */
        {PositionalParams, BalanceDontCare, 2, 487 }, /* 272 */
        {PositionalParams, BalanceDontCare, 2, 489 }, /* 273 */
        {PositionalParams, BalanceDontCare, 2, 491 }, /* 274 */
        {PositionalParams, BalanceDontCare, 1, 493 }, /* 275 */
        {AnyParams       , BalanceDontCare, 3, 494 }, /* 276 */
        {AnyParams       , BalanceDontCare, 2, 497 }, /* 277 */
        {PositionalParams, BalanceDontCare, 2, 499 }, /* 278 */
        {PositionalParams, BalanceDontCare, 2, 501 }, /* 279 */
        {PositionalParams, BalanceDontCare, 2, 503 }, /* 280 */
        {PositionalParams, BalanceDontCare, 1, 505 }, /* 281 */
        {AnyParams       , BalanceDontCare, 3, 506 }, /* 282 */
        {AnyParams       , BalanceDontCare, 3, 509 }, /* 283 */
        {AnyParams       , BalanceDontCare, 2, 512 }, /* 284 */
        {PositionalParams, BalanceDontCare, 2, 514 }, /* 285 */
        {PositionalParams, BalanceDontCare, 2, 516 }, /* 286 */
        {PositionalParams, BalanceDontCare, 2, 518 }, /* 287 */
        {PositionalParams, BalanceDontCare, 2, 520 }, /* 288 */
        {PositionalParams, BalanceDontCare, 1, 522 }, /* 289 */
        {AnyParams       , BalanceDontCare, 3, 523 }, /* 290 */
        {AnyParams       , BalanceDontCare, 3, 526 }, /* 291 */
        {AnyParams       , BalanceDontCare, 2, 529 }, /* 292 */
        {PositionalParams, BalanceDontCare, 2, 531 }, /* 293 */
        {PositionalParams, BalanceDontCare, 2, 533 }, /* 294 */
        {PositionalParams, BalanceDontCare, 2, 535 }, /* 295 */
        {PositionalParams, BalanceDontCare, 2, 537 }, /* 296 */
        {PositionalParams, BalanceDontCare, 1, 539 }, /* 297 */
        {SelectedParams  , BalanceDontCare, 2, 540 }, /* 298 */
        {AnyParams       , BalanceDontCare, 2, 542 }, /* 299 */
        {PositionalParams, BalanceDontCare, 2, 544 }, /* 300 */
        {PositionalParams, BalanceDontCare, 1, 546 }, /* 301 */
        {PositionalParams, BalanceDontCare, 1, 547 }, /* 302 */
        {SelectedParams  , BalanceDontCare, 2, 548 }, /* 303 */
        {AnyParams       , BalanceDontCare, 2, 550 }, /* 304 */
        {PositionalParams, BalanceDontCare, 2, 552 }, /* 305 */
        {PositionalParams, BalanceDontCare, 1, 554 }, /* 306 */
        {PositionalParams, BalanceDontCare, 1, 555 }, /* 307 */
        {SelectedParams  , BalanceDontCare, 2, 556 }, /* 308 */
        {SelectedParams  , BalanceDontCare, 2, 558 }, /* 309 */
        {AnyParams       , BalanceDontCare, 2, 560 }, /* 310 */
        {PositionalParams, BalanceDontCare, 2, 562 }, /* 311 */
        {PositionalParams, BalanceDontCare, 1, 564 }, /* 312 */
        {PositionalParams, BalanceDontCare, 1, 565 }, /* 313 */
        {AnyParams       , BalanceDontCare, 3, 566 }, /* 314 */
        {AnyParams       , BalanceDontCare, 2, 569 }, /* 315 */
        {PositionalParams, BalanceDontCare, 2, 571 }, /* 316 */
        {PositionalParams, BalanceDontCare, 2, 573 }, /* 317 */
        {PositionalParams, BalanceDontCare, 2, 575 }, /* 318 */
        {PositionalParams, BalanceDontCare, 1, 577 }, /* 319 */
        {AnyParams       , BalanceDontCare, 3, 578 }, /* 320 */
        {AnyParams       , BalanceDontCare, 2, 581 }, /* 321 */
        {PositionalParams, BalanceDontCare, 2, 583 }, /* 322 */
        {PositionalParams, BalanceDontCare, 2, 585 }, /* 323 */
        {PositionalParams, BalanceDontCare, 2, 587 }, /* 324 */
        {PositionalParams, BalanceDontCare, 1, 589 }, /* 325 */
        {AnyParams       , BalanceDontCare, 1, 590 }, /* 326 */
        {PositionalParams, BalanceDontCare, 2, 591 }, /* 327 */
        {PositionalParams, BalanceDontCare, 1, 593 }, /* 328 */
        {AnyParams       , BalanceDontCare, 1, 594 }, /* 329 */
        {PositionalParams, BalanceDontCare, 2, 595 }, /* 330 */
        {PositionalParams, BalanceDontCare, 1, 597 }, /* 331 */
        {PositionalParams, BalanceDontCare, 2, 598 }, /* 332 */
        {PositionalParams, BalanceDontCare, 2, 600 }, /* 333 */
        {AnyParams       , BalanceDontCare, 4, 602 }, /* 334 */
        {AnyParams       , BalanceDontCare, 3, 606 }, /* 335 */
        {PositionalParams, BalanceDontCare, 2, 609 }, /* 336 */
        {PositionalParams, BalanceDontCare, 2, 611 }, /* 337 */
        {PositionalParams, BalanceDontCare, 2, 613 }, /* 338 */
        {PositionalParams, BalanceDontCare, 2, 615 }, /* 339 */
        {PositionalParams, BalanceDontCare, 3, 617 }, /* 340 */
        {PositionalParams, BalanceDontCare, 2, 620 }, /* 341 */
        {PositionalParams, BalanceDontCare, 1, 80 }, /* 342 */
        {AnyParams       , BalanceDontCare, 2, 622 }, /* 343 */
        {PositionalParams, BalanceDontCare, 1, 624 }, /* 344 */
        {PositionalParams, BalanceDontCare, 1, 625 }, /* 345 */
        {PositionalParams, BalanceDontCare, 1, 626 }, /* 346 */
        {AnyParams       , BalanceDontCare, 3, 627 }, /* 347 */
        {PositionalParams, BalanceDontCare, 2, 630 }, /* 348 */
        {PositionalParams, BalanceDontCare, 1, 632 }, /* 349 */
        {PositionalParams, BalanceDontCare, 1, 633 }, /* 350 */
        {AnyParams       , BalanceDontCare, 1, 209 }, /* 351 */
        {PositionalParams, BalanceDontCare, 1, 209 }, /* 352 */
        {AnyParams       , BalanceDontCare, 1, 213 }, /* 353 */
        {AnyParams       , BalanceDontCare, 2, 634 }, /* 354 */
        {AnyParams       , BalanceDontCare, 1, 636 }, /* 355 */
        {PositionalParams, BalanceDontCare, 2, 637 }, /* 356 */
        {PositionalParams, BalanceDontCare, 2, 639 }, /* 357 */
        {AnyParams       , BalanceDontCare, 1, 641 }, /* 358 */
        {PositionalParams, BalanceDontCare, 2, 642 }, /* 359 */
        {PositionalParams, BalanceDontCare, 1, 644 }, /* 360 */
        {AnyParams       , BalanceDontCare, 1, 645 }, /* 361 */
        {PositionalParams, BalanceDontCare, 2, 646 }, /* 362 */
        {AnyParams       , BalanceDontCare, 2, 648 }, /* 363 */
        {PositionalParams, BalanceDontCare, 1, 652 }, /* 364 */
        {AnyParams       , BalanceDontCare, 2, 653 }, /* 365 */
        {PositionalParams, BalanceDontCare, 1, 657 }, /* 366 */
        {AnyParams       , BalanceDontCare, 2, 658 }, /* 367 */
        {PositionalParams, BalanceDontCare, 2, 660 }, /* 368 */
        {PositionalParams, BalanceDontCare, 1, 662 }, /* 369 */
        {AnyParams       , BalanceDontCare, 2, 663 }, /* 370 */
        {PositionalParams, BalanceDontCare, 2, 665 }, /* 371 */
        {PositionalParams, BalanceDontCare, 1, 667 }, /* 372 */
        {AnyParams       , BalanceDontCare, 2, 668 }, /* 373 */
        {PositionalParams, BalanceDontCare, 2, 670 }, /* 374 */
        {PositionalParams, BalanceDontCare, 1, 672 }, /* 375 */
        {AnyParams       , BalanceDontCare, 2, 673 }, /* 376 */
        {PositionalParams, BalanceDontCare, 2, 675 }, /* 377 */
        {AnyParams       , BalanceDontCare, 2, 677 }, /* 378 */
        {PositionalParams, BalanceDontCare, 1, 679 }, /* 379 */
        {AnyParams       , BalanceDontCare, 2, 680 }, /* 380 */
        {PositionalParams, BalanceDontCare, 2, 682 }, /* 381 */
        {PositionalParams, BalanceDontCare, 2, 684 }, /* 382 */
        {PositionalParams, BalanceDontCare, 1, 686 }, /* 383 */
        {PositionalParams, BalanceDontCare, 2, 687 }, /* 384 */
        {AnyParams       , BalanceDontCare, 2, 689 }, /* 385 */
        {PositionalParams, BalanceDontCare, 1, 691 }, /* 386 */
        {AnyParams       , BalanceDontCare, 2, 692 }, /* 387 */
        {PositionalParams, BalanceDontCare, 2, 694 }, /* 388 */
        {PositionalParams, BalanceDontCare, 2, 696 }, /* 389 */
        {PositionalParams, BalanceDontCare, 1, 698 }, /* 390 */
        {PositionalParams, BalanceDontCare, 2, 699 }, /* 391 */
        {AnyParams       , BalanceDontCare, 2, 701 }, /* 392 */
        {PositionalParams, BalanceDontCare, 1, 703 }, /* 393 */
        {AnyParams       , BalanceDontCare, 2, 704 }, /* 394 */
        {PositionalParams, BalanceDontCare, 1, 280 }, /* 395 */
        {PositionalParams, BalanceDontCare, 2, 706 }, /* 396 */
        {PositionalParams, BalanceDontCare, 2, 708 }, /* 397 */
        {PositionalParams, BalanceDontCare, 1, 710 }, /* 398 */
        {PositionalParams, BalanceDontCare, 2, 711 }, /* 399 */
        {PositionalParams, BalanceDontCare, 2, 713 }, /* 400 */
        {AnyParams       , BalanceDontCare, 2, 715 }, /* 401 */
        {PositionalParams, BalanceDontCare, 2, 717 }, /* 402 */
        {PositionalParams, BalanceDontCare, 2, 719 }, /* 403 */
        {PositionalParams, BalanceDontCare, 1, 721 }, /* 404 */
        {PositionalParams, BalanceDontCare, 2, 722 }, /* 405 */
        {PositionalParams, BalanceDontCare, 2, 724 }, /* 406 */
        {AnyParams       , BalanceDontCare, 2, 726 }, /* 407 */
        {PositionalParams, BalanceDontCare, 2, 728 }, /* 408 */
        {PositionalParams, BalanceDontCare, 2, 730 }, /* 409 */
        {PositionalParams, BalanceDontCare, 1, 732 }, /* 410 */
        {AnyParams       , BalanceDontCare, 2, 733 }, /* 411 */
        {PositionalParams, BalanceDontCare, 1, 735 }, /* 412 */
        {AnyParams       , BalanceDontCare, 2, 736 }, /* 413 */
        {PositionalParams, BalanceDontCare, 1, 738 }, /* 414 */
        {PositionalParams, BalanceDontCare, 2, 739 }, /* 415 */
        {AnyParams       , BalanceDontCare, 2, 741 }, /* 416 */
        {PositionalParams, BalanceDontCare, 2, 743 }, /* 417 */
        {PositionalParams, BalanceDontCare, 2, 745 }, /* 418 */
        {PositionalParams, BalanceDontCare, 1, 747 }, /* 419 */
        {PositionalParams, BalanceDontCare, 2, 748 }, /* 420 */
        {AnyParams       , BalanceDontCare, 2, 750 }, /* 421 */
        {PositionalParams, BalanceDontCare, 2, 752 }, /* 422 */
        {PositionalParams, BalanceDontCare, 2, 754 }, /* 423 */
        {PositionalParams, BalanceDontCare, 1, 756 }, /* 424 */
        {AnyParams       , BalanceDontCare, 2, 757 }, /* 425 */
        {PositionalParams, BalanceDontCare, 1, 761 }, /* 426 */
        {PositionalParams, BalanceDontCare, 2, 762 }, /* 427 */
        {PositionalParams, BalanceDontCare, 1, 764 }, /* 428 */
        {AnyParams       , BalanceDontCare, 2, 765 }, /* 429 */
        {PositionalParams, BalanceDontCare, 1, 753 }, /* 430 */
        {PositionalParams, BalanceDontCare, 2, 767 }, /* 431 */
        {PositionalParams, BalanceDontCare, 1, 769 }, /* 432 */
        {AnyParams       , BalanceDontCare, 2, 770 }, /* 433 */
        {PositionalParams, BalanceDontCare, 1, 459 }, /* 434 */
        {PositionalParams, BalanceDontCare, 2, 772 }, /* 435 */
        {PositionalParams, BalanceDontCare, 2, 774 }, /* 436 */
        {AnyParams       , BalanceDontCare, 2, 776 }, /* 437 */
        {PositionalParams, BalanceDontCare, 2, 778 }, /* 438 */
        {PositionalParams, BalanceDontCare, 2, 780 }, /* 439 */
        {PositionalParams, BalanceDontCare, 1, 782 }, /* 440 */
        {AnyParams       , BalanceDontCare, 2, 783 }, /* 441 */
        {PositionalParams, BalanceDontCare, 1, 785 }, /* 442 */
        {AnyParams       , BalanceDontCare, 2, 786 }, /* 443 */
        {PositionalParams, BalanceDontCare, 1, 788 }, /* 444 */
        {PositionalParams, BalanceDontCare, 2, 789 }, /* 445 */
        {AnyParams       , BalanceDontCare, 2, 791 }, /* 446 */
        {PositionalParams, BalanceDontCare, 2, 793 }, /* 447 */
        {PositionalParams, BalanceDontCare, 2, 795 }, /* 448 */
        {PositionalParams, BalanceDontCare, 1, 797 }, /* 449 */
        {PositionalParams, BalanceDontCare, 2, 798 }, /* 450 */
        {AnyParams       , BalanceDontCare, 2, 800 }, /* 451 */
        {PositionalParams, BalanceDontCare, 2, 802 }, /* 452 */
        {PositionalParams, BalanceDontCare, 2, 804 }, /* 453 */
        {PositionalParams, BalanceDontCare, 1, 806 }, /* 454 */
        {AnyParams       , BalanceDontCare, 1, 592 }, /* 455 */
        {PositionalParams, BalanceDontCare, 2, 807 }, /* 456 */
        {PositionalParams, BalanceDontCare, 1, 809 }, /* 457 */
        {AnyParams       , BalanceDontCare, 1, 810 }, /* 458 */
        {PositionalParams, BalanceDontCare, 2, 811 }, /* 459 */
        {PositionalParams, BalanceDontCare, 1, 813 }, /* 460 */
        {PositionalParams, BalanceDontCare, 2, 814 }, /* 461 */
        {PositionalParams, BalanceDontCare, 1, 818 }, /* 462 */
        {PositionalParams, BalanceDontCare, 2, 819 }, /* 463 */
        {PositionalParams, BalanceDontCare, 2, 821 }, /* 464 */
        {PositionalParams, BalanceDontCare, 2, 823 }, /* 465 */
        {PositionalParams, BalanceDontCare, 2, 825 }, /* 466 */
        {PositionalParams, BalanceDontCare, 2, 827 }, /* 467 */
        {PositionalParams, BalanceDontCare, 2, 829 }, /* 468 */
        {PositionalParams, BalanceDontCare, 2, 831 }, /* 469 */
        {PositionalParams, BalanceDontCare, 1, 833 }, /* 470 */
        {PositionalParams, BalanceDontCare, 2, 834 }, /* 471 */
        {PositionalParams, BalanceDontCare, 1, 836 }, /* 472 */
        {PositionalParams, BalanceDontCare, 2, 837 }, /* 473 */
        {PositionalParams, BalanceDontCare, 1, 839 }, /* 474 */
        {PositionalParams, BalanceDontCare, 2, 840 }, /* 475 */
        {PositionalParams, BalanceDontCare, 1, 842 }, /* 476 */
        {PositionalParams, BalanceDontCare, 2, 843 }, /* 477 */
        {PositionalParams, BalanceDontCare, 1, 845 }, /* 478 */
        {PositionalParams, BalanceDontCare, 2, 846 }, /* 479 */
        {PositionalParams, BalanceDontCare, 1, 848 }, /* 480 */
        {PositionalParams, BalanceDontCare, 2, 849 }, /* 481 */
        {PositionalParams, BalanceDontCare, 1, 851 }, /* 482 */
        {PositionalParams, BalanceDontCare, 2, 852 }, /* 483 */
        {PositionalParams, BalanceDontCare, 1, 854 }, /* 484 */
        {PositionalParams, BalanceDontCare, 2, 855 }, /* 485 */
        {PositionalParams, BalanceDontCare, 1, 857 }, /* 486 */
        {PositionalParams, BalanceDontCare, 2, 858 }, /* 487 */
        {PositionalParams, BalanceDontCare, 1, 860 }, /* 488 */
        {PositionalParams, BalanceDontCare, 2, 861 }, /* 489 */
        {PositionalParams, BalanceDontCare, 1, 863 }, /* 490 */
        {PositionalParams, BalanceDontCare, 2, 864 }, /* 491 */
        {PositionalParams, BalanceDontCare, 1, 866 }, /* 492 */
        {AnyParams       , BalanceMoreNeg , 2, 867 }, /* 493 */
        {PositionalParams, BalanceDontCare, 2, 869 }, /* 494 */
        {PositionalParams, BalanceDontCare, 1, 871 }, /* 495 */
        {PositionalParams, BalanceDontCare, 1, 872 }, /* 496 */
        {PositionalParams, BalanceDontCare, 1, 425 }, /* 497 */
        {AnyParams       , BalanceDontCare, 1, 1 }, /* 498 */
        {AnyParams       , BalanceDontCare, 2, 873 }, /* 499 */
        {AnyParams       , BalanceDontCare, 1, 875 }, /* 500 */
        {AnyParams       , BalanceDontCare, 1, 2 }, /* 501 */
        {PositionalParams, BalanceDontCare, 2, 876 }, /* 502 */
        {AnyParams       , BalanceDontCare, 1, 878 }, /* 503 */
        {PositionalParams, BalanceDontCare, 2, 879 }, /* 504 */
        {PositionalParams, BalanceDontCare, 1, 881 }, /* 505 */
        {PositionalParams, BalanceDontCare, 2, 882 }, /* 506 */
        {AnyParams       , BalanceDontCare, 1, 884 }, /* 507 */
        {PositionalParams, BalanceDontCare, 2, 885 }, /* 508 */
        {PositionalParams, BalanceDontCare, 1, 887 }, /* 509 */
        {PositionalParams, BalanceDontCare, 2, 888 }, /* 510 */
        {AnyParams       , BalanceDontCare, 1, 890 }, /* 511 */
        {PositionalParams, BalanceDontCare, 2, 891 }, /* 512 */
        {PositionalParams, BalanceDontCare, 1, 893 }, /* 513 */
        {PositionalParams, BalanceDontCare, 2, 894 }, /* 514 */
        {AnyParams       , BalanceDontCare, 1, 896 }, /* 515 */
        {PositionalParams, BalanceDontCare, 2, 897 }, /* 516 */
        {PositionalParams, BalanceDontCare, 1, 899 }, /* 517 */
        {PositionalParams, BalanceDontCare, 2, 900 }, /* 518 */
        {AnyParams       , BalanceDontCare, 1, 902 }, /* 519 */
        {PositionalParams, BalanceDontCare, 2, 903 }, /* 520 */
        {PositionalParams, BalanceDontCare, 1, 905 }, /* 521 */
        {PositionalParams, BalanceDontCare, 2, 906 }, /* 522 */
        {AnyParams       , BalanceDontCare, 1, 908 }, /* 523 */
        {PositionalParams, BalanceDontCare, 2, 909 }, /* 524 */
        {PositionalParams, BalanceDontCare, 1, 911 }, /* 525 */
        {AnyParams       , BalanceDontCare, 1, 912 }, /* 526 */
        {AnyParams       , BalanceDontCare, 2, 913 }, /* 527 */
        {AnyParams       , BalanceDontCare, 1, 915 }, /* 528 */
        {AnyParams       , BalanceDontCare, 1, 916 }, /* 529 */
        {AnyParams       , BalanceDontCare, 2, 917 }, /* 530 */
        {AnyParams       , BalanceDontCare, 2, 919 }, /* 531 */
        {AnyParams       , BalanceDontCare, 2, 921 }, /* 532 */
        {AnyParams       , BalanceDontCare, 2, 834 }, /* 533 */
        {AnyParams       , BalanceDontCare, 2, 923 }, /* 534 */
        {AnyParams       , BalanceDontCare, 2, 925 }, /* 535 */
        {AnyParams       , BalanceDontCare, 2, 927 }, /* 536 */
        {AnyParams       , BalanceDontCare, 2, 929 }, /* 537 */
        {AnyParams       , BalanceDontCare, 2, 931 }, /* 538 */
        {AnyParams       , BalanceDontCare, 3, 933 }, /* 539 */
        {PositionalParams, BalanceDontCare, 2, 936 }, /* 540 */
        {PositionalParams, BalanceDontCare, 2, 938 }, /* 541 */
        {PositionalParams, BalanceDontCare, 2, 940 }, /* 542 */
        {PositionalParams, BalanceDontCare, 1, 942 }, /* 543 */
        {PositionalParams, BalanceDontCare, 1, 943 }, /* 544 */
        {AnyParams       , BalanceDontCare, 2, 944 }, /* 545 */
        {AnyParams       , BalanceDontCare, 1, 946 }, /* 546 */
        {PositionalParams, BalanceDontCare, 2, 947 }, /* 547 */
        {AnyParams       , BalanceDontCare, 1, 949 }, /* 548 */
        {PositionalParams, BalanceDontCare, 2, 950 }, /* 549 */
        {PositionalParams, BalanceDontCare, 1, 952 }, /* 550 */
        {PositionalParams, BalanceDontCare, 2, 953 }, /* 551 */
        {AnyParams       , BalanceDontCare, 1, 955 }, /* 552 */
        {PositionalParams, BalanceDontCare, 2, 956 }, /* 553 */
        {PositionalParams, BalanceDontCare, 1, 958 }, /* 554 */
        {PositionalParams, BalanceDontCare, 2, 959 }, /* 555 */
        {AnyParams       , BalanceDontCare, 1, 961 }, /* 556 */
        {PositionalParams, BalanceDontCare, 2, 962 }, /* 557 */
        {PositionalParams, BalanceDontCare, 1, 964 }, /* 558 */
        {PositionalParams, BalanceDontCare, 2, 965 }, /* 559 */
        {AnyParams       , BalanceDontCare, 1, 967 }, /* 560 */
        {PositionalParams, BalanceDontCare, 2, 968 }, /* 561 */
        {PositionalParams, BalanceDontCare, 1, 970 }, /* 562 */
        {PositionalParams, BalanceDontCare, 2, 971 }, /* 563 */
        {AnyParams       , BalanceDontCare, 1, 973 }, /* 564 */
        {PositionalParams, BalanceDontCare, 2, 974 }, /* 565 */
        {PositionalParams, BalanceDontCare, 1, 976 }, /* 566 */
        {PositionalParams, BalanceDontCare, 2, 977 }, /* 567 */
        {AnyParams       , BalanceDontCare, 1, 979 }, /* 568 */
        {PositionalParams, BalanceDontCare, 2, 980 }, /* 569 */
        {PositionalParams, BalanceDontCare, 1, 982 }, /* 570 */
        {AnyParams       , BalanceDontCare, 1, 983 }, /* 571 */
        {AnyParams       , BalanceDontCare, 2, 984 }, /* 572 */
        {AnyParams       , BalanceDontCare, 1, 986 }, /* 573 */
        {AnyParams       , BalanceDontCare, 1, 987 }, /* 574 */
        {AnyParams       , BalanceDontCare, 2, 988 }, /* 575 */
        {AnyParams       , BalanceDontCare, 2, 990 }, /* 576 */
        {AnyParams       , BalanceDontCare, 2, 992 }, /* 577 */
        {AnyParams       , BalanceDontCare, 2, 994 }, /* 578 */
        {AnyParams       , BalanceDontCare, 2, 996 }, /* 579 */
        {AnyParams       , BalanceDontCare, 2, 998 }, /* 580 */
        {PositionalParams, BalanceDontCare, 2, 1000 }, /* 581 */
        {PositionalParams, BalanceDontCare, 1, 1002 }, /* 582 */
        {PositionalParams, BalanceDontCare, 1, 1003 }, /* 583 */
        {PositionalParams, BalanceDontCare, 2, 1004 }, /* 584 */
        {PositionalParams, BalanceDontCare, 1, 1006 }, /* 585 */
        {PositionalParams, BalanceDontCare, 2, 1007 }, /* 586 */
        {PositionalParams, BalanceDontCare, 1, 1009 }, /* 587 */
        {PositionalParams, BalanceDontCare, 2, 1010 }, /* 588 */
        {PositionalParams, BalanceDontCare, 1, 1012 }, /* 589 */
        {PositionalParams, BalanceDontCare, 2, 1013 }, /* 590 */
        {PositionalParams, BalanceDontCare, 1, 1015 }, /* 591 */
        {PositionalParams, BalanceDontCare, 2, 1016 }, /* 592 */
        {PositionalParams, BalanceDontCare, 1, 1018 }, /* 593 */
        {PositionalParams, BalanceDontCare, 2, 1019 }, /* 594 */
        {PositionalParams, BalanceDontCare, 1, 1021 }, /* 595 */
        {PositionalParams, BalanceDontCare, 2, 1022 }, /* 596 */
        {PositionalParams, BalanceDontCare, 1, 1024 }, /* 597 */
        {PositionalParams, BalanceDontCare, 2, 1025 }, /* 598 */
        {PositionalParams, BalanceDontCare, 1, 1027 }, /* 599 */
        {PositionalParams, BalanceDontCare, 2, 1028 }, /* 600 */
        {PositionalParams, BalanceDontCare, 1, 1030 }, /* 601 */
        {PositionalParams, BalanceDontCare, 2, 1031 }, /* 602 */
        {PositionalParams, BalanceDontCare, 1, 1033 }, /* 603 */
        {PositionalParams, BalanceDontCare, 1, 1034 }, /* 604 */
        {AnyParams       , BalanceDontCare, 2, 1035 }, /* 605 */
        {PositionalParams, BalanceDontCare, 1, 1037 }, /* 606 */
        {PositionalParams, BalanceDontCare, 2, 1038 }, /* 607 */
        {PositionalParams, BalanceDontCare, 1, 1040 }, /* 608 */
        {PositionalParams, BalanceDontCare, 1, 1041 }, /* 609 */
        {PositionalParams, BalanceDontCare, 2, 1042 }, /* 610 */
        {PositionalParams, BalanceDontCare, 1, 1044 }, /* 611 */
        {PositionalParams, BalanceDontCare, 2, 1045 }, /* 612 */
        {PositionalParams, BalanceDontCare, 1, 1047 }, /* 613 */
        {PositionalParams, BalanceDontCare, 2, 1048 }, /* 614 */
        {PositionalParams, BalanceDontCare, 1, 1050 }, /* 615 */
        {AnyParams       , BalanceDontCare, 3, 1051 }, /* 616 */
        {PositionalParams, BalanceDontCare, 2, 1054 }, /* 617 */
        {PositionalParams, BalanceDontCare, 1, 1056 }, /* 618 */
        {PositionalParams, BalanceDontCare, 1, 1057 }, /* 619 */
        {AnyParams       , BalanceDontCare, 3, 1058 }, /* 620 */
        {PositionalParams, BalanceDontCare, 2, 1061 }, /* 621 */
        {PositionalParams, BalanceDontCare, 1, 1063 }, /* 622 */
        {PositionalParams, BalanceDontCare, 1, 1064 }, /* 623 */
        {AnyParams       , BalanceDontCare, 1, 1065 }, /* 624 */
        {PositionalParams, BalanceDontCare, 1, 1066 }, /* 625 */
        {AnyParams       , BalanceDontCare, 1, 287 }, /* 626 */
        {PositionalParams, BalanceDontCare, 1, 1067 }, /* 627 */
        {AnyParams       , BalanceDontCare, 1, 1068 }, /* 628 */
        {PositionalParams, BalanceDontCare, 1, 1069 }, /* 629 */
        {AnyParams       , BalanceDontCare, 2, 1070 }, /* 630 */
        {PositionalParams, BalanceDontCare, 1, 1072 }, /* 631 */
        {AnyParams       , BalanceDontCare, 2, 1073 }, /* 632 */
        {PositionalParams, BalanceDontCare, 1, 1075 }, /* 633 */
        {AnyParams       , BalanceDontCare, 2, 1076 }, /* 634 */
        {PositionalParams, BalanceDontCare, 1, 1078 }, /* 635 */
        {AnyParams       , BalanceDontCare, 2, 1079 }, /* 636 */
        {PositionalParams, BalanceDontCare, 1, 1081 }, /* 637 */
        {PositionalParams, BalanceDontCare, 1, 1082 }, /* 638 */
    };

    const Function flist[] =
    {
        {cNot        , 0 }, /* 0 */
        {cNotNot     , 0 }, /* 1 */
        {cAcos       , 10 }, /* 2 */
        {cAdd        , 12 }, /* 3 */
        {cAdd        , 14 }, /* 4 */
        {cSin        , 10 }, /* 5 */
        {cAdd        , 23 }, /* 6 */
        {cAdd        , 25 }, /* 7 */
        {cIf         , 26 }, /* 8 */
        {cAdd        , 27 }, /* 9 */
        {cMul        , 29 }, /* 10 */
        {cMul        , 31 }, /* 11 */
        {cIf         , 32 }, /* 12 */
        {cMul        , 33 }, /* 13 */
        {cAnd        , 35 }, /* 14 */
        {cAnd        , 25 }, /* 15 */
        {cIf         , 37 }, /* 16 */
        {cAnd        , 38 }, /* 17 */
        {cOr         , 40 }, /* 18 */
        {cOr         , 42 }, /* 19 */
        {cIf         , 43 }, /* 20 */
        {cOr         , 44 }, /* 21 */
        {cAdd        , 46 }, /* 22 */
        {cAdd        , 47 }, /* 23 */
        {cAdd        , 49 }, /* 24 */
        {cAdd        , 50 }, /* 25 */
        {cIf         , 51 }, /* 26 */
        {cAdd        , 52 }, /* 27 */
        {cMul        , 54 }, /* 28 */
        {cMul        , 55 }, /* 29 */
        {cMul        , 57 }, /* 30 */
        {cIf         , 58 }, /* 31 */
        {cMul        , 59 }, /* 32 */
        {cAnd        , 61 }, /* 33 */
        {cAnd        , 62 }, /* 34 */
        {cAnd        , 64 }, /* 35 */
        {cAnd        , 65 }, /* 36 */
        {cIf         , 66 }, /* 37 */
        {cAnd        , 67 }, /* 38 */
        {cOr         , 69 }, /* 39 */
        {cOr         , 70 }, /* 40 */
        {cOr         , 72 }, /* 41 */
        {cOr         , 73 }, /* 42 */
        {cIf         , 74 }, /* 43 */
        {cOr         , 75 }, /* 44 */
        {cNot        , 77 }, /* 45 */
        {cIf         , 79 }, /* 46 */
        {cNotNot     , 81 }, /* 47 */
        {cIf         , 83 }, /* 48 */
        {cPow        , 87 }, /* 49 */
        {cLog        , 89 }, /* 50 */
        {cMul        , 90 }, /* 51 */
        {cPow        , 92 }, /* 52 */
        {cMul        , 93 }, /* 53 */
        {cMul        , 95 }, /* 54 */
        {cLog        , 96 }, /* 55 */
        {cAdd        , 97 }, /* 56 */
        {cMax        , 101 }, /* 57 */
        {cMin        , 108 }, /* 58 */
        {cLog        , 10 }, /* 59 */
        {cLog        , 119 }, /* 60 */
        {cMul        , 120 }, /* 61 */
        {cMul        , 122 }, /* 62 */
        {cLog        , 0 }, /* 63 */
        {cMul        , 126 }, /* 64 */
        {cMul        , 128 }, /* 65 */
        {cMul        , 130 }, /* 66 */
        {cMul        , 132 }, /* 67 */
        {cMul        , 12 }, /* 68 */
        {cAdd        , 139 }, /* 69 */
        {cAdd        , 141 }, /* 70 */
        {cPow        , 142 }, /* 71 */
        {cMul        , 143 }, /* 72 */
        {cLog        , 145 }, /* 73 */
        {cMul        , 146 }, /* 74 */
        {cMul        , 148 }, /* 75 */
        {cPow        , 150 }, /* 76 */
        {cMul        , 152 }, /* 77 */
        {cAsin       , 0 }, /* 78 */
        {cAdd        , 156 }, /* 79 */
        {cSin        , 0 }, /* 80 */
        {cAdd        , 158 }, /* 81 */
        {cAdd        , 160 }, /* 82 */
        {cCos        , 10 }, /* 83 */
        {cAtan       , 10 }, /* 84 */
        {cTan        , 10 }, /* 85 */
        {cAdd        , 166 }, /* 86 */
        {cAdd        , 171 }, /* 87 */
        {cAdd        , 174 }, /* 88 */
        {cMul        , 175 }, /* 89 */
        {cAdd        , 177 }, /* 90 */
        {cMul        , 178 }, /* 91 */
        {cAdd        , 182 }, /* 92 */
        {cMul        , 185 }, /* 93 */
        {cMul        , 187 }, /* 94 */
        {cAdd        , 189 }, /* 95 */
        {cMul        , 190 }, /* 96 */
        {cMul        , 192 }, /* 97 */
        {cCos        , 119 }, /* 98 */
        {cPow        , 194 }, /* 99 */
        {cPow        , 196 }, /* 100 */
        {cSin        , 119 }, /* 101 */
        {cPow        , 198 }, /* 102 */
        {cPow        , 200 }, /* 103 */
        {cLog        , 20 }, /* 104 */
        {cMul        , 206 }, /* 105 */
        {cLog        , 207 }, /* 106 */
        {cPow        , 209 }, /* 107 */
        {cCos        , 0 }, /* 108 */
        {cPow        , 210 }, /* 109 */
        {cMul        , 212 }, /* 110 */
        {cMul        , 213 }, /* 111 */
        {cMul        , 215 }, /* 112 */
        {cMul        , 216 }, /* 113 */
        {cAdd        , 217 }, /* 114 */
        {cMul        , 218 }, /* 115 */
        {cMul        , 220 }, /* 116 */
        {cMul        , 221 }, /* 117 */
        {cMul        , 223 }, /* 118 */
        {cMul        , 224 }, /* 119 */
        {cAdd        , 225 }, /* 120 */
        {cMul        , 226 }, /* 121 */
        {cMul        , 228 }, /* 122 */
        {cMul        , 229 }, /* 123 */
        {cMul        , 231 }, /* 124 */
        {cMul        , 232 }, /* 125 */
        {cAdd        , 233 }, /* 126 */
        {cMul        , 234 }, /* 127 */
        {cMul        , 236 }, /* 128 */
        {cMul        , 237 }, /* 129 */
        {cMul        , 239 }, /* 130 */
        {cMul        , 240 }, /* 131 */
        {cAdd        , 241 }, /* 132 */
        {cMul        , 242 }, /* 133 */
        {cCos        , 20 }, /* 134 */
        {cMul        , 244 }, /* 135 */
        {cSin        , 245 }, /* 136 */
        {cMul        , 246 }, /* 137 */
        {cAdd        , 248 }, /* 138 */
        {cCos        , 249 }, /* 139 */
        {cCos        , 245 }, /* 140 */
        {cMul        , 251 }, /* 141 */
        {cSin        , 252 }, /* 142 */
        {cMul        , 253 }, /* 143 */
        {cAdd        , 255 }, /* 144 */
        {cCos        , 256 }, /* 145 */
        {cCos        , 252 }, /* 146 */
        {cMul        , 258 }, /* 147 */
        {cSin        , 20 }, /* 148 */
        {cMul        , 259 }, /* 149 */
        {cAdd        , 261 }, /* 150 */
        {cSin        , 262 }, /* 151 */
        {cMul        , 264 }, /* 152 */
        {cMul        , 265 }, /* 153 */
        {cAdd        , 267 }, /* 154 */
        {cSin        , 268 }, /* 155 */
        {cMul        , 270 }, /* 156 */
        {cMul        , 272 }, /* 157 */
        {cAdd        , 273 }, /* 158 */
        {cMul        , 274 }, /* 159 */
        {cMul        , 276 }, /* 160 */
        {cMul        , 278 }, /* 161 */
        {cAdd        , 279 }, /* 162 */
        {cMul        , 280 }, /* 163 */
        {cMul        , 282 }, /* 164 */
        {cMul        , 283 }, /* 165 */
        {cMul        , 285 }, /* 166 */
        {cMul        , 286 }, /* 167 */
        {cAdd        , 287 }, /* 168 */
        {cMul        , 288 }, /* 169 */
        {cMul        , 290 }, /* 170 */
        {cMul        , 291 }, /* 171 */
        {cMul        , 293 }, /* 172 */
        {cMul        , 294 }, /* 173 */
        {cAdd        , 295 }, /* 174 */
        {cMul        , 296 }, /* 175 */
        {cMul        , 298 }, /* 176 */
        {cAdd        , 300 }, /* 177 */
        {cCos        , 301 }, /* 178 */
        {cMul        , 303 }, /* 179 */
        {cAdd        , 305 }, /* 180 */
        {cCos        , 306 }, /* 181 */
        {cMul        , 308 }, /* 182 */
        {cMul        , 309 }, /* 183 */
        {cAdd        , 311 }, /* 184 */
        {cSin        , 312 }, /* 185 */
        {cMul        , 314 }, /* 186 */
        {cMul        , 316 }, /* 187 */
        {cAdd        , 317 }, /* 188 */
        {cMul        , 318 }, /* 189 */
        {cMul        , 320 }, /* 190 */
        {cMul        , 322 }, /* 191 */
        {cAdd        , 323 }, /* 192 */
        {cMul        , 324 }, /* 193 */
        {cMul        , 327 }, /* 194 */
        {cMul        , 330 }, /* 195 */
        {cPow        , 332 }, /* 196 */
        {cPow        , 333 }, /* 197 */
        {cMul        , 334 }, /* 198 */
        {cAdd        , 336 }, /* 199 */
        {cPow        , 337 }, /* 200 */
        {cMul        , 338 }, /* 201 */
        {cAdd        , 339 }, /* 202 */
        {cMul        , 340 }, /* 203 */
        {cAdd        , 343 }, /* 204 */
        {cTan        , 344 }, /* 205 */
        {cMul        , 348 }, /* 206 */
        {cAdd        , 349 }, /* 207 */
        {cMul        , 354 }, /* 208 */
        {cPow        , 357 }, /* 209 */
        {cPow        , 359 }, /* 210 */
        {cMul        , 171 }, /* 211 */
        {cPow        , 368 }, /* 212 */
        {cLog        , 369 }, /* 213 */
        {cPow        , 371 }, /* 214 */
        {cLog        , 372 }, /* 215 */
        {cPow        , 374 }, /* 216 */
        {cLog        , 375 }, /* 217 */
        {cPow        , 377 }, /* 218 */
        {cMul        , 378 }, /* 219 */
        {cLog        , 379 }, /* 220 */
        {cMul        , 381 }, /* 221 */
        {cAdd        , 382 }, /* 222 */
        {cPow        , 384 }, /* 223 */
        {cMul        , 385 }, /* 224 */
        {cLog        , 386 }, /* 225 */
        {cMul        , 388 }, /* 226 */
        {cAdd        , 389 }, /* 227 */
        {cPow        , 391 }, /* 228 */
        {cMul        , 392 }, /* 229 */
        {cLog        , 393 }, /* 230 */
        {cLog        , 395 }, /* 231 */
        {cMul        , 396 }, /* 232 */
        {cAdd        , 397 }, /* 233 */
        {cPow        , 399 }, /* 234 */
        {cPow        , 400 }, /* 235 */
        {cAdd        , 402 }, /* 236 */
        {cPow        , 403 }, /* 237 */
        {cPow        , 405 }, /* 238 */
        {cPow        , 406 }, /* 239 */
        {cAdd        , 408 }, /* 240 */
        {cPow        , 409 }, /* 241 */
        {cTan        , 119 }, /* 242 */
        {cSinh       , 10 }, /* 243 */
        {cCosh       , 10 }, /* 244 */
        {cTanh       , 119 }, /* 245 */
        {cPow        , 415 }, /* 246 */
        {cAdd        , 417 }, /* 247 */
        {cPow        , 418 }, /* 248 */
        {cPow        , 420 }, /* 249 */
        {cAdd        , 422 }, /* 250 */
        {cPow        , 423 }, /* 251 */
        {cPow        , 427 }, /* 252 */
        {cLog        , 428 }, /* 253 */
        {cPow        , 431 }, /* 254 */
        {cLog        , 432 }, /* 255 */
        {cPow        , 435 }, /* 256 */
        {cPow        , 436 }, /* 257 */
        {cAdd        , 438 }, /* 258 */
        {cPow        , 439 }, /* 259 */
        {cTan        , 0 }, /* 260 */
        {cSinh       , 119 }, /* 261 */
        {cCosh       , 119 }, /* 262 */
        {cTanh       , 0 }, /* 263 */
        {cPow        , 445 }, /* 264 */
        {cAdd        , 447 }, /* 265 */
        {cPow        , 448 }, /* 266 */
        {cPow        , 450 }, /* 267 */
        {cAdd        , 452 }, /* 268 */
        {cPow        , 453 }, /* 269 */
        {cPow        , 456 }, /* 270 */
        {cPow        , 459 }, /* 271 */
        {cEqual      , 469 }, /* 272 */
        {cNEqual     , 471 }, /* 273 */
        {cNEqual     , 473 }, /* 274 */
        {cEqual      , 475 }, /* 275 */
        {cLess       , 477 }, /* 276 */
        {cGreaterOrEq, 479 }, /* 277 */
        {cLessOrEq   , 481 }, /* 278 */
        {cGreater    , 483 }, /* 279 */
        {cGreater    , 485 }, /* 280 */
        {cLessOrEq   , 487 }, /* 281 */
        {cGreaterOrEq, 489 }, /* 282 */
        {cLess       , 491 }, /* 283 */
        {cOr         , 494 }, /* 284 */
        {cNotNot     , 10 }, /* 285 */
        {cAnd        , 499 }, /* 286 */
        {cEqual      , 502 }, /* 287 */
        {cNEqual     , 504 }, /* 288 */
        {cNEqual     , 506 }, /* 289 */
        {cEqual      , 508 }, /* 290 */
        {cLess       , 510 }, /* 291 */
        {cGreaterOrEq, 512 }, /* 292 */
        {cLessOrEq   , 514 }, /* 293 */
        {cGreater    , 516 }, /* 294 */
        {cGreater    , 518 }, /* 295 */
        {cLessOrEq   , 520 }, /* 296 */
        {cGreaterOrEq, 522 }, /* 297 */
        {cLess       , 524 }, /* 298 */
        {cAnd        , 527 }, /* 299 */
        {cNotNot     , 119 }, /* 300 */
        {cEqual      , 532 }, /* 301 */
        {cNEqual     , 533 }, /* 302 */
        {cEqual      , 536 }, /* 303 */
        {cEqual      , 537 }, /* 304 */
        {cEqual      , 538 }, /* 305 */
        {cEqual      , 471 }, /* 306 */
        {cEqual      , 540 }, /* 307 */
        {cAnd        , 542 }, /* 308 */
        {cNot        , 10 }, /* 309 */
        {cOr         , 545 }, /* 310 */
        {cEqual      , 547 }, /* 311 */
        {cNEqual     , 549 }, /* 312 */
        {cNEqual     , 551 }, /* 313 */
        {cEqual      , 553 }, /* 314 */
        {cLess       , 555 }, /* 315 */
        {cGreaterOrEq, 557 }, /* 316 */
        {cLessOrEq   , 559 }, /* 317 */
        {cGreater    , 561 }, /* 318 */
        {cGreater    , 563 }, /* 319 */
        {cLessOrEq   , 565 }, /* 320 */
        {cGreaterOrEq, 567 }, /* 321 */
        {cLess       , 569 }, /* 322 */
        {cOr         , 572 }, /* 323 */
        {cEqual      , 577 }, /* 324 */
        {cNEqual     , 578 }, /* 325 */
        {cEqual      , 581 }, /* 326 */
        {cNEqual     , 584 }, /* 327 */
        {cNEqual     , 586 }, /* 328 */
        {cLess       , 588 }, /* 329 */
        {cLess       , 590 }, /* 330 */
        {cLessOrEq   , 592 }, /* 331 */
        {cLessOrEq   , 594 }, /* 332 */
        {cGreater    , 596 }, /* 333 */
        {cGreater    , 598 }, /* 334 */
        {cGreaterOrEq, 600 }, /* 335 */
        {cGreaterOrEq, 602 }, /* 336 */
        {cNot        , 496 }, /* 337 */
        {cAnd        , 605 }, /* 338 */
        {cAnd        , 607 }, /* 339 */
        {cOr         , 171 }, /* 340 */
        {cOr         , 610 }, /* 341 */
        {cExp        , 10 }, /* 342 */
        {cSqrt       , 10 }, /* 343 */
        {cMul        , 617 }, /* 344 */
        {cRad        , 618 }, /* 345 */
        {cMul        , 621 }, /* 346 */
        {cDeg        , 622 }, /* 347 */
        {cSec        , 10 }, /* 348 */
        {cCsc        , 0 }, /* 349 */
        {cCot        , 10 }, /* 350 */
        {cLog10      , 10 }, /* 351 */
        {cLog2       , 10 }, /* 352 */
        {cNot        , 1 }, /* 353 */
    };

    const Rule rlist[] =
    {
        {1, ProduceNewTree,    2,	{ cNot        , 1 } }, /* 0 */
        {1, ProduceNewTree,    4,	{ cAcos       , 3 } }, /* 1 */
        {1, ProduceNewTree,    6,	{ cAsin       , 5 } }, /* 2 */
        {1, ProduceNewTree,    7,	{ cAtan       , 5 } }, /* 3 */
        {1, ProduceNewTree,    8,	{ cCeil       , 5 } }, /* 4 */
        {1, ProduceNewTree,    9,	{ cCos        , 5 } }, /* 5 */
        {1, ProduceNewTree,    10,	{ cCos        , 11 } }, /* 6 */
        {1, ReplaceParams ,    10,	{ cCos        , 13 } }, /* 7 */
        {1, ProduceNewTree,    16,	{ cCos        , 15 } }, /* 8 */
        {1, ProduceNewTree,    17,	{ cCosh       , 5 } }, /* 9 */
        {1, ProduceNewTree,    18,	{ cFloor      , 5 } }, /* 10 */
        {3, ProduceNewTree,    20,	{ cIf         , 19 } }, /* 11 */
        {3, ProduceNewTree,    0,	{ cIf         , 21 } }, /* 12 */
        {3, ProduceNewTree,    0,	{ cIf         , 22 } }, /* 13 */
        {3, ProduceNewTree,    28,	{ cIf         , 24 } }, /* 14 */
        {3, ProduceNewTree,    34,	{ cIf         , 30 } }, /* 15 */
        {3, ProduceNewTree,    39,	{ cIf         , 36 } }, /* 16 */
        {3, ProduceNewTree,    45,	{ cIf         , 41 } }, /* 17 */
        {3, ProduceNewTree,    53,	{ cIf         , 48 } }, /* 18 */
        {3, ProduceNewTree,    60,	{ cIf         , 56 } }, /* 19 */
        {3, ProduceNewTree,    68,	{ cIf         , 63 } }, /* 20 */
        {3, ProduceNewTree,    76,	{ cIf         , 71 } }, /* 21 */
        {3, ProduceNewTree,    80,	{ cIf         , 78 } }, /* 22 */
        {3, ProduceNewTree,    84,	{ cIf         , 82 } }, /* 23 */
        {1, ProduceNewTree,    86,	{ cLog        , 85 } }, /* 24 */
        {1, ProduceNewTree,    91,	{ cLog        , 88 } }, /* 25 */
        {1, ProduceNewTree,    98,	{ cLog        , 94 } }, /* 26 */
        {0, ProduceNewTree,    100,	{ cMax        , 99 } }, /* 27 */
        {1, ProduceNewTree,    10,	{ cMax        , 10 } }, /* 28 */
        {1, ReplaceParams ,    103,	{ cMax        , 102 } }, /* 29 */
        {2, ReplaceParams ,    105,	{ cMax        , 104 } }, /* 30 */
        {2, ReplaceParams ,    10,	{ cMax        , 106 } }, /* 31 */
        {0, ProduceNewTree,    107,	{ cMin        , 99 } }, /* 32 */
        {1, ProduceNewTree,    0,	{ cMin        , 0 } }, /* 33 */
        {1, ReplaceParams ,    110,	{ cMin        , 109 } }, /* 34 */
        {2, ReplaceParams ,    112,	{ cMin        , 111 } }, /* 35 */
        {2, ReplaceParams ,    0,	{ cMin        , 113 } }, /* 36 */
        {2, ProduceNewTree,    115,	{ cPow        , 114 } }, /* 37 */
        {2, ProduceNewTree,    117,	{ cPow        , 116 } }, /* 38 */
        {2, ProduceNewTree,    119,	{ cPow        , 118 } }, /* 39 */
        {2, ReplaceParams ,    123,	{ cPow        , 121 } }, /* 40 */
        {2, ProduceNewTree,    125,	{ cPow        , 124 } }, /* 41 */
        {2, ReplaceParams ,    129,	{ cPow        , 127 } }, /* 42 */
        {2, ReplaceParams ,    133,	{ cPow        , 131 } }, /* 43 */
        {2, ProduceNewTree,    135,	{ cPow        , 134 } }, /* 44 */
        {2, ProduceNewTree,    137,	{ cPow        , 136 } }, /* 45 */
        {2, ProduceNewTree,    10,	{ cPow        , 138 } }, /* 46 */
        {2, ProduceNewTree,    144,	{ cPow        , 140 } }, /* 47 */
        {2, ReplaceParams ,    149,	{ cPow        , 147 } }, /* 48 */
        {2, ReplaceParams ,    153,	{ cPow        , 151 } }, /* 49 */
        {1, ProduceNewTree,    154,	{ cSin        , 5 } }, /* 50 */
        {1, ProduceNewTree,    119,	{ cSin        , 155 } }, /* 51 */
        {1, ProduceNewTree,    159,	{ cSin        , 157 } }, /* 52 */
        {1, ProduceNewTree,    162,	{ cSin        , 161 } }, /* 53 */
        {1, ProduceNewTree,    163,	{ cSinh       , 3 } }, /* 54 */
        {1, ProduceNewTree,    164,	{ cTan        , 5 } }, /* 55 */
        {1, ProduceNewTree,    10,	{ cTan        , 165 } }, /* 56 */
        {1, ProduceNewTree,    167,	{ cTan        , 13 } }, /* 57 */
        {1, ProduceNewTree,    169,	{ cTanh       , 168 } }, /* 58 */
        {0, ProduceNewTree,    115,	{ cAdd        , 99 } }, /* 59 */
        {1, ProduceNewTree,    10,	{ cAdd        , 10 } }, /* 60 */
        {1, ReplaceParams ,    99,	{ cAdd        , 170 } }, /* 61 */
        {1, ReplaceParams ,    173,	{ cAdd        , 172 } }, /* 62 */
        {1, ReplaceParams ,    179,	{ cAdd        , 176 } }, /* 63 */
        {1, ReplaceParams ,    181,	{ cAdd        , 180 } }, /* 64 */
        {1, ReplaceParams ,    184,	{ cAdd        , 183 } }, /* 65 */
        {1, ReplaceParams ,    188,	{ cAdd        , 186 } }, /* 66 */
        {1, ReplaceParams ,    193,	{ cAdd        , 191 } }, /* 67 */
        {2, ReplaceParams ,    197,	{ cAdd        , 195 } }, /* 68 */
        {2, ReplaceParams ,    201,	{ cAdd        , 199 } }, /* 69 */
        {2, ReplaceParams ,    203,	{ cAdd        , 202 } }, /* 70 */
        {2, ReplaceParams ,    99,	{ cAdd        , 204 } }, /* 71 */
        {2, ReplaceParams ,    208,	{ cAdd        , 205 } }, /* 72 */
        {2, ReplaceParams ,    137,	{ cAdd        , 211 } }, /* 73 */
        {2, ReplaceParams ,    219,	{ cAdd        , 214 } }, /* 74 */
        {2, ReplaceParams ,    227,	{ cAdd        , 222 } }, /* 75 */
        {2, ReplaceParams ,    235,	{ cAdd        , 230 } }, /* 76 */
        {2, ReplaceParams ,    243,	{ cAdd        , 238 } }, /* 77 */
        {2, ReplaceParams ,    250,	{ cAdd        , 247 } }, /* 78 */
        {2, ReplaceParams ,    257,	{ cAdd        , 254 } }, /* 79 */
        {2, ReplaceParams ,    263,	{ cAdd        , 260 } }, /* 80 */
        {2, ReplaceParams ,    269,	{ cAdd        , 266 } }, /* 81 */
        {2, ReplaceParams ,    275,	{ cAdd        , 271 } }, /* 82 */
        {2, ReplaceParams ,    281,	{ cAdd        , 277 } }, /* 83 */
        {2, ReplaceParams ,    289,	{ cAdd        , 284 } }, /* 84 */
        {2, ReplaceParams ,    297,	{ cAdd        , 292 } }, /* 85 */
        {2, ReplaceParams ,    302,	{ cAdd        , 299 } }, /* 86 */
        {2, ReplaceParams ,    307,	{ cAdd        , 304 } }, /* 87 */
        {2, ReplaceParams ,    313,	{ cAdd        , 310 } }, /* 88 */
        {2, ReplaceParams ,    319,	{ cAdd        , 315 } }, /* 89 */
        {2, ReplaceParams ,    325,	{ cAdd        , 321 } }, /* 90 */
        {2, ReplaceParams ,    328,	{ cAdd        , 326 } }, /* 91 */
        {2, ReplaceParams ,    331,	{ cAdd        , 329 } }, /* 92 */
        {3, ReplaceParams ,    341,	{ cAdd        , 335 } }, /* 93 */
        {0, ProduceNewTree,    342,	{ cMul        , 99 } }, /* 94 */
        {1, ProduceNewTree,    10,	{ cMul        , 10 } }, /* 95 */
        {1, ProduceNewTree,    346,	{ cMul        , 345 } }, /* 96 */
        {1, ProduceNewTree,    350,	{ cMul        , 347 } }, /* 97 */
        {1, ProduceNewTree,    352,	{ cMul        , 351 } }, /* 98 */
        {1, ReplaceParams ,    99,	{ cMul        , 353 } }, /* 99 */
        {1, ReplaceParams ,    356,	{ cMul        , 355 } }, /* 100 */
        {1, ReplaceParams ,    360,	{ cMul        , 358 } }, /* 101 */
        {1, ReplaceParams ,    362,	{ cMul        , 361 } }, /* 102 */
        {2, ReplaceParams ,    364,	{ cMul        , 363 } }, /* 103 */
        {2, ReplaceParams ,    366,	{ cMul        , 365 } }, /* 104 */
        {2, ReplaceParams ,    99,	{ cMul        , 367 } }, /* 105 */
        {2, ReplaceParams ,    245,	{ cMul        , 370 } }, /* 106 */
        {2, ReplaceParams ,    252,	{ cMul        , 373 } }, /* 107 */
        {2, ReplaceParams ,    20,	{ cMul        , 376 } }, /* 108 */
        {2, ProduceNewTree,    383,	{ cMul        , 380 } }, /* 109 */
        {2, ProduceNewTree,    390,	{ cMul        , 387 } }, /* 110 */
        {2, ProduceNewTree,    398,	{ cMul        , 394 } }, /* 111 */
        {2, ReplaceParams ,    404,	{ cMul        , 401 } }, /* 112 */
        {2, ReplaceParams ,    410,	{ cMul        , 407 } }, /* 113 */
        {2, ReplaceParams ,    412,	{ cMul        , 411 } }, /* 114 */
        {2, ReplaceParams ,    414,	{ cMul        , 413 } }, /* 115 */
        {2, ReplaceParams ,    419,	{ cMul        , 416 } }, /* 116 */
        {2, ReplaceParams ,    424,	{ cMul        , 421 } }, /* 117 */
        {2, ReplaceParams ,    426,	{ cMul        , 425 } }, /* 118 */
        {2, ReplaceParams ,    430,	{ cMul        , 429 } }, /* 119 */
        {2, ReplaceParams ,    434,	{ cMul        , 433 } }, /* 120 */
        {2, ReplaceParams ,    440,	{ cMul        , 437 } }, /* 121 */
        {2, ReplaceParams ,    442,	{ cMul        , 441 } }, /* 122 */
        {2, ReplaceParams ,    444,	{ cMul        , 443 } }, /* 123 */
        {2, ReplaceParams ,    449,	{ cMul        , 446 } }, /* 124 */
        {2, ReplaceParams ,    454,	{ cMul        , 451 } }, /* 125 */
        {2, ReplaceParams ,    457,	{ cMul        , 455 } }, /* 126 */
        {2, ReplaceParams ,    460,	{ cMul        , 458 } }, /* 127 */
        {2, ProduceNewTree,    462,	{ cMod        , 461 } }, /* 128 */
        {2, ProduceNewTree,    117,	{ cEqual      , 463 } }, /* 129 */
        {2, ProduceNewTree,    115,	{ cNEqual     , 464 } }, /* 130 */
        {2, ProduceNewTree,    352,	{ cLess       , 465 } }, /* 131 */
        {2, ProduceNewTree,    137,	{ cLessOrEq   , 466 } }, /* 132 */
        {2, ProduceNewTree,    115,	{ cGreater    , 467 } }, /* 133 */
        {2, ProduceNewTree,    117,	{ cGreaterOrEq, 468 } }, /* 134 */
        {1, ProduceNewTree,    472,	{ cNot        , 470 } }, /* 135 */
        {1, ProduceNewTree,    476,	{ cNot        , 474 } }, /* 136 */
        {1, ProduceNewTree,    480,	{ cNot        , 478 } }, /* 137 */
        {1, ProduceNewTree,    484,	{ cNot        , 482 } }, /* 138 */
        {1, ProduceNewTree,    488,	{ cNot        , 486 } }, /* 139 */
        {1, ProduceNewTree,    492,	{ cNot        , 490 } }, /* 140 */
        {0, ProduceNewTree,    115,	{ cAnd        , 99 } }, /* 141 */
        {0, ReplaceParams ,    495,	{ cAnd        , 493 } }, /* 142 */
        {1, ProduceNewTree,    496,	{ cAnd        , 10 } }, /* 143 */
        {1, ProduceNewTree,    1,	{ cAnd        , 497 } }, /* 144 */
        {1, ReplaceParams ,    497,	{ cAnd        , 498 } }, /* 145 */
        {1, ReplaceParams ,    25,	{ cAnd        , 500 } }, /* 146 */
        {1, ReplaceParams ,    0,	{ cAnd        , 501 } }, /* 147 */
        {1, ReplaceParams ,    505,	{ cAnd        , 503 } }, /* 148 */
        {1, ReplaceParams ,    509,	{ cAnd        , 507 } }, /* 149 */
        {1, ReplaceParams ,    513,	{ cAnd        , 511 } }, /* 150 */
        {1, ReplaceParams ,    517,	{ cAnd        , 515 } }, /* 151 */
        {1, ReplaceParams ,    521,	{ cAnd        , 519 } }, /* 152 */
        {1, ReplaceParams ,    525,	{ cAnd        , 523 } }, /* 153 */
        {1, ReplaceParams ,    119,	{ cAnd        , 526 } }, /* 154 */
        {1, ReplaceParams ,    141,	{ cAnd        , 528 } }, /* 155 */
        {1, ReplaceParams ,    156,	{ cAnd        , 529 } }, /* 156 */
        {2, ReplaceParams ,    0,	{ cAnd        , 530 } }, /* 157 */
        {2, ProduceNewTree,    115,	{ cAnd        , 531 } }, /* 158 */
        {2, ProduceNewTree,    115,	{ cAnd        , 534 } }, /* 159 */
        {2, ReplaceParams ,    156,	{ cAnd        , 535 } }, /* 160 */
        {3, ReplaceParams ,    541,	{ cAnd        , 539 } }, /* 161 */
        {0, ProduceNewTree,    342,	{ cOr         , 99 } }, /* 162 */
        {0, ReplaceParams ,    543,	{ cOr         , 139 } }, /* 163 */
        {1, ProduceNewTree,    496,	{ cOr         , 10 } }, /* 164 */
        {1, ProduceNewTree,    544,	{ cOr         , 12 } }, /* 165 */
        {1, ReplaceParams ,    497,	{ cOr         , 498 } }, /* 166 */
        {1, ReplaceParams ,    25,	{ cOr         , 546 } }, /* 167 */
        {1, ReplaceParams ,    0,	{ cOr         , 501 } }, /* 168 */
        {1, ReplaceParams ,    550,	{ cOr         , 548 } }, /* 169 */
        {1, ReplaceParams ,    554,	{ cOr         , 552 } }, /* 170 */
        {1, ReplaceParams ,    558,	{ cOr         , 556 } }, /* 171 */
        {1, ReplaceParams ,    562,	{ cOr         , 560 } }, /* 172 */
        {1, ReplaceParams ,    566,	{ cOr         , 564 } }, /* 173 */
        {1, ReplaceParams ,    570,	{ cOr         , 568 } }, /* 174 */
        {1, ReplaceParams ,    0,	{ cOr         , 571 } }, /* 175 */
        {1, ReplaceParams ,    184,	{ cOr         , 573 } }, /* 176 */
        {1, ReplaceParams ,    497,	{ cOr         , 574 } }, /* 177 */
        {2, ReplaceParams ,    10,	{ cOr         , 575 } }, /* 178 */
        {2, ProduceNewTree,    117,	{ cOr         , 576 } }, /* 179 */
        {2, ProduceNewTree,    342,	{ cOr         , 579 } }, /* 180 */
        {2, ReplaceParams ,    156,	{ cOr         , 580 } }, /* 181 */
        {1, ProduceNewTree,    583,	{ cNotNot     , 582 } }, /* 182 */
        {1, ProduceNewTree,    587,	{ cNotNot     , 585 } }, /* 183 */
        {1, ProduceNewTree,    591,	{ cNotNot     , 589 } }, /* 184 */
        {1, ProduceNewTree,    595,	{ cNotNot     , 593 } }, /* 185 */
        {1, ProduceNewTree,    599,	{ cNotNot     , 597 } }, /* 186 */
        {1, ProduceNewTree,    603,	{ cNotNot     , 601 } }, /* 187 */
        {1, ProduceNewTree,    604,	{ cNotNot     , 544 } }, /* 188 */
        {1, ProduceNewTree,    608,	{ cNotNot     , 606 } }, /* 189 */
        {1, ProduceNewTree,    611,	{ cNotNot     , 609 } }, /* 190 */
        {1, ReplaceParams ,    0,	{ cNotNot     , 2 } }, /* 191 */
        {2, ProduceNewTree,    613,	{ cPow        , 612 } }, /* 192 */
        {2, ProduceNewTree,    615,	{ cPow        , 614 } }, /* 193 */
        {1, ProduceNewTree,    619,	{ cMul        , 616 } }, /* 194 */
        {1, ProduceNewTree,    623,	{ cMul        , 620 } }, /* 195 */
        {1, ReplaceParams ,    625,	{ cMul        , 624 } }, /* 196 */
        {1, ReplaceParams ,    627,	{ cMul        , 626 } }, /* 197 */
        {1, ReplaceParams ,    629,	{ cMul        , 628 } }, /* 198 */
        {2, ReplaceParams ,    631,	{ cMul        , 630 } }, /* 199 */
        {2, ReplaceParams ,    633,	{ cMul        , 632 } }, /* 200 */
        {2, ReplaceParams ,    635,	{ cMul        , 634 } }, /* 201 */
        {2, ReplaceParams ,    637,	{ cMul        , 636 } }, /* 202 */
        {1, ProduceNewTree,    638,	{ cNotNot     , 0 } }, /* 203 */
    };
}

namespace FPoptimizer_Grammar
{
    const GrammarPack pack =
    {
        clist, plist, mlist, flist, rlist,
        {
            {0, 1 }, /* 0 */
            {1, 191 }, /* 1 */
            {192, 12 }, /* 2 */
        }
    };
}

#include <algorithm>
#include <cmath>
#include <map>
#include <assert.h>

#include "fpconfig.hh"
#include "fparser.hh"
#include "fptypes.hh"
using namespace FUNCTIONPARSERTYPES;

//#define DEBUG_SUBSTITUTIONS

namespace FPoptimizer_CodeTree
{
    void CodeTree::ConstantFolding()
    {
        // Insert here any hardcoded constant-folding optimizations
        // that you want to be done at bytecode->codetree conversion time.
    }
}

namespace FPoptimizer_Grammar
{
    /* A helper for std::equal_range */
    struct OpcodeRuleCompare
    {
        bool operator() (const FPoptimizer_CodeTree::CodeTree& tree, const Rule& rule) const
        {
            /* If this function returns true, len=half.
             */

            if(tree.Opcode != rule.func.opcode)
                return tree.Opcode < rule.func.opcode;

            if(tree.Params.size() < rule.n_minimum_params)
            {
                // Tree has fewer params than required?
                return true; // Failure
            }
            return false;
        }
        bool operator() (const Rule& rule, const FPoptimizer_CodeTree::CodeTree& tree) const
        {
            /* If this function returns true, rule will be excluded from the equal_range
             */

            if(rule.func.opcode != tree.Opcode)
                return rule.func.opcode < tree.Opcode;

            if(rule.n_minimum_params < tree.Params.size())
            {
                // Tree has more params than the pattern has?
                switch(pack.mlist[rule.func.index].type)
                {
                    case PositionalParams:
                    case SelectedParams:
                        return true; // Failure
                    case AnyParams:
                        return false; // Not a failure
                }
            }
            return false;
        }
    };

#ifdef DEBUG_SUBSTITUTIONS
    void DumpTree(const FPoptimizer_CodeTree::CodeTree& tree);
    static const char ImmedHolderNames[2][2] = {"%","&"};
    static const char NamedHolderNames[6][2] = {"x","y","z","a","b","c"};
#endif

    /* Apply the grammar to a given CodeTree */
    bool Grammar::ApplyTo(
        FPoptimizer_CodeTree::CodeTree& tree,
        bool recursion) const
    {
        bool changed = false;

#ifdef DEBUG_SUBSTITUTIONS
        if(!recursion)
        {
            std::cout << "Input:  ";
            DumpTree(tree);
            std::cout << "\n";
        }
#endif
        if(tree.OptimizedUsing != this)
        {
            /* First optimize all children */
            for(size_t a=0; a<tree.Params.size(); ++a)
            {
                if( ApplyTo( *tree.Params[a].param, true ) )
                {
                    changed = true;
                }
            }

            /* Figure out which rules _may_ match this tree */
            typedef const Rule* ruleit;

            std::pair<ruleit, ruleit> range
                = std::equal_range(pack.rlist + index,
                                   pack.rlist + index + count,
                                   tree,
                                   OpcodeRuleCompare());

            while(range.first < range.second)
            {
                /* Check if this rule matches */
                if(range.first->ApplyTo(tree))
                {
                    changed = true;
                    break;
                }
                ++range.first;
            }

            if(!changed)
            {
                tree.OptimizedUsing = this;
            }
        }

#ifdef DEBUG_SUBSTITUTIONS
        if(!recursion)
        {
            std::cout << "Output: ";
            DumpTree(tree);
            std::cout << "\n";
        }
#endif
        return changed;
    }

    /* Store information about a potential match,
     * in order to iterate through candidates
     */
    struct MatchedParams::CodeTreeMatch
    {
        // Which parameters were matched -- these will be replaced if AnyParams are used
        std::vector<size_t> param_numbers;

        // Which values were saved for ImmedHolders?
        std::map<unsigned, double> ImmedMap;
        // Which codetrees were saved for each NameHolder? And how many?
        std::map<unsigned, std::pair<uint_fast64_t, size_t> > NamedMap;
        // Which codetrees were saved for each RestHolder?
        std::map<unsigned,
          std::vector<uint_fast64_t> > RestMap;

        // Examples of each codetree
        std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP> trees;

        CodeTreeMatch() : param_numbers(), ImmedMap(), NamedMap(), RestMap() { }
    };

#ifdef DEBUG_SUBSTITUTIONS
    void DumpMatch(const Function& input,
                   const FPoptimizer_CodeTree::CodeTree& tree,
                   const MatchedParams& replacement,
                   const MatchedParams::CodeTreeMatch& matchrec,
                   bool DidMatch=true);
    void DumpFunction(const Function& input);
    void DumpParam(const ParamSpec& p);
    void DumpParams(const MatchedParams& mitem);
#endif

    /* Apply the rule to a given CodeTree */
    bool Rule::ApplyTo(
        FPoptimizer_CodeTree::CodeTree& tree) const
    {
        const Function&      input  = func;
        const MatchedParams& repl   = pack.mlist[repl_index];

        MatchedParams::CodeTreeMatch matchrec;
        if(input.opcode == tree.Opcode
        && pack.mlist[input.index].Match(tree, matchrec, false))
        {
#ifdef DEBUG_SUBSTITUTIONS
            DumpMatch(input, tree, repl, matchrec);
#endif

            const MatchedParams& params = pack.mlist[input.index];
            switch(type)
            {
                case ReplaceParams:
                    repl.ReplaceParams(tree, params, matchrec);
#ifdef DEBUG_SUBSTITUTIONS
                    std::cout << "  ParmReplace: ";
                    DumpTree(tree);
                    std::cout << "\n";
#endif
                    return true;
                case ProduceNewTree:
                    repl.ReplaceTree(tree,   params, matchrec);
#ifdef DEBUG_SUBSTITUTIONS
                    std::cout << "  TreeReplace: ";
                    DumpTree(tree);
                    std::cout << "\n";
#endif
                    return true;
            }
        }
        else
        {
            //DumpMatch(input, tree, repl, matchrec, false);
        }
        return false;
    }


    /* Match the given function to the given CodeTree.
     */
    bool Function::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match) const
    {
        return opcode == tree.Opcode
            && pack.mlist[index].Match(tree, match);
    }


    /* This struct is used by MatchedParams::Match() for backtracking. */
    struct ParamMatchSnapshot
    {
        MatchedParams::CodeTreeMatch snapshot;
                                    // Snapshot of the state so far
        size_t            parampos; // Which position was last chosen?
        std::vector<bool> used;     // Which params were allocated?
    };

    /* Match the given list of ParamSpecs using the given ParamMatchingType
     * to the given CodeTree.
     * The CodeTree is already assumed to be a function type
     * -- i.e. it is assumed that the caller has tested the Opcode of the tree.
     */
    bool MatchedParams::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match,
        bool recursion) const
    {
        /* FIXME: This algorithm still does not cover the possibility
         *        that the ParamSpec needs backtracking.
         *
         *        For example,
         *          cMul (cAdd x) (cAdd x)
         *        Applied to:
         *          (a+b)*(c+b)
         *
         *        Match (cAdd x) to (a+b) may first capture "a" into "x",
         *        and then Match(cAdd x) for (c+b) will fail,
         *        because there's no "a" there.
         */


        /* First, check if the tree has any chances of matching... */
        /* Figure out what we need. */
        struct Needs
        {
            struct Needs_Pol
            {
                int SubTrees;
                int Others;
                unsigned SubTreesDetail[VarBegin];

                Needs_Pol(): SubTrees(0), Others(0), SubTreesDetail()
                {
                }
            } polarity[2]; // 0=positive, 1=negative
            int Immeds;

            Needs(): polarity(), Immeds() { }
        } NeedList;

        // Figure out what we need
        size_t minimum_need = 0;
        for(unsigned a=0; a<count; ++a)
        {
            const ParamSpec& param = pack.plist[index+a];
            Needs::Needs_Pol& needs = NeedList.polarity[param.sign];
            switch(param.opcode)
            {
                case SubFunction:
                    needs.SubTrees += 1;
                    assert( pack.flist[param.index].opcode < VarBegin );
                    needs.SubTreesDetail[ pack.flist[param.index].opcode ] += 1;
                    ++minimum_need;
                    break;
                case NumConstant:
                case ImmedHolder:
                default: // GroupFunction:
                    NeedList.Immeds += 1;
                    ++minimum_need;
                    break;
                case NamedHolder:
                    needs.Others += param.minrepeat;
                    ++minimum_need;
                    break;
                case RestHolder:
                    break;
            }
        }
        if(tree.Params.size() < minimum_need) return false;

        // Figure out what we have (note: we already assume that the opcode of the tree matches!)
        for(size_t a=0; a<tree.Params.size(); ++a)
        {
            Needs::Needs_Pol& needs = NeedList.polarity[tree.Params[a].sign];
            unsigned opcode = tree.Params[a].param->Opcode;
            switch(opcode)
            {
                case cImmed:
                    if(NeedList.Immeds > 0) NeedList.Immeds -= 1;
                    else needs.Others -= 1;
                    break;
                case cVar:
                case cFCall:
                case cPCall:
                    needs.Others -= 1;
                    break;
                default:
                    assert( opcode < VarBegin );
                    if(needs.SubTrees > 0
                    && needs.SubTreesDetail[opcode] > 0)
                    {
                        needs.SubTrees -= 1;
                        needs.SubTreesDetail[opcode] -= 1;
                    }
                    else needs.Others -= 1;
            }
        }

        // Check whether all needs were satisfied
        if(NeedList.Immeds > 0
        || NeedList.polarity[0].SubTrees > 0
        || NeedList.polarity[0].Others > 0
        || NeedList.polarity[1].SubTrees > 0
        || NeedList.polarity[1].Others > 0)
        {
            // Something came short.
            return false;
        }

        if(type != AnyParams)
        {
            if(NeedList.Immeds < 0
            || NeedList.polarity[0].SubTrees < 0
            || NeedList.polarity[0].Others < 0
            || NeedList.polarity[1].SubTrees < 0
            || NeedList.polarity[1].Others < 0
            || count != tree.Params.size())
            {
                // Something was too much.
                return false;
            }
        }

        TransformationType transf = None;
        switch(tree.Opcode)
        {
            case cAdd: transf = Negate; break;
            case cMul: transf = Invert; break;
            case cAnd:
            case cOr:  transf = NotThe; break;
        }

        switch(type)
        {
            case PositionalParams:
            {
                /*DumpTree(tree);
                std::cout << "<->";
                DumpParams(*this);
                std::cout << " -- ";*/
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(!param.Match(*tree.Params[a].param, match, tree.Params[a].sign ? transf : None))
                    {
                        /*std::cout << " drats at " << a << "!\n";*/
                        return false;
                    }
                    if(!recursion)
                        match.param_numbers.push_back(a);
                }
                /*std::cout << " yay?\n";*/
                // Match = no mismatch.
                return true;
            }
            case AnyParams:
            case SelectedParams:
            {
                const size_t n_tree_params = tree.Params.size();

                bool HasRestHolders = false;
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(param.opcode == RestHolder) { HasRestHolders = true; break; }
                }

                #ifdef DEBUG_SUBSTITUTIONS
                if((type == AnyParams) && recursion && !HasRestHolders)
                {
                    std::cout << "Recursed AnyParams with no RestHolders?\n";
                    DumpParams(*this);
                }
                #endif

                if(!HasRestHolders && recursion && count != n_tree_params)
                {
                    /*DumpTree(tree);
                    std::cout << "<->";
                    DumpParams(*this);
                    std::cout << " -- fail due to recursion&&count!=n_tree_params";*/
                    return false;
                }

                std::vector<ParamMatchSnapshot> position(count);
                std::vector<bool>               used(count);

                for(unsigned a=0; a<count; ++a)
                {
                    position[a].snapshot  = match;
                    position[a].parampos  = 0;
                    position[a].used      = used;

                    size_t b = 0;
                backtrack:
                    const ParamSpec& param = pack.plist[index+a];

                    if(param.opcode == RestHolder)
                    {
                        // RestHolders always match. They're filled afterwards.
                        continue;
                    }

                    for(; b<n_tree_params; ++b)
                    {
                        if(!used[b])
                        {
                            /*std::cout << "Maybe [" << a << "]:";
                            DumpParam(param);
                            std::cout << " <-> ";
                            if(tree.Params[b].sign) std::cout << '~';
                            DumpTree(*tree.Params[b].param);
                            std::cout << "...?\n";*/

                            if(param.Match(*tree.Params[b].param, match, tree.Params[b].sign ? transf : None))
                            {
                                /*std::cout << "woo... " << a << ", " << b << "\n";*/
                                /* NamedHolders require a special treatment,
                                 * because a repetition count may be issued
                                 * for them.
                                 */
                                if(param.opcode == NamedHolder)
                                {
                                    // Verify the MinRepeat & AnyRepeat case
                                    unsigned MinRepeat = param.minrepeat;
                                    bool AnyRepeat     = param.anyrepeat;
                                    unsigned HadRepeat = 1;

                                    for(size_t c = b+1;
                                        c < n_tree_params && (HadRepeat < MinRepeat || AnyRepeat);
                                        ++c)
                                    {
                                        if(tree.Params[c].param->Hash == tree.Params[b].param->Hash
                                        && tree.Params[c].sign == tree.Params[b].sign)
                                        {
                                            ++HadRepeat;
                                        }
                                    }
                                    if(HadRepeat < MinRepeat)
                                        continue; // No sufficient repeat count here

                                    used[b] = true;
                                    if(!recursion) match.param_numbers.push_back(b);

                                    HadRepeat = 1;
                                    for(size_t c = b+1;
                                        c < n_tree_params && (HadRepeat < MinRepeat || AnyRepeat);
                                        ++c)
                                    {
                                        if(tree.Params[c].param->Hash == tree.Params[b].param->Hash
                                        && tree.Params[c].sign == tree.Params[b].sign)
                                        {
                                            ++HadRepeat;
                                            used[c] = true;
                                            if(!recursion) match.param_numbers.push_back(c);
                                        }
                                    }
                                    if(AnyRepeat)
                                        match.NamedMap[param.index].second = HadRepeat;
                                    position[a].parampos = b+1;
                                    goto ok;
                                }

                                used[b] = true;
                                if(!recursion) match.param_numbers.push_back(b);
                                position[a].parampos = b+1;
                                goto ok;
                            }
                        }
                    }

                    /*DumpParam(param);
                    std::cout << " didn't match anything in ";
                    DumpTree(tree);
                    std::cout << "\n";*/

                    // No match for this param, try backtracking.
                    while(a > 0)
                    {
                        --a;
                        ParamMatchSnapshot& prevpos = position[a];
                        if(prevpos.parampos < n_tree_params)
                        {
                            // Try another combination.
                            b     = prevpos.parampos;
                            match = prevpos.snapshot;
                            used  = prevpos.used;
                            goto backtrack;
                        }
                    }
                    // If we cannot backtrack, break. No possible match.
                    /*if(!recursion)
                        std::cout << "Drats!\n";*/
                    return false;
                ok:;
                    /*if(!recursion)
                        std::cout << "Match for param " << a << " at " << b << std::endl;*/
                }
                // Match = no mismatch.

                // If the rule cares about the balance of
                // negative restholdings versus positive restholdings,
                // verify them.
                if(balance != BalanceDontCare)
                {
                    unsigned n_pos_restholdings = 0;
                    unsigned n_neg_restholdings = 0;

                    for(unsigned a=0; a<count; ++a)
                    {
                        const ParamSpec& param = pack.plist[index+a];
                        if(param.opcode == RestHolder)
                        {
                            for(size_t b=0; b<n_tree_params; ++b)
                                if(tree.Params[b].sign == param.sign && !used[b])
                                {
                                    if(param.sign)
                                        n_neg_restholdings += 1;
                                    else
                                        n_pos_restholdings += 1;
                                }
                        }
                    }
                    switch(balance)
                    {
                        case BalanceMoreNeg:
                            if(n_neg_restholdings <= n_pos_restholdings) return false;
                            break;
                        case BalanceMorePos:
                            if(n_pos_restholdings <= n_neg_restholdings) return false;
                            break;
                        case BalanceEqual:
                            if(n_pos_restholdings != n_neg_restholdings) return false;
                            break;
                        case BalanceDontCare: ;
                    }
                }

                // Now feed any possible RestHolders the remaining parameters.
                for(unsigned a=0; a<count; ++a)
                {
                    const ParamSpec& param = pack.plist[index+a];
                    if(param.opcode == RestHolder)
                    {
                        std::vector<uint_fast64_t>& RestList
                            = match.RestMap[param.index]; // mark it up

                        for(size_t b=0; b<n_tree_params; ++b)
                            if(tree.Params[b].sign == param.sign && !used[b])
                            {
                                if(!recursion)
                                    match.param_numbers.push_back(b);
                                uint_fast64_t hash = tree.Params[b].param->Hash;
                                RestList.push_back(hash);
                                match.trees.insert(
                                    std::make_pair(hash, tree.Params[b].param) );
                            }
                    }
                }
                return true;
            }
        }
        return false;
    }

    bool ParamSpec::Match(
        FPoptimizer_CodeTree::CodeTree& tree,
        MatchedParams::CodeTreeMatch& match,
        TransformationType transf) const
    {
        assert(opcode != RestHolder); // RestHolders are supposed to be handler by the caller

        switch(OpcodeType(opcode))
        {
            case NumConstant:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();
                if(transformation == Negate) res = -res;
                if(transformation == Invert) res = 1/res;
                double res2 = pack.clist[index];
                if(transf == Negate) res2 = -res2;
                if(transf == Invert) res2 = 1/res2;
                if(transf == NotThe) res2 = res2 != 0;
                if(res != res2) return false;
                return true;
            }
            case ImmedHolder:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();
                if(transformation == Negate) res = -res;
                if(transformation == Invert) res = 1/res;
                std::map<unsigned, double>::iterator
                    i = match.ImmedMap.lower_bound(index);
                if(i != match.ImmedMap.end() && i->first == index)
                {
                    double res2 = i->second;
                    if(transf == Negate) res2 = -res2;
                    if(transf == Invert) res2 = 1/res2;
                    if(transf == NotThe) res2 = res2 != 0;
                    return res == res2;
                }
                if(sign != (transf != None)) return false;

                match.ImmedMap.insert(i, std::make_pair((unsigned)index, res));
                return true;
            }
            case NamedHolder:
            {
                if(sign != (transf != None)) return false;
                std::map<unsigned, std::pair<uint_fast64_t, size_t> >::iterator
                    i = match.NamedMap.lower_bound(index);
                if(i != match.NamedMap.end() && i->first == index)
                {
                    return tree.Hash == i->second.first;
                }
                match.NamedMap.insert(i, std::make_pair(index, std::make_pair(tree.Hash, 1)));
                match.trees.insert(std::make_pair(tree.Hash, &tree));
                return true;
            }
            case RestHolder:
                break;
            case SubFunction:
            {
                if(sign != (transf != None)) return false;
                return pack.flist[index].Match(tree, match);
            }
            default:
            {
                if(!tree.IsImmed()) return false;
                double res = tree.GetImmed();
                if(transformation == Negate) res = -res;
                if(transformation == Invert) res = 1/res;
                double res2;
                if(!GetConst(match, res2)) return false;
                if(transf == Negate) res2 = -res2;
                if(transf == Invert) res2 = 1/res2;
                if(transf == NotThe) res2 = res2 != 0;
                return res == res2;
            }
        }
        return false;
    }

    bool ParamSpec::GetConst(
        const MatchedParams::CodeTreeMatch& match,
        double& result) const
    {
        switch(OpcodeType(opcode))
        {
            case NumConstant:
                result = pack.clist[index];
                break;
            case ImmedHolder:
            {
                std::map<unsigned, double>::const_iterator
                    i = match.ImmedMap.find(index);
                if(i == match.ImmedMap.end()) return false; // impossible
                result = i->second;
                break;
            }
            case NamedHolder:
            {
                std::map<unsigned, std::pair<uint_fast64_t, size_t> >::const_iterator
                    i = match.NamedMap.find(index);
                if(i == match.NamedMap.end()) return false; // impossible
                result = i->second.second;
                break;
            }
            case RestHolder:
            {
                // Not enumerable
                return false;
            }
            case SubFunction:
            {
                // Not enumerable
                return false;
            }
            default:
            {
                switch(OPCODE(opcode))
                {
                    case cAdd:
                        result=0;
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            result += tmp;
                        }
                        break;
                    case cMul:
                        result=1;
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            result *= tmp;
                        }
                        break;
                    case cMin:
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            if(p == 0 || tmp < result) result = tmp;
                        }
                        break;
                    case cMax:
                        for(unsigned p=0; p<count; ++p)
                        {
                            double tmp;
                            if(!pack.plist[index+p].GetConst(match, tmp)) return false;
                            if(p == 0 || tmp > result) result = tmp;
                        }
                        break;
                    case cSin: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::sin(result); break;
                    case cCos: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::cos(result); break;
                    case cTan: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::tan(result); break;
                    case cAsin: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::asin(result); break;
                    case cAcos: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::acos(result); break;
                    case cAtan: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::atan(result); break;
                    case cSinh: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::sinh(result); break;
                    case cCosh: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::cosh(result); break;
                    case cTanh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::tanh(result); break;
#ifndef FP_NO_ASINH
                    case cAsinh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = asinh(result); break;
                    case cAcosh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = acosh(result); break;
                    case cAtanh: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = atanh(result); break;
#endif
                    case cCeil: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::ceil(result); break;
                    case cFloor: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::floor(result); break;
                    case cLog: if(!pack.plist[index].GetConst(match, result))return false;
                               result = std::log(result); break;
                    case cLog2: if(!pack.plist[index].GetConst(match, result))return false;
                                result = std::log(result) * CONSTANT_L2I;
                                //result = std::log2(result);
                                break;
                    case cLog10: if(!pack.plist[index].GetConst(match, result))return false;
                                 result = std::log10(result); break;
                    case cPow:
                    {
                        if(!pack.plist[index+0].GetConst(match, result))return false;
                        double tmp;
                        if(!pack.plist[index+1].GetConst(match, tmp))return false;
                        result = std::pow(result, tmp);
                        break;
                    }
                    case cMod:
                    {
                        if(!pack.plist[index+0].GetConst(match, result))return false;
                        double tmp;
                        if(!pack.plist[index+1].GetConst(match, tmp))return false;
                        result = std::fmod(result, tmp);
                        break;
                    }
                    default:
                        return false;
                }
            }
        }
        if(transformation == Negate) result = -result;
        if(transformation == Invert) result = 1.0 / result;
        return true;
    }

    void MatchedParams::SynthesizeTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        for(unsigned a=0; a<count; ++a)
        {
            const ParamSpec& param = pack.plist[index+a];
            if(param.opcode == RestHolder)
            {
                // Add children directly to this tree
                param.SynthesizeTree(tree, matcher, match);
            }
            else
            {
                FPoptimizer_CodeTree::CodeTree* subtree = new FPoptimizer_CodeTree::CodeTree;
                param.SynthesizeTree(*subtree, matcher, match);
                subtree->Sort();
                subtree->Recalculate_Hash_NoRecursion(); // rehash this, but not the children, nor the parent
                FPoptimizer_CodeTree::CodeTree::Param p(subtree, param.sign) ;
                tree.AddParam(p);
            }
        }
    }

    void MatchedParams::ReplaceParams(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        // Replace the 0-level params indicated in "match" with the ones we have

        // First, construct the tree recursively using the "match" info
        SynthesizeTree(tree, matcher, match);

        // Remove the indicated params
        std::sort(match.param_numbers.begin(), match.param_numbers.end());
        for(size_t a=match.param_numbers.size(); a-->0; )
        {
            size_t num = match.param_numbers[a];
            tree.DelParam(num);
        }
        tree.Sort();
        tree.Rehash(true); // rehash this and its parents, but not its children
    }

    void MatchedParams::ReplaceTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        CodeTreeMatch& match) const
    {
        // Replace the entire tree with one indicated by our Params[0]
        // Note: The tree is still constructed using the holders indicated in "match".
        std::vector<FPoptimizer_CodeTree::CodeTree::Param> OldParams = tree.Params;
        tree.Params.clear();
        pack.plist[index].SynthesizeTree(tree, matcher, match);

        tree.Sort();
        tree.Rehash(true);  // rehash this and its parents, but not its children
    }

    /* Synthesizes a new tree based on the given information
     * in ParamSpec. Assume the tree is empty, don't deallocate
     * anything. Don't touch Hash, Parent.
     */
    void ParamSpec::SynthesizeTree(
        FPoptimizer_CodeTree::CodeTree& tree,
        const MatchedParams& matcher,
        MatchedParams::CodeTreeMatch& match) const
    {
        switch(ParamMatchingType(opcode))
        {
            case RestHolder:
            {
                std::map<unsigned, std::vector<uint_fast64_t> >
                    ::const_iterator i = match.RestMap.find(index);

                assert(i != match.RestMap.end());

                /*std::cout << std::flush;
                fprintf(stderr, "Restmap %u, sign %d, size is %u -- params %u\n",
                    (unsigned) i->first, sign, (unsigned) i->second.size(),
                    (unsigned) tree.Params.size());*/

                for(size_t a=0; a<i->second.size(); ++a)
                {
                    uint_fast64_t hash = i->second[a];

                    std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP>
                        ::const_iterator j = match.trees.find(hash);

                    assert(j != match.trees.end());

                    FPoptimizer_CodeTree::CodeTree* subtree = j->second->Clone();
                    FPoptimizer_CodeTree::CodeTree::Param p(subtree, sign);
                    tree.AddParam(p);
                }
                /*fprintf(stderr, "- params size became %u\n", (unsigned)tree.Params.size());
                fflush(stderr);*/
                break;
            }
            case SubFunction:
            {
                const Function& fitem = pack.flist[index];
                tree.Opcode = fitem.opcode;
                const MatchedParams& mitem = pack.mlist[fitem.index];
                mitem.SynthesizeTree(tree, matcher, match);
                break;
            }
            case NamedHolder:
                if(!anyrepeat && minrepeat == 1)
                {
                    /* Literal parameter */
                    std::map<unsigned, std::pair<uint_fast64_t, size_t> >
                        ::const_iterator i = match.NamedMap.find(index);

                    assert(i != match.NamedMap.end());

                    uint_fast64_t hash = i->second.first;

                    std::map<uint_fast64_t, FPoptimizer_CodeTree::CodeTreeP>
                        ::const_iterator j = match.trees.find(hash);

                    assert(j != match.trees.end());

                    tree.Opcode = j->second->Opcode;
                    switch(tree.Opcode)
                    {
                        case cImmed: tree.Value = j->second->Value; break;
                        case cVar:   tree.Var   = j->second->Var;  break;
                        case cFCall:
                        case cPCall: tree.Funcno = j->second->Funcno; break;
                    }

                    tree.SetParams(j->second->Params);
                    break;
                }
                // passthru; x+ is synthesized as the number, not as the tree
            case NumConstant:
            case ImmedHolder:
            default:
                tree.Opcode = cImmed;
                GetConst(match, tree.Value); // note: return value is ignored
                break;
        }
    }

#ifdef DEBUG_SUBSTITUTIONS
    void DumpParam(const ParamSpec& p)
    {
        //std::cout << "/*p" << (&p-pack.plist) << "*/";

        if(p.sign) std::cout << '~';
        if(p.transformation == Negate) std::cout << '-';
        if(p.transformation == Invert) std::cout << '/';

        switch(SpecialOpcode(p.opcode))
        {
            case NumConstant: std::cout << pack.clist[p.index]; break;
            case ImmedHolder: std::cout << ImmedHolderNames[p.index]; break;
            case NamedHolder: std::cout << NamedHolderNames[p.index]; break;
            case RestHolder: std::cout << '<' << p.index << '>'; break;
            case SubFunction: DumpFunction(pack.flist[p.index]); break;
            default:
            {
                std::string opcode = FP_GetOpcodeName(p.opcode).substr(1);
                for(size_t a=0; a<opcode.size(); ++a) opcode[a] = std::toupper(opcode[a]);
                std::cout << opcode << '(';
                for(unsigned a=0; a<p.count; ++a)
                {
                    if(a > 0) std::cout << ' ';
                    DumpParam(pack.plist[p.index+a]);
                }
                std::cout << " )";
            }
        }
        if(p.anyrepeat && p.minrepeat==1) std::cout << '*';
        if(p.anyrepeat && p.minrepeat==2) std::cout << '+';
    }

    void DumpParams(const MatchedParams& mitem)
    {
        //std::cout << "/*m" << (&mitem-pack.mlist) << "*/";

        if(mitem.type == PositionalParams) std::cout << '[';
        if(mitem.type == SelectedParams) std::cout << '{';

        for(unsigned a=0; a<mitem.count; ++a)
        {
            std::cout << ' ';
            DumpParam(pack.plist[mitem.index + a]);
        }

        switch(mitem.balance)
        {
            case BalanceMorePos: std::cout << " =+"; break;
            case BalanceMoreNeg: std::cout << " =-"; break;
            case BalanceEqual:   std::cout << " =="; break;
            case BalanceDontCare: break;
        }

        if(mitem.type == PositionalParams) std::cout << " ]";
        if(mitem.type == SelectedParams) std::cout << " }";
    }

    void DumpFunction(const Function& fitem)
    {
        //std::cout << "/*f" << (&fitem-pack.flist) << "*/";

        std::cout << '(' << FP_GetOpcodeName(fitem.opcode);
        DumpParams(pack.mlist[fitem.index]);
        std::cout << ')';
    }
    void DumpTree(const FPoptimizer_CodeTree::CodeTree& tree)
    {
        //std::cout << "/*" << tree.Depth << "*/";
        const char* sep2 = "";
        switch(tree.Opcode)
        {
            case cImmed: std::cout << tree.Value; return;
            case cVar:   std::cout << "Var" << tree.Var; return;
            case cAdd: sep2 = " +"; break;
            case cMul: sep2 = " *"; break;
            case cAnd: sep2 = " &"; break;
            case cOr: sep2 = " |"; break;
            default:
                std::cout << FP_GetOpcodeName(tree.Opcode);
                if(tree.Opcode == cFCall || tree.Opcode == cPCall)
                    std::cout << ':' << tree.Funcno;
        }
        std::cout << '(';
        if(tree.Params.size() <= 1 && *sep2) std::cout << (sep2+1) << ' ';
        for(size_t a=0; a<tree.Params.size(); ++a)
        {
            if(a > 0) std::cout << ' ';
            if(tree.Params[a].sign) std::cout << '~';

            DumpTree(*tree.Params[a].param);

            if(tree.Params[a].param->Parent != &tree)
            {
                std::cout << "(?""?""?))";
            }

            if(a+1 < tree.Params.size()) std::cout << sep2;
        }
        std::cout << ')';
    }
    void DumpMatch(const Function& input,
                   const FPoptimizer_CodeTree::CodeTree& tree,
                   const MatchedParams& replacement,
                   const MatchedParams::CodeTreeMatch& matchrec,
                   bool DidMatch)
    {
        std::cout <<
            "Found " << (DidMatch ? "match" : "mismatch") << ":\n"
            "  Pattern    : ";
        DumpFunction(input);
        std::cout << "\n"
            "  Replacement: ";
        DumpParams(replacement);
        std::cout << "\n";

        std::cout <<
            "  Tree       : ";
        DumpTree(tree);
        std::cout << "\n";

        for(std::map<unsigned, std::pair<uint_fast64_t, size_t> >::const_iterator
            i = matchrec.NamedMap.begin(); i != matchrec.NamedMap.end(); ++i)
        {
            std::cout << "           " << NamedHolderNames[i->first] << " = ";
            DumpTree(*matchrec.trees.find(i->second.first)->second);
            std::cout << " (" << i->second.second << " matches)\n";
        }

        for(std::map<unsigned, double>::const_iterator
            i = matchrec.ImmedMap.begin(); i != matchrec.ImmedMap.end(); ++i)
        {
            std::cout << "           " << ImmedHolderNames[i->first] << " = ";
            std::cout << i->second << std::endl;
        }

        for(std::map<unsigned, std::vector<uint_fast64_t> >::const_iterator
            i = matchrec.RestMap.begin(); i != matchrec.RestMap.end(); ++i)
        {
            for(size_t a=0; a<i->second.size(); ++a)
            {
                uint_fast64_t hash = i->second[a];
                std::cout << "         <" << i->first << "> = ";
                DumpTree(*matchrec.trees.find(hash)->second);
                std::cout << std::endl;
            }
            if(i->second.empty())
                std::cout << "         <" << i->first << "> = <empty>\n";
        }
    }
#endif
}
#include "fpconfig.hh"
#include "fparser.hh"
#include "fptypes.hh"


using namespace FUNCTIONPARSERTYPES;

namespace FPoptimizer_CodeTree
{
    bool    CodeTree::IsImmed() const { return Opcode == cImmed; }
    bool    CodeTree::IsVar()   const { return Opcode == cVar; }
}

using namespace FPoptimizer_CodeTree;

#ifdef FP_SUPPORT_OPTIMIZER
void FunctionParser::Optimize()
{
    if(isOptimized) return;
    CopyOnWrite();

    //PrintByteCode(std::cout);

    FPoptimizer_CodeTree::CodeTreeP tree
        = CodeTree::GenerateFrom(data->ByteCode, data->Immed, *data);

    while(FPoptimizer_Grammar::pack.glist[0].ApplyTo(*tree))
        {}

    while(FPoptimizer_Grammar::pack.glist[1].ApplyTo(*tree))
        {}

    while(FPoptimizer_Grammar::pack.glist[2].ApplyTo(*tree))
        {}

    tree->Sort_Recursive();

    std::vector<unsigned> byteCode;
    std::vector<double> immed;
    size_t stacktop_max = 0;
    tree->SynthesizeByteCode(byteCode, immed, stacktop_max);

    /*std::cout << std::flush;
    std::cerr << std::flush;
    fprintf(stderr, "Estimated stacktop %u\n", (unsigned)stacktop_max);
    fflush(stderr);*/

    if(data->StackSize != stacktop_max)
    {
        data->StackSize = stacktop_max;
        data->Stack.resize(stacktop_max);
    }

    data->ByteCode.swap(byteCode);
    data->Immed.swap(immed);

    //PrintByteCode(std::cout);

    isOptimized = true;
}
#endif
#include <cmath>
#include <list>
#include <cassert>

#include "fptypes.hh"


using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;

#ifndef FP_GENERATING_POWI_TABLE
static const unsigned MAX_POWI_BYTECODE_LENGTH = 15;
#else
static const unsigned MAX_POWI_BYTECODE_LENGTH = 999;
#endif
static const unsigned MAX_MULI_BYTECODE_LENGTH = 5;

#define POWI_TABLE_SIZE 256
#define POWI_WINDOW_SIZE 3
#ifndef FP_GENERATING_POWI_TABLE
static const
#endif
signed char powi_table[POWI_TABLE_SIZE] =
{
      0,   1,   1,   1,   2,   1,   3,   1, /*   0 -   7 */
      4,   1,   5,   1,   6,   1,  -2,   5, /*   8 -  15 */
      8,   1,   9,   1,  10,  -3,  11,   1, /*  16 -  23 */
     12,   5,  13,   9,  14,   1,  15,   1, /*  24 -  31 */
     16,   1,  17,  -5,  18,   1,  19,  13, /*  32 -  39 */
     20,   1,  21,   1,  22,   9,  -2,   1, /*  40 -  47 */
     24,   1,  25,  17,  26,   1,  27,  11, /*  48 -  55 */
     28,   1,  29,   8,  30,   1,  -2,   1, /*  56 -  63 */
     32,   1,  33,   1,  34,   1,  35,   1, /*  64 -  71 */
     36,   1,  37,  25,  38, -11,  39,   1, /*  72 -  79 */
     40,   9,  41,   1,  42,  17,   1,  29, /*  80 -  87 */
     44,   1,  45,   1,  46,  -3,  32,  19, /*  88 -  95 */
     48,   1,  49,  33,  50,   1,  51,   1, /*  96 - 103 */
     52,  35,  53,   8,  54,   1,  55,  37, /* 104 - 111 */
     56,   1,  57,  -5,  58,  13,  59, -17, /* 112 - 119 */
     60,   1,  61,  41,  62,  25,  -2,   1, /* 120 - 127 */
     64,   1,  65,   1,  66,   1,  67,  45, /* 128 - 135 */
     68,   1,  69,   1,  70,  48,  16,   8, /* 136 - 143 */
     72,   1,  73,  49,  74,   1,  75,   1, /* 144 - 151 */
     76,  17,   1,  -5,  78,   1,  32,  53, /* 152 - 159 */
     80,   1,  81,   1,  82,  33,   1,   2, /* 160 - 167 */
     84,   1,  85,  57,  86,   8,  87,  35, /* 168 - 175 */
     88,   1,  89,   1,  90,   1,  91,  61, /* 176 - 183 */
     92,  37,  93,  17,  94,  -3,  64,   2, /* 184 - 191 */
     96,   1,  97,  65,  98,   1,  99,   1, /* 192 - 199 */
    100,  67, 101,   8, 102,  41, 103,  69, /* 200 - 207 */
    104,   1, 105,  16, 106,  24, 107,   1, /* 208 - 215 */
    108,   1, 109,  73, 110,  17, 111,   1, /* 216 - 223 */
    112,  45, 113,  32, 114,   1, 115, -33, /* 224 - 231 */
    116,   1, 117,  -5, 118,  48, 119,   1, /* 232 - 239 */
    120,   1, 121,  81, 122,  49, 123,  13, /* 240 - 247 */
    124,   1, 125,   1, 126,   1,  -2,  85  /* 248 - 255 */
}; /* as in gcc, but custom-optimized for stack calculation */
static const int POWI_CACHE_SIZE = 256;

#define FPO(x) /**/
//#define FPO(x) x

static const struct SequenceOpCode
{
    double basevalue;
    unsigned op_flip;
    unsigned op_normal, op_normal_flip;
    unsigned op_inverse, op_inverse_flip;
} AddSequence = {0.0, cNeg, cAdd, cAdd, cSub, cRSub },
  MulSequence = {1.0, cInv, cMul, cMul, cDiv, cRDiv };

class FPoptimizer_CodeTree::CodeTree::ByteCodeSynth
{
public:
    ByteCodeSynth()
        : ByteCode(), Immed(), StackTop(0), StackMax(0)
    {
        /* estimate the initial requirements as such */
        ByteCode.reserve(64);
        Immed.reserve(8);
    }

    void Pull(std::vector<unsigned>& bc,
              std::vector<double>&   imm,
              size_t& StackTop_max)
    {
        ByteCode.swap(bc);
        Immed.swap(imm);
        StackTop_max = StackMax;
    }

    size_t GetByteCodeSize() const { return ByteCode.size(); }
    size_t GetStackTop()     const { return StackTop; }

    void PushVar(unsigned varno)
    {
        ByteCode.push_back(varno);
        SetStackTop(StackTop+1);
    }

    void PushImmed(double immed)
    {
        ByteCode.push_back(cImmed);
        Immed.push_back(immed);
        SetStackTop(StackTop+1);
    }

    void StackTopIs(uint_fast64_t hash)
    {
        if(StackTop > 0)
        {
            StackHash[StackTop-1].first = true;
            StackHash[StackTop-1].second = hash;
        }
    }

    void AddOperation(unsigned opcode, unsigned eat_count, unsigned produce_count = 1)
    {
        SetStackTop(StackTop - eat_count);

        if(opcode == cMul && ByteCode.back() == cDup)
            ByteCode.back() = cSqr;
        else
            ByteCode.push_back(opcode);
        SetStackTop(StackTop + produce_count);
    }

    void DoPopNMov(size_t targetpos, size_t srcpos)
    {
        ByteCode.push_back(cPopNMov);
        ByteCode.push_back(targetpos);
        ByteCode.push_back(srcpos);

        SetStackTop(srcpos+1);
        StackHash[targetpos] = StackHash[srcpos];
        SetStackTop(targetpos+1);
    }

    void DoDup(size_t src_pos)
    {
        if(src_pos == StackTop-1)
        {
            ByteCode.push_back(cDup);
        }
        else
        {
            ByteCode.push_back(cFetch);
            ByteCode.push_back(src_pos);
        }
        SetStackTop(StackTop + 1);
        StackHash[StackTop-1] = StackHash[src_pos];
    }

    bool FindAndDup(uint_fast64_t hash)
    {
        for(size_t a=StackHash.size(); a-->0; )
        {
            if(StackHash[a].first && StackHash[a].second == hash)
            {
                DoDup(a);
                return true;
            }
        }
        return false;
    }

    void SynthIfStep1(size_t& ofs)
    {
        SetStackTop(StackTop-1); // the If condition was popped.

        ofs = ByteCode.size();
        ByteCode.push_back(cIf);
        ByteCode.push_back(0); // code index
        ByteCode.push_back(0); // Immed index
    }
    void SynthIfStep2(size_t& ofs)
    {
        SetStackTop(StackTop-1); // ignore the pushed then-branch result.

        ByteCode[ofs+1] = ByteCode.size()+2;
        ByteCode[ofs+2] = Immed.size();

        ofs = ByteCode.size();
        ByteCode.push_back(cJump);
        ByteCode.push_back(0); // code index
        ByteCode.push_back(0); // Immed index
    }
    void SynthIfStep3(size_t& ofs)
    {
        SetStackTop(StackTop-1); // ignore the pushed else-branch result.

        ByteCode[ofs+1] = ByteCode.size()-1;
        ByteCode[ofs+2] = Immed.size();

        SetStackTop(StackTop+1); // one or the other was pushed.
    }

private:
    void SetStackTop(size_t value)
    {
        StackTop = value;
        if(StackTop > StackMax) StackMax = StackTop;
        StackHash.resize(value);
    }

private:
    std::vector<unsigned> ByteCode;
    std::vector<double>   Immed;

    std::vector<std::pair<bool/*known*/, uint_fast64_t/*hash*/> > StackHash;
    size_t StackTop;
    size_t StackMax;
};

namespace
{
    using namespace FPoptimizer_CodeTree;

    bool AssembleSequence(
                  CodeTree& tree, long count,
                  const SequenceOpCode& sequencing,
                  CodeTree::ByteCodeSynth& synth,
                  size_t max_bytecode_grow_length);

    class PowiCache
    {
    private:
        int cache[POWI_CACHE_SIZE];
        int cache_needed[POWI_CACHE_SIZE];

    public:
        PowiCache()
            : cache(), cache_needed() /* Assume we have no factors in the cache */
        {
            /* Decide which factors we would need multiple times.
             * Output:
             *   cache[]        = these factors were generated
             *   cache_needed[] = number of times these factors were desired
             */
            cache[1] = 1; // We have this value already.
        }

        bool Plan_Add(long value, int count)
        {
            if(value >= POWI_CACHE_SIZE) return false;
            //FPO(fprintf(stderr, "%ld will be needed %d times more\n", count, need_count));
            cache_needed[value] += count;
            return cache[value];
        }

        void Plan_Has(long value)
        {
            if(value < POWI_CACHE_SIZE)
                cache[value] = 1; // This value has been generated
        }

        void Start(size_t value1_pos)
        {
            for(int n=2; n<POWI_CACHE_SIZE; ++n)
                cache[n] = -1; /* Stack location for each component */

            Remember(1, value1_pos);

            DumpContents();
        }

        int Find(long value) const
        {
            if(value < POWI_CACHE_SIZE)
            {
                if(cache[value] >= 0)
                {
                    // found from the cache
                    FPO(fprintf(stderr, "* I found %ld from cache (%u,%d)\n",
                        value, (unsigned)cache[value], cache_needed[value]));
                    return cache[value];
                }
            }
            return -1;
        }

        void Remember(long value, size_t stackpos)
        {
            if(value >= POWI_CACHE_SIZE) return;

            FPO(fprintf(stderr, "* Remembering that %ld can be found at %u (%d uses remain)\n",
                value, (unsigned)stackpos, cache_needed[value]));
            cache[value] = stackpos;
        }

        void DumpContents() const
        {
            FPO(for(int a=1; a<POWI_CACHE_SIZE; ++a)
                if(cache[a] >= 0 || cache_needed[a] > 0)
                {
                    fprintf(stderr, "== cache: sp=%d, val=%d, needs=%d\n",
                        cache[a], a, cache_needed[a]);
                })
        }

        int UseGetNeeded(long value)
        {
            if(value >= 0 && value < POWI_CACHE_SIZE)
                return --cache_needed[value];
            return 0;
        }
    };

    size_t AssembleSequence_Subdivide(
        long count,
        PowiCache& cache,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth);

    void Subdivide_Combine(
        size_t apos, long aval,
        size_t bpos, long bval,
        PowiCache& cache,

        unsigned cumulation_opcode,
        unsigned cimulation_opcode_flip,

        CodeTree::ByteCodeSynth& synth);
}

namespace
{
    typedef
        std::map<uint_fast64_t,  std::pair<size_t, CodeTreeP> >
        TreeCountType;

    void FindTreeCounts(TreeCountType& TreeCounts, CodeTreeP tree)
    {
        TreeCountType::iterator i = TreeCounts.lower_bound(tree->Hash);
        if(i == TreeCounts.end() || i->first != tree->Hash)
            TreeCounts.insert(i, std::make_pair(tree->Hash, std::make_pair(size_t(1), tree)));
        else
            i->second.first += 1;

        for(size_t a=0; a<tree->Params.size(); ++a)
            FindTreeCounts(TreeCounts, tree->Params[a].param);
    }

    void RememberRecursivelyHashList(std::set<uint_fast64_t>& hashlist,
                                     CodeTreeP tree)
    {
        hashlist.insert(tree->Hash);
        for(size_t a=0; a<tree->Params.size(); ++a)
            RememberRecursivelyHashList(hashlist, tree->Params[a].param);
    }
#if 0
    void PowiTreeSequence(CodeTree& tree, const CodeTreeP param, long value)
    {
        tree.Params.clear();
        if(value < 0)
        {
            tree.Opcode = cInv;
            CodeTree* subtree = new CodeTree;
            PowiTreeSequence(*subtree, param, -value);
            tree.AddParam( CodeTree::Param(subtree, false) );
            tree.Recalculate_Hash_NoRecursion();
        }
        else
        {
            assert(value != 0 && value != 1);
            long half = 1;
            if(value < POWI_TABLE_SIZE)
                half = powi_table[value];
            else if(value & 1)
                half = value & ((1 << POWI_WINDOW_SIZE) - 1); // that is, value & 7
            else
                half = value / 2;
            long otherhalf = value-half;
            if(half > otherhalf || half<0) std::swap(half,otherhalf);

            if(half == 1)
                tree.AddParam( CodeTree::Param(param->Clone(), false) );
            else
            {
                CodeTree* subtree = new CodeTree;
                PowiTreeSequence(*subtree, param, half);
                tree.AddParam( CodeTree::Param(subtree, false) );
            }

            bool otherhalf_sign = otherhalf < 0;
            if(otherhalf < 0) otherhalf = -otherhalf;

            if(otherhalf == 1)
                tree.AddParam( CodeTree::Param(param->Clone(), otherhalf_sign) );
            else
            {
                CodeTree* subtree = new CodeTree;
                PowiTreeSequence(*subtree, param, otherhalf);
                tree.AddParam( CodeTree::Param(subtree, otherhalf_sign) );
            }

            tree.Opcode = cMul;

            tree.Sort();
            tree.Recalculate_Hash_NoRecursion();
        }
    }
    void ConvertPowi(CodeTree& tree)
    {
        if(tree.Opcode == cPow)
        {
            const CodeTree::Param& p0 = tree.Params[0];
            const CodeTree::Param& p1 = tree.Params[1];

            if(p1.param->IsLongIntegerImmed())
            {
                FPoptimizer_CodeTree::CodeTree::ByteCodeSynth temp_synth;

                if(AssembleSequence(*p0.param, p1.param->GetLongIntegerImmed(),
                    MulSequence,
                    temp_synth,
                    MAX_POWI_BYTECODE_LENGTH)
                  )
                {
                    // Seems like a good candidate!
                    // Redo the tree as a powi sequence.
                    CodeTreeP param = p0.param;
                    PowiTreeSequence(tree, param, p1.param->GetLongIntegerImmed());
                }
            }
        }
        for(size_t a=0; a<tree.Params.size(); ++a)
            ConvertPowi(*tree.Params[a].param);
    }
#endif
}

namespace FPoptimizer_CodeTree
{
    void CodeTree::SynthesizeByteCode(
        std::vector<unsigned>& ByteCode,
        std::vector<double>&   Immed,
        size_t& stacktop_max)
    {
        ByteCodeSynth synth;
    #if 0
        /* Convert integer powi sequences into trees
         * to put them into the scope of the CSE
         */
        /* Disabled: Seems to actually slow down */
        ConvertPowi(*this);
    #endif

        /* Find common subtrees */
        TreeCountType TreeCounts;
        FindTreeCounts(TreeCounts, this);

        /* Synthesize some of the most common ones */
        std::set<uint_fast64_t> AlreadyDoneTrees;
    FindMore: ;
        size_t best_score = 0;
        TreeCountType::const_iterator synth_it;
        for(TreeCountType::const_iterator
            i = TreeCounts.begin();
            i != TreeCounts.end();
            ++i)
        {
            size_t score = i->second.first;
            if(score < 2) continue; // It must always occur at least twice
            if(i->second.second->Depth < 2) continue; // And it must not be a simple expression
            if(AlreadyDoneTrees.find(i->first)
            != AlreadyDoneTrees.end()) continue; // And it must not yet have been synthesized
            score *= i->second.second->Depth;
            if(score > best_score)
                { best_score = score; synth_it = i; }
        }
        if(best_score > 0)
        {
            /* Synthesize the selected tree */
            synth_it->second.second->SynthesizeByteCode(synth);
            /* Add the tree and all its children to the AlreadyDoneTrees list,
             * to prevent it from being re-synthesized
             */
            RememberRecursivelyHashList(AlreadyDoneTrees, synth_it->second.second);
            goto FindMore;
        }

        /* Then synthesize the actual expression */
        SynthesizeByteCode(synth);
      #ifndef FP_DISABLE_EVAL
        /* Ensure that the expression result is
         * the only thing that remains in the stack
         */
        /* Removed: Fparser does not seem to care! */
        /* But if cEval is supported, it still needs to be done. */
        if(synth.GetStackTop() > 1)
            synth.DoPopNMov(0, synth.GetStackTop()-1);
      #endif
        synth.Pull(ByteCode, Immed, stacktop_max);
    }

    void CodeTree::SynthesizeByteCode(ByteCodeSynth& synth)
    {
        // If the synth can already locate our operand in the stack,
        // never mind synthesizing it again, just dup it.
        if(synth.FindAndDup(Hash))
        {
            return;
        }

        switch(Opcode)
        {
            case cVar:
                synth.PushVar(GetVar());
                break;
            case cImmed:
                synth.PushImmed(GetImmed());
                break;
            case cAdd:
            case cMul:
            case cMin:
            case cMax:
            case cAnd:
            case cOr:
            {
                // Operand re-sorting:
                // If the first param has a sign, try to find a param
                // that does _not_ have a sign and put it first.
                // This can be done because params are commutative
                // when they are grouped with their signs.
                if(!Params.empty() && Params[0].sign)
                {
                    for(size_t a=1; a<Params.size(); ++a)
                        if(!Params[a].sign)
                        {
                            std::swap(Params[0], Params[a]);
                            break;
                        }
                }

                // Try to ensure that Immeds don't have a sign
                for(size_t a=0; a<Params.size(); ++a)
                {
                    CodeTreeP& param = Params[a].param;
                    if(Params[a].sign && param->IsImmed())
                        switch(Opcode)
                        {
                            case cAdd: param->NegateImmed(); Params[a].sign=false; break;
                            case cMul: if(param->GetImmed() == 0.0) break;
                                       param->InvertImmed(); Params[a].sign=false; break;
                            case cAnd:
                            case cOr:  param->NotTheImmed(); Params[a].sign=false; break;
                        }
                }

                if(Opcode == cMul) // Special treatment for cMul sequences
                {
                    // If the paramlist contains an Immed, and that Immed
                    // fits in a long-integer, try to synthesize it
                    // as add-sequences instead.
                    for(size_t a=0; a<Params.size(); ++a)
                    {
                        Param p = Params[a];
                        CodeTreeP& param = p.param;
                        if(!p.sign && param->IsLongIntegerImmed())
                        {
                            long value = param->GetLongIntegerImmed();
                            Params.erase(Params.begin()+a);

                            bool success = AssembleSequence(
                                *this, value, AddSequence,
                                synth,
                                MAX_MULI_BYTECODE_LENGTH);

                            // Readd the token so that we don't need
                            // to deal with allocationd/deallocation here.
                            Params.insert(Params.begin()+a, p);

                            if(success)
                            {
                                // this tree was treated just fine
                                synth.StackTopIs(Hash);
                                return;
                            }
                        }
                    }
                }

                int n_stacked = 0;
                for(size_t a=0; a<Params.size(); ++a)
                {
                    CodeTreeP const & param = Params[a].param;
                    bool               sign = Params[a].sign;

                    param->SynthesizeByteCode(synth);
                    ++n_stacked;

                    if(sign) // Is the operand negated/inverted?
                    {
                        if(n_stacked == 1)
                        {
                            // Needs unary negation/invertion. Decide how to accomplish it.
                            switch(Opcode)
                            {
                                case cAdd:
                                    synth.AddOperation(cNeg, 1); // stack state: -1+1 = +0
                                    break;
                                case cMul:
                                    synth.AddOperation(cInv, 1); // stack state: -1+1 = +0
                                    break;
                                case cAnd:
                                case cOr:
                                    synth.AddOperation(cNot, 1); // stack state: -1+1 = +0
                                    break;
                            }
                            // Note: We could use RDiv or RSub when the first
                            // token is negated/inverted and the second is not, to
                            // avoid cNeg/cInv/cNot, but thanks to the operand
                            // re-sorting in the beginning of this code, this
                            // situation never arises.
                            // cNeg/cInv/cNot is only synthesized when the group
                            // consists entirely of negated/inverted items.
                        }
                        else
                        {
                            // Needs binary negation/invertion. Decide how to accomplish it.
                            switch(Opcode)
                            {
                                case cAdd:
                                    synth.AddOperation(cSub, 2); // stack state: -2+1 = -1
                                    break;
                                case cMul:
                                    synth.AddOperation(cDiv, 2); // stack state: -2+1 = -1
                                    break;
                                case cAnd:
                                case cOr:
                                    synth.AddOperation(cNot,   1);   // stack state: -1+1 = +0
                                    synth.AddOperation(Opcode, 2); // stack state: -2+1 = -1
                                    break;
                            }
                            n_stacked = n_stacked - 2 + 1;
                        }
                    }
                    else if(n_stacked > 1)
                    {
                        // Cumulate at the earliest opportunity.
                        synth.AddOperation(Opcode, 2); // stack state: -2+1 = -1
                        n_stacked = n_stacked - 2 + 1;
                    }
                }
                if(n_stacked == 0)
                {
                    // Uh, we got an empty cAdd/cMul/whatever...
                    // Synthesize a default value.
                    // This should never happen.
                    switch(Opcode)
                    {
                        case cAdd:
                        case cOr:
                            synth.PushImmed(0);
                            break;
                        case cMul:
                        case cAnd:
                            synth.PushImmed(1);
                            break;
                        case cMin:
                        case cMax:
                            //synth.PushImmed(NaN);
                            synth.PushImmed(0);
                            break;
                    }
                    ++n_stacked;
                }
                assert(n_stacked == 1);
                break;
            }
            case cPow:
            {
                const Param& p0 = Params[0];
                const Param& p1 = Params[1];

                if(!p1.param->IsLongIntegerImmed()
                || !AssembleSequence( /* Optimize integer exponents */
                        *p0.param, p1.param->GetLongIntegerImmed(),
                        MulSequence,
                        synth,
                        MAX_POWI_BYTECODE_LENGTH)
                  )
                {
                    p0.param->SynthesizeByteCode(synth);
                    p1.param->SynthesizeByteCode(synth);
                    synth.AddOperation(Opcode, 2);
                }
                break;
            }
            case cIf:
            {
                size_t ofs;
                // If the parameter amount is != 3, we're screwed.
                Params[0].param->SynthesizeByteCode(synth); // expression
                synth.SynthIfStep1(ofs);
                Params[1].param->SynthesizeByteCode(synth); // true branch
                synth.SynthIfStep2(ofs);
                Params[2].param->SynthesizeByteCode(synth); // false branch
                synth.SynthIfStep3(ofs);
                break;
            }
            case cFCall:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                synth.AddOperation(Funcno, 0, 0);
                break;
            }
            case cPCall:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                synth.AddOperation(Funcno, 0, 0);
                break;
            }
            default:
            {
                // If the parameter count is invalid, we're screwed.
                for(size_t a=0; a<Params.size(); ++a)
                    Params[a].param->SynthesizeByteCode(synth);
                synth.AddOperation(Opcode, Params.size());
                break;
            }
        }
        synth.StackTopIs(Hash);
    }
}

namespace
{
    void PlanNtimesCache
        (long value,
         PowiCache& cache,
         int need_count,
         int recursioncount=0)
    {
        if(value < 1) return;

    #ifdef FP_GENERATING_POWI_TABLE
        if(recursioncount > 32) throw false;
    #endif

        if(cache.Plan_Add(value, need_count)) return;

        long half = 1;
        if(value < POWI_TABLE_SIZE)
            half = powi_table[value];
        else if(value & 1)
            half = value & ((1 << POWI_WINDOW_SIZE) - 1); // that is, value & 7
        else
            half = value / 2;

        long otherhalf = value-half;
        if(half > otherhalf || half<0) std::swap(half,otherhalf);

        FPO(fprintf(stderr, "value=%ld, half=%ld, otherhalf=%ld\n", value,half,otherhalf));

        if(half == otherhalf)
        {
            PlanNtimesCache(half,      cache, 2, recursioncount+1);
        }
        else
        {
            PlanNtimesCache(half,      cache, 1, recursioncount+1);
            PlanNtimesCache(otherhalf>0?otherhalf:-otherhalf,
                                       cache, 1, recursioncount+1);
        }

        cache.Plan_Has(value);
    }

    bool AssembleSequence(
        CodeTree& tree, long count,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth,
        size_t max_bytecode_grow_length)
    {
        CodeTree::ByteCodeSynth backup = synth;
        const size_t bytecodesize_backup = synth.GetByteCodeSize();

        if(count == 0)
        {
            synth.PushImmed(sequencing.basevalue);
        }
        else
        {
            tree.SynthesizeByteCode(synth);

            if(count < 0)
            {
                synth.AddOperation(sequencing.op_flip, 1);
                count = -count;
            }

            if(count > 1)
            {
                /* To prevent calculating the same factors over and over again,
                 * we use a cache. */
                PowiCache cache;
                PlanNtimesCache(count, cache, 1);

                size_t stacktop_desired = synth.GetStackTop();

                cache.Start( synth.GetStackTop()-1 );

                FPO(fprintf(stderr, "Calculating result for %ld...\n", count));
                size_t res_stackpos = AssembleSequence_Subdivide(
                    count, cache, sequencing,
                    synth);

                size_t n_excess = synth.GetStackTop() - stacktop_desired;
                if(n_excess > 0 || res_stackpos != stacktop_desired-1)
                {
                    // Remove the cache values
                    synth.DoPopNMov(stacktop_desired-1, res_stackpos);
                }
            }
        }

        size_t bytecode_grow_amount = synth.GetByteCodeSize() - bytecodesize_backup;
        if(bytecode_grow_amount > max_bytecode_grow_length)
        {
            synth = backup;
            return false;
        }
        return true;
    }

    size_t AssembleSequence_Subdivide(
        long value,
        PowiCache& cache,
        const SequenceOpCode& sequencing,
        CodeTree::ByteCodeSynth& synth)
    {
        int cachepos = cache.Find(value);
        if(cachepos >= 0)
        {
            // found from the cache
            return cachepos;
        }

        long half = 1;
        if(value < POWI_TABLE_SIZE)
            half = powi_table[value];
        else if(value & 1)
            half = value & ((1 << POWI_WINDOW_SIZE) - 1); // that is, value & 7
        else
            half = value / 2;
        long otherhalf = value-half;
        if(half > otherhalf || half<0) std::swap(half,otherhalf);

        FPO(fprintf(stderr, "* I want %ld, my plan is %ld + %ld\n", value, half, value-half));

        if(half == otherhalf)
        {
            size_t half_pos = AssembleSequence_Subdivide(half, cache, sequencing, synth);

            // self-cumulate the subdivide result
            Subdivide_Combine(half_pos,half, half_pos,half, cache,
                sequencing.op_normal, sequencing.op_normal_flip,
                synth);
        }
        else
        {
            long part1 = half;
            long part2 = otherhalf>0?otherhalf:-otherhalf;

            size_t part1_pos = AssembleSequence_Subdivide(part1, cache, sequencing, synth);
            size_t part2_pos = AssembleSequence_Subdivide(part2, cache, sequencing, synth);

            FPO(fprintf(stderr, "Subdivide(%ld: %ld, %ld)\n", value, half, otherhalf));

            Subdivide_Combine(part1_pos,part1, part2_pos,part2, cache,
                otherhalf>0 ? sequencing.op_normal      : sequencing.op_inverse,
                otherhalf>0 ? sequencing.op_normal_flip : sequencing.op_inverse_flip,
                synth);
        }
        size_t stackpos = synth.GetStackTop()-1;
        cache.Remember(value, stackpos);
        cache.DumpContents();
        return stackpos;
    }

    void Subdivide_Combine(
        size_t apos, long aval,
        size_t bpos, long bval,
        PowiCache& cache,
        unsigned cumulation_opcode,
        unsigned cumulation_opcode_flip,
        CodeTree::ByteCodeSynth& synth)
    {
        /*FPO(fprintf(stderr, "== making result for (sp=%u, val=%d, needs=%d) and (sp=%u, val=%d, needs=%d), stacktop=%u\n",
            (unsigned)apos, aval, aval>=0 ? cache_needed[aval] : -1,
            (unsigned)bpos, bval, bval>=0 ? cache_needed[bval] : -1,
            (unsigned)synth.GetStackTop()));*/

        // Figure out whether we can trample a and b
        int a_needed = cache.UseGetNeeded(aval);
        int b_needed = cache.UseGetNeeded(bval);

        bool flipped = false;

        #define DUP_BOTH() do { \
            if(apos < bpos) { size_t tmp=apos; apos=bpos; bpos=tmp; flipped=!flipped; } \
            FPO(fprintf(stderr, "-> dup(%u) dup(%u) op\n", (unsigned)apos, (unsigned)bpos)); \
            synth.DoDup(apos); \
            synth.DoDup(apos==bpos ? synth.GetStackTop()-1 : bpos); } while(0)
        #define DUP_ONE(p) do { \
            FPO(fprintf(stderr, "-> dup(%u) op\n", (unsigned)p)); \
            synth.DoDup(p); \
        } while(0)

        if(a_needed > 0)
        {
            if(b_needed > 0)
            {
                // If they must both be preserved, make duplicates
                // First push the one that is at the larger stack
                // address. This increases the odds of possibly using cDup.
                DUP_BOTH();

                //SCENARIO 1:
                // Input:  x B A x x
                // Temp:   x B A x x A B
                // Output: x B A x x R
                //SCENARIO 2:
                // Input:  x A B x x
                // Temp:   x A B x x B A
                // Output: x A B x x R
            }
            else
            {
                // A must be preserved, but B can be trampled over

                // SCENARIO 1:
                //  Input:  x B x x A
                //   Temp:  x B x x A A B   (dup both, later first)
                //  Output: x B x x A R
                // SCENARIO 2:
                //  Input:  x A x x B
                //   Temp:  x A x x B A
                //  Output: x A x x R       -- only commutative cases
                // SCENARIO 3:
                //  Input:  x x x B A
                //   Temp:  x x x B A A B   (dup both, later first)
                //  Output: x x x B A R
                // SCENARIO 4:
                //  Input:  x x x A B
                //   Temp:  x x x A B A     -- only commutative cases
                //  Output: x x x A R
                // SCENARIO 5:
                //  Input:  x A B x x
                //   Temp:  x A B x x A B   (dup both, later first)
                //  Output: x A B x x R

                // if B is not at the top, dup both.
                if(bpos != synth.GetStackTop()-1)
                    DUP_BOTH();    // dup both
                else
                {
                    DUP_ONE(apos); // just dup A
                    flipped=!flipped;
                }
            }
        }
        else if(b_needed > 0)
        {
            // B must be preserved, but A can be trampled over
            // This is a mirror image of the a_needed>0 case, so I'll cut the chase
            if(apos != synth.GetStackTop()-1)
                DUP_BOTH();
            else
                DUP_ONE(bpos);
        }
        else
        {
            // Both can be trampled over.
            // SCENARIO 1:
            //  Input:  x B x x A
            //   Temp:  x B x x A B
            //  Output: x B x x R
            // SCENARIO 2:
            //  Input:  x A x x B
            //   Temp:  x A x x B A
            //  Output: x A x x R       -- only commutative cases
            // SCENARIO 3:
            //  Input:  x x x B A
            //  Output: x x x R         -- only commutative cases
            // SCENARIO 4:
            //  Input:  x x x A B
            //  Output: x x x R
            // SCENARIO 5:
            //  Input:  x A B x x
            //   Temp:  x A B x x A B   (dup both, later first)
            //  Output: x A B x x R
            // SCENARIO 6:
            //  Input:  x x x C
            //   Temp:  x x x C C   (c is both A and B)
            //  Output: x x x R

            if(apos == bpos && apos == synth.GetStackTop()-1)
                DUP_ONE(apos); // scenario 6
            else if(apos == synth.GetStackTop()-1 && bpos == synth.GetStackTop()-2)
            {
                FPO(fprintf(stderr, "-> op\n")); // scenario 3
                flipped=!flipped;
            }
            else if(apos == synth.GetStackTop()-2 && bpos == synth.GetStackTop()-1)
                FPO(fprintf(stderr, "-> op\n")); // scenario 4
            else if(apos == synth.GetStackTop()-1)
                DUP_ONE(bpos); // scenario 1
            else if(bpos == synth.GetStackTop()-1)
            {
                DUP_ONE(apos); // scenario 2
                flipped=!flipped;
            }
            else
                DUP_BOTH(); // scenario 5
        }
        // Add them together.
        synth.AddOperation(flipped ? cumulation_opcode_flip : cumulation_opcode, 2);
    }
}
#include <cmath>
#include <cassert>

#include "fptypes.hh"

#include "fparser.hh"


using namespace FUNCTIONPARSERTYPES;
//using namespace FPoptimizer_Grammar;


namespace FPoptimizer_CodeTree
{
    class CodeTreeParserData
    {
    private:
        std::vector<CodeTreeP> stack;
    public:
        CodeTreeParserData() : stack() { }

        void Eat(unsigned nparams, OPCODE opcode)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = opcode;
            size_t stackhead = stack.size() - nparams;
            for(unsigned a=0; a<nparams; ++a)
            {
                CodeTree::Param param;
                param.param = stack[stackhead + a];
                param.sign  = false;
                newnode->AddParam(param);
            }
            stack.resize(stackhead);
            stack.push_back(newnode);
        }

        void EatFunc(unsigned params, OPCODE opcode, unsigned funcno)
        {
            Eat(params, opcode);
            stack.back()->Funcno = funcno;
        }

        void AddConst(double value)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = cImmed;
            newnode->Value  = value;
            stack.push_back(newnode);
        }

        void AddVar(unsigned varno)
        {
            CodeTreeP newnode = new CodeTree;
            newnode->Opcode = cVar;
            newnode->Var    = varno;
            stack.push_back(newnode);
        }

        void SetLastOpParamSign(unsigned paramno)
        {
            stack.back()->Params[paramno].sign = true;
        }

        void SwapLastTwoInStack()
        {
            std::swap(stack[stack.size()-1],
                      stack[stack.size()-2]);
        }

        void Dup()
        {
            stack.push_back(stack.back()->Clone());
        }

        CodeTreeP PullResult()
        {
            CodeTreeP result = stack.back();
            stack.resize(stack.size()-1);
            result->Rehash(false);
            result->Sort_Recursive();
            return result;
        }

        void CheckConst()
        {
            // Check if the last token on stack can be optimized with constant math
            CodeTreeP result = stack.back();
            result->ConstantFolding();
        }
    private:
        CodeTreeParserData(const CodeTreeParserData&);
        CodeTreeParserData& operator=(const CodeTreeParserData&);
    };

    CodeTreeP CodeTree::GenerateFrom(
        const std::vector<unsigned>& ByteCode,
        const std::vector<double>& Immed,
        const FunctionParser::Data& fpdata)
    {
        CodeTreeParserData data;
        std::vector<size_t> labels;

        for(size_t IP=0, DP=0; ; ++IP)
        {
            while(!labels.empty() && labels.back() == IP)
            {
                // The "else" of an "if" ends here
                data.Eat(3, cIf);
                labels.erase(labels.end()-1);
            }
            if(IP >= ByteCode.size()) break;

            unsigned opcode = ByteCode[IP];
            if(OPCODE(opcode) >= VarBegin)
            {
                data.AddVar(opcode);
            }
            else
            {
                switch(opcode)
                {
                    // Specials
                    case cIf:
                        IP += 2;
                        continue;
                    case cJump:
                        labels.push_back(ByteCode[IP+1]+1);
                        IP += 2;
                        continue;
                    case cImmed:
                        data.AddConst(Immed[DP++]);
                        break;
                    case cDup:
                        data.Dup();
                        break;
                    case cNop:
                        break;
                    case cFCall:
                    {
                        unsigned funcno = ByteCode[++IP];
                        unsigned params = fpdata.FuncPtrs[funcno].params;
                        data.EatFunc(params, OPCODE(opcode), funcno);
                        break;
                    }
                    case cPCall:
                    {
                        unsigned funcno = ByteCode[++IP];
                        unsigned params = fpdata.FuncParsers[funcno].params;
                        data.EatFunc(params, OPCODE(opcode), funcno);
                        break;
                    }
                    // Unary operators requiring special attention
                    case cInv:
                        data.Eat(1, cMul); // Unary division is inverse multiplying
                        data.SetLastOpParamSign(0);
                        break;
                    case cNeg:
                        data.Eat(1, cAdd); // Unary minus is negative adding.
                        data.SetLastOpParamSign(0);
                        break;
                    case cSqr:
                        data.Dup();
                        data.Eat(2, cMul);
                        break;
                    // Unary functions requiring special attention
                    case cDeg:
                        data.AddConst(CONSTANT_DR);
                        data.Eat(2, cMul);
                        break;
                    case cRad:
                        data.AddConst(CONSTANT_RD);
                        data.Eat(2, cMul);
                        break;
                    case cExp:
                        data.AddConst(CONSTANT_E);
                        data.SwapLastTwoInStack();
                        data.Eat(2, cPow);
                        break;
                    case cSqrt:
                        data.AddConst(0.5);
                        data.Eat(2, cPow);
                        break;
                    case cCot:
                        data.Eat(1, cTan);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cCsc:
                        data.Eat(1, cSin);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cSec:
                        data.Eat(1, cCos);
                        data.Eat(1, cMul);
                        data.SetLastOpParamSign(0);
                        break;
                    case cLog10:
                        data.Eat(1, cLog);
                        data.AddConst(CONSTANT_L10I);
                        data.Eat(2, cMul);
                        break;
                    case cLog2:
                        data.Eat(1, cLog);
                        data.AddConst(CONSTANT_L2I);
                        data.Eat(2, cMul);
                        break;
                    // Binary operators requiring special attention
                    case cSub:
                        data.Eat(2, cAdd); // Minus is negative adding
                        data.SetLastOpParamSign(1);
                        break;
                    case cRSub:
                        data.Eat(2, cAdd);
                        data.SetLastOpParamSign(0); // negate param0 instead of param1
                        break;
                    case cDiv:
                        data.Eat(2, cMul); // Divide is inverse multiply
                        data.SetLastOpParamSign(1);
                        break;
                    case cRDiv:
                        data.Eat(2, cMul);
                        data.SetLastOpParamSign(0); // invert param0 instead of param1
                        break;
                    // Binary operators not requiring special attention
                    case cAdd: case cMul:
                    case cMod: case cPow:
                    case cEqual: case cLess: case cGreater:
                    case cNEqual: case cLessOrEq: case cGreaterOrEq:
                    case cAnd: case cOr:
                        data.Eat(2, OPCODE(opcode));
                        break;
                    // Unary operators not requiring special attention
                    case cNot:
                        data.Eat(1, OPCODE(opcode));
                        break;
                    // Other functions
#ifndef FP_DISABLE_EVAL
                    case cEval:
                    {
                        unsigned paramcount = fpdata.variableRefs.size();
                        data.Eat(paramcount, OPCODE(opcode));
                        break;
                    }
#endif
                    default:
                        unsigned funcno = opcode-cAbs;
                        assert(funcno < FUNC_AMOUNT);
                        const FuncDefinition& func = Functions[funcno];
                        data.Eat(func.params, OPCODE(opcode));
                        break;
                }
            }
            data.CheckConst();
        }
        return data.PullResult();
    }
}

#endif
